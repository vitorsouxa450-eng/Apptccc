# LoadSense — Entrega Final do TCC

Esta entrega reúne o site, o aplicativo, o backend de integração e os arquivos do banco de dados.

A versão dos códigos foi revisada para remover comentários de implementação e reduzir formatação excessiva, mantendo a funcionalidade existente.

## Conteúdo

- 01_SITE: site web final integrado à API.
- 02_APP: aplicativo mobile final integrado à API.
- 03_BANCO_DE_DADOS: banco completo e migrações.
- 04_BACKEND_E_INTEGRACAO: API Node.js + Express que conecta os clientes ao MySQL.
- 05_DOCUMENTACAO: guia de execução local e resumo das integrações.

## Execução local

1. Instale MySQL 8.x e Node.js 20+.
2. Importe `03_BANCO_DE_DADOS/LoadSense_LOCAL_COMPLETO.sql`.
3. Configure a senha do MySQL no `.env` do backend.
4. Entre em `04_BACKEND_E_INTEGRACAO/LoadSense_Backend_Final` e execute `npm install`.
5. Execute `npm start`.
6. Abra `http://localhost:3333/`.

## Credenciais locais de demonstração

Empresa: `loadsense-demo`

E-mail: `admin@loadsense.local`

Senha: `LoadSense123!`
