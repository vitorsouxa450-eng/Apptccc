# Resumo das integrações

## Site → API → MySQL

O site usa a camada `api-client.js` e a integração `loadsense-site-integration.js` para chamar as rotas da API REST. A API faz a autenticação e as operações de leitura/escrita no MySQL.

## App → API → MySQL

O aplicativo mobile usa o cliente HTTP da API e autenticação por access/refresh token. O mesmo backend é utilizado pelo site, permitindo que os dois clientes trabalhem com a mesma base de dados.

## Backend → MySQL

O backend usa a configuração do `.env` para acessar o banco `loadsense` em ambiente local. As regras de pesagem já existentes no banco, incluindo procedures e triggers, permanecem no banco principal.

## Banco → API

A migração `02_LoadSense_API_support_migration.sql` adiciona as estruturas auxiliares necessárias ao fluxo da API.
