# Guia de execução local — LoadSense

## 1. Banco de dados

Abra o MySQL Workbench e execute o arquivo:

`03_BANCO_DE_DADOS/LoadSense_LOCAL_COMPLETO.sql`

Depois confirme:

```sql
SHOW DATABASES;
USE loadsense;
SHOW TABLES;
```

## 2. Backend/API

Extraia:

`04_BACKEND_E_INTEGRACAO/LoadSense_Backend_API_Final_v0.2.0.zip`

No terminal:

```bat
cd caminho\\para\\backend
npm install
npm start
```

Configure o arquivo `.env` conforme o `.env.example`, principalmente `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER` e `DB_PASSWORD`.

## 3. Teste de conexão

Abra no navegador:

`http://localhost:3333/health`

A resposta deve indicar que a API está funcionando e o banco está conectado.

## 4. Site

Abra:

`http://localhost:3333/`

## 5. Login de demonstração

Empresa: `loadsense-demo`

E-mail: `admin@loadsense.local`

Senha: `LoadSense123!`

## 6. Aplicativo

Extraia `02_APP/LoadSense_App_Final_Organizado_v0.2.0.zip` e instale as dependências com `npm install`.

Para Android Emulator, configure a URL da API para `http://10.0.2.2:3333/api/v1`.

Para dispositivo físico na mesma rede, use o IP local do computador que executa a API, por exemplo `http://192.168.0.10:3333/api/v1`.
