require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
async function main() {
    const [, , companyCodeArg, emailArg, passwordArg, ...nameParts] = process.argv;
    const companyCode = String(companyCodeArg || '').trim().toLowerCase();
    const email = String(emailArg || '').trim().toLowerCase();
    const password = String(passwordArg || '');
    const name = nameParts.join(' ').trim();
    if (!companyCode || !email || !password || !name) {
        throw new Error('Uso: npm run create-admin -- <empresa> <email> <senha> <nome completo>');
    }
    const pool = await mysql.createPool({
        host: process.env.DB_HOST || '127.0.0.1', port: Number(process.env.DB_PORT || 3306), database: process.env.DB_NAME || 'loadsense',
        user: process.env.DB_USER || 'loadsense_app', password: process.env.DB_PASSWORD || '', timezone: '+00:00',
    });
    try {
        const [companies] = await pool.query(`SELECT id, slug FROM companies WHERE slug = ? LIMIT 1`, [companyCode]);
        const company = companies[0];
        if (!company)
            throw new Error(`Empresa não encontrada: ${companyCode}`);
        const [roles] = await pool.query(`SELECT id FROM roles WHERE company_id = ? AND name = 'ADMINISTRATOR' LIMIT 1`, [company.id]);
        const role = roles[0];
        if (!role)
            throw new Error('Perfil ADMINISTRATOR não encontrado.');
        const passwordHash = await bcrypt.hash(password, 12);
        await pool.query(`INSERT INTO users (company_id, role_id, full_name, email, password_hash)
       VALUES (?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), role_id = VALUES(role_id), password_hash = VALUES(password_hash), active = 1, locked_until = NULL, failed_login_attempts = 0`, [company.id, role.id, name, email, passwordHash]);
        console.log(`Administrador criado/atualizado: ${email}`);
    }
    finally {
        await pool.end();
    }
}
main().catch((e) => { console.error(e.message); process.exit(1); });
