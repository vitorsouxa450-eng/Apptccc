require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
const path = require('path');
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
app.use(express.static(PUBLIC_DIR));
app.get('/', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'Login', 'Login.html')));
const allowedOrigins = (process.env.CORS_ORIGIN || '*').split(',').map((v) => v.trim()).filter(Boolean);
app.use(cors({
    origin(origin, callback) {
        if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin))
            return callback(null, true);
        return callback(new Error('CORS origin not allowed'));
    },
}));
const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    database: process.env.DB_NAME || 'loadsense',
    user: process.env.DB_USER || 'loadsense_app',
    password: process.env.DB_PASSWORD || '',
    waitForConnections: true,
    connectionLimit: Number(process.env.DB_CONNECTION_LIMIT || 10),
    charset: 'utf8mb4',
    timezone: '+00:00',
    dateStrings: true,
});
const PORT = Number(process.env.PORT || 3333);
const API_PREFIX = '/api/v1';
const JWT_SECRET = process.env.JWT_SECRET || 'development-only-change-me';
const ACCESS_TOKEN_TTL = process.env.ACCESS_TOKEN_TTL || '15m';
const REFRESH_TOKEN_TTL_DAYS = Math.max(1, Number(process.env.REFRESH_TOKEN_TTL_DAYS || 30));
const permissionMap = {
    DASHBOARD_VIEW: 'dashboard.read',
    OPERATION_CREATE: 'operations.write',
    OPERATION_VIEW: 'operations.read',
    OPERATION_UPDATE: 'operations.write',
    OPERATION_FINALIZE: 'operations.write',
    OPERATION_CANCEL: 'operations.write',
    READING_CREATE: 'readings.write',
    READING_ACCEPT: 'readings.write',
    ALERT_VIEW: 'alerts.read',
    ALERT_MANAGE: 'alerts.manage',
    REPORT_GENERATE: 'reports.write',
    VEHICLE_MANAGE: 'vehicles.manage',
    DRIVER_MANAGE: 'drivers.manage',
    PRODUCT_MANAGE: 'products.manage',
    DEVICE_MANAGE: 'devices.manage',
    USER_MANAGE: 'users.manage',
    SETTINGS_MANAGE: 'settings.manage',
    AUDIT_VIEW: 'audit.read',
    TRACKING_VIEW: 'tracking.read',
    TRACKING_MANAGE: 'tracking.manage',
    AI_VIEW: 'ai.read',
    AI_GENERATE: 'ai.write',
    SUBSCRIPTION_VIEW: 'subscription.read',
    SUBSCRIPTION_MANAGE: 'subscription.manage',
};
function errorResponse(res, status, code, message) {
    return res.status(status).json({ error: { code, message, request_id: `req_${crypto.randomBytes(8).toString('hex')}` } });
}
function normalizeEmail(v) { return String(v || '').trim().toLowerCase(); }
function normalizeCode(v) { return String(v || '').trim().toLowerCase(); }
function hashToken(v) { return crypto.createHash('sha256').update(v).digest('hex'); }
function randomToken() { return crypto.randomBytes(48).toString('base64url'); }
function nowIso() { return new Date().toISOString(); }
function relativeTime(value) {
    if (!value)
        return 'Sem sinal';
    const minutes = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 60000));
    if (minutes < 1)
        return 'Agora';
    if (minutes < 60)
        return `Há ${minutes} min`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24)
        return `Há ${hours} h`;
    return `Há ${Math.floor(hours / 24)} d`;
}
function statusLabel(v) { return ({ ANALYSIS: 'Em análise', NORMAL: 'Normal', ATTENTION: 'Atenção', CRITICAL: 'Crítico' }[v] || v); }
function statusTone(v) { return v === 'CRITICAL' ? 'critical' : v === 'ATTENTION' ? 'warning' : 'success'; }
function stageLabel(v) { return ({ EMPTY_TRUCK: 'Peso vazio', SEPARATED_CARGO: 'Peso da carga', LOADED_TRUCK: 'Peso carregado' }[v] || v); }
function cargoKg(row) {
    if (row.actual_cargo_weight_kg != null)
        return Number(row.actual_cargo_weight_kg);
    if (row.loaded_truck_weight_kg != null && row.empty_truck_weight_kg != null)
        return Math.max(0, Number(row.loaded_truck_weight_kg) - Number(row.empty_truck_weight_kg));
    if (row.separated_cargo_weight_kg != null)
        return Number(row.separated_cargo_weight_kg);
    return Number(row.declared_cargo_weight_kg || 0);
}
function targetKg(row) { return Number(row.declared_cargo_weight_kg ?? row.separated_cargo_weight_kg ?? 0); }
async function getPermissions(companyId, roleId) {
    const [rows] = await pool.query(`SELECT p.code FROM role_permissions rp
      JOIN permissions p ON p.id = rp.permission_id
      JOIN roles r ON r.id = rp.role_id AND r.company_id = ?
     WHERE rp.role_id = ? ORDER BY p.code`, [companyId, roleId]);
    return rows.map((r) => permissionMap[r.code] || String(r.code).toLowerCase());
}
async function getTermsAccepted(companyId, userId) {
    const [rows] = await pool.query(`SELECT COUNT(*) AS pending_count
       FROM legal_documents ld
      WHERE ld.company_id = ? AND ld.active = 1 AND ld.mandatory = 1
        AND NOT EXISTS (
          SELECT 1 FROM legal_acceptances la
           WHERE la.company_id = ld.company_id
             AND la.user_id = ?
             AND la.legal_document_id = ld.id
        )`, [companyId, userId]);
    return Number(rows[0]?.pending_count || 0) === 0;
}
function signAccessToken(user) {
    return jwt.sign({ sub: String(user.id), company_id: String(user.company_id), role_id: String(user.role_id), role: user.role_name }, JWT_SECRET, { expiresIn: ACCESS_TOKEN_TTL, issuer: 'loadsense-api', audience: 'loadsense-client' });
}
async function sessionBody(user) {
    return {
        access_token: signAccessToken(user),
        user: { id: String(user.id), name: user.full_name, email: user.email, role: user.role_name },
        company: { id: String(user.company_id), code: user.slug, name: user.trade_name },
        permissions: await getPermissions(user.company_id, user.role_id),
        terms_accepted: await getTermsAccepted(user.company_id, user.id),
    };
}
async function findUser(companyCode, email) {
    const [rows] = await pool.query(`SELECT u.id, u.company_id, u.role_id, u.full_name, u.email, u.password_hash,
            u.active, u.failed_login_attempts, u.locked_until,
            c.slug, c.trade_name, c.active AS company_active,
            r.name AS role_name, r.active AS role_active
       FROM users u
       JOIN companies c ON c.id = u.company_id
       JOIN roles r ON r.company_id = u.company_id AND r.id = u.role_id
      WHERE c.slug = ? AND LOWER(u.email) = ? LIMIT 1`, [companyCode, email]);
    return rows[0] || null;
}
async function issueRefreshToken(user, req, connection = pool) {
    const token = randomToken();
    const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_DAYS * 86400000);
    await connection.query(`INSERT INTO auth_sessions (company_id, user_id, refresh_token_hash, expires_at, ip_address, user_agent)
     VALUES (?, ?, ?, ?, ?, ?)`, [user.company_id, user.id, hashToken(token), expiresAt, req.ip || null, req.get('user-agent') || null]);
    return token;
}
async function requireAuth(req, res, next) {
    const header = req.get('authorization') || '';
    if (!header.startsWith('Bearer '))
        return errorResponse(res, 401, 'UNAUTHORIZED', 'Sessão não autenticada.');
    try {
        const payload = jwt.verify(header.slice(7), JWT_SECRET, { issuer: 'loadsense-api', audience: 'loadsense-client' });
        const [rows] = await pool.query(`SELECT u.id, u.company_id, u.role_id, u.full_name, u.email, u.active,
              c.slug, c.trade_name, c.active AS company_active,
              r.name AS role_name, r.active AS role_active
         FROM users u
         JOIN companies c ON c.id = u.company_id
         JOIN roles r ON r.company_id = u.company_id AND r.id = u.role_id
        WHERE u.id = ? AND u.company_id = ? LIMIT 1`, [Number(payload.sub), Number(payload.company_id)]);
        const user = rows[0];
        if (!user || !user.active || !user.company_active || !user.role_active)
            return errorResponse(res, 401, 'SESSION_INVALID', 'Sessão inválida ou usuário inativo.');
        req.user = user;
        return next();
    }
    catch {
        return errorResponse(res, 401, 'TOKEN_EXPIRED', 'Sessão expirada.');
    }
}
async function buildOperationSummary(row) {
    const current = cargoKg(row);
    const target = targetKg(row);
    const calcProgress = target > 0 ? Math.min(100, Math.max(0, current / target * 100)) : 0;
    const progress = row.progress_percent == null ? Math.round(calcProgress) : Math.round(Number(row.progress_percent));
    const deviceOnline = row.device_state === 'ONLINE' && row.device_last_seen_at && (Date.now() - new Date(row.device_last_seen_at).getTime() < 300000);
    const currentLocation = row.current_latitude != null && row.current_longitude != null
        ? `${Number(row.current_latitude).toFixed(5)}, ${Number(row.current_longitude).toFixed(5)}`
        : row.tracking_state === 'IN_TRANSIT' ? 'Em trânsito' : row.destination || 'Sem posição';
    return {
        id: String(row.id), code: row.operation_code,
        state: row.state === 'COMPLETED' ? 'COMPLETED' : 'ACTIVE',
        status: statusLabel(row.status), statusTone: statusTone(row.status),
        plate: row.vehicle_plate, driver: row.driver_name || 'Não informado', cargo: row.cargo_product_name || 'Não informado',
        rfidTag: row.rfid_code || 'Não vinculada', origin: row.origin || 'Origem não informada', destination: row.destination || 'Destino não informado',
        currentLocation, currentWeightTons: Number((current / 1000).toFixed(3)), targetWeightTons: Number((target / 1000).toFixed(3)), progress,
        scheduledAt: row.planned_departure_at || row.started_at || '', estimatedArrival: row.estimated_arrival_at || row.planned_arrival_at || '',
        lastSignal: relativeTime(row.last_position_at || row.device_last_seen_at), deviceOnline: Boolean(deviceOnline),
        alertsCount: 0, routeProgress: Number(row.progress_percent || 0), progressPercent: Number(row.progress_percent || 0), trackingState: row.tracking_state || 'NOT_STARTED', currentLatitude: row.current_latitude != null ? Number(row.current_latitude) : null, currentLongitude: row.current_longitude != null ? Number(row.current_longitude) : null, speedKmh: row.speed_kmh != null ? Number(row.speed_kmh) : null, estimatedArrival: row.estimated_arrival_at || row.planned_arrival_at || '', emptyWeightKg: row.empty_truck_weight_kg != null ? Number(row.empty_truck_weight_kg) : null, separatedCargoWeightKg: row.separated_cargo_weight_kg != null ? Number(row.separated_cargo_weight_kg) : null, loadedWeightKg: row.loaded_truck_weight_kg != null ? Number(row.loaded_truck_weight_kg) : null, actualCargoWeightKg: row.actual_cargo_weight_kg != null ? Number(row.actual_cargo_weight_kg) : null, differenceKg: row.difference_kg != null ? Number(row.difference_kg) : null, differencePercent: row.difference_percent != null ? Number(row.difference_percent) : null, weighings: [], events: [],
    };
}
const operationSelect = `
    SELECT o.id, o.operation_code, o.state, o.status,
           o.started_at, o.completed_at, o.planned_departure_at, o.planned_arrival_at,
           o.departed_at, o.arrived_at,
           o.declared_cargo_weight_kg, o.separated_cargo_weight_kg,
           o.empty_truck_weight_kg, o.loaded_truck_weight_kg, o.actual_cargo_weight_kg,
           v.plate AS vehicle_plate,
           d.full_name AS driver_name,
           cp.name AS cargo_product_name,
           rt.origin, rt.destination,
           COALESCE(rfid.code, '') AS rfid_code,
           COALESCE(ots.tracking_state, 'NOT_STARTED') AS tracking_state,
           ots.current_latitude, ots.current_longitude, ots.speed_kmh,
           ots.progress_percent, ots.estimated_arrival_at, ots.last_position_at,
           ots.delay_minutes,
           dev.state AS device_state, dev.last_seen_at AS device_last_seen_at
      FROM weighing_operations o
      JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
      LEFT JOIN drivers d ON d.company_id = o.company_id AND d.id = o.driver_id
      LEFT JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
      LEFT JOIN routes rt ON rt.company_id = o.company_id AND rt.id = o.route_id
      LEFT JOIN rfid_tags rfid ON rfid.company_id = o.company_id AND rfid.id = o.rfid_tag_id
      LEFT JOIN operation_tracking_status ots ON ots.company_id = o.company_id AND ots.operation_id = o.id
      LEFT JOIN weighing_stations ws ON ws.company_id = o.company_id AND ws.id = o.weighing_station_id
      LEFT JOIN devices dev ON dev.company_id = ws.company_id AND dev.id = ws.scale_device_id
     WHERE o.company_id = ? AND o.state <> 'CANCELLED'`;
async function listOperations(companyId, state, search) {
    let sql = operationSelect;
    const params = [companyId];
    if (state === 'ACTIVE')
        sql += ` AND o.state IN ('DRAFT','IN_PROGRESS')`;
    if (state === 'COMPLETED')
        sql += ` AND o.state = 'COMPLETED'`;
    if (search) {
        const s = `%${search}%`;
        sql += ` AND (o.operation_code LIKE ? OR v.plate LIKE ? OR d.full_name LIKE ? OR cp.name LIKE ? OR rt.origin LIKE ? OR rt.destination LIKE ?)`;
        params.push(s, s, s, s, s, s);
    }
    sql += ` ORDER BY COALESCE(ots.last_position_at, o.completed_at, o.started_at) DESC LIMIT 250`;
    const [rows] = await pool.query(sql, params);
    return Promise.all(rows.map((row) => buildOperationSummary(row)));
}
async function getOperationDetail(companyId, operationId) {
    const [rows] = await pool.query(`${operationSelect} AND o.id = ? LIMIT 1`, [companyId, operationId]);
    const row = rows[0];
    if (!row)
        return null;
    const operation = await buildOperationSummary(row);
    const [countRows] = await pool.query(`SELECT COUNT(*) AS c FROM alerts WHERE company_id = ? AND operation_id = ? AND state IN ('OPEN','ACKNOWLEDGED')`, [companyId, operationId]);
    operation.alertsCount = Number(countRows[0]?.c || 0);
    const [weighings] = await pool.query(`SELECT id, stage, weight_kg, measured_at, accepted_at
       FROM weighing_readings WHERE company_id = ? AND operation_id = ? AND is_accepted = 1
      ORDER BY measured_at, id`, [companyId, operationId]);
    operation.weighings = weighings.map((w) => ({ id: String(w.id), label: stageLabel(w.stage), valueTons: Number((Number(w.weight_kg) / 1000).toFixed(3)), recordedAt: w.measured_at || w.accepted_at || '' }));
    const [events] = await pool.query(`SELECT CONCAT('alert-', id) AS id, title, message AS description, created_at AS event_time,
            CASE WHEN severity = 'CRITICAL' THEN 'critical' ELSE 'warning' END AS tone
       FROM alerts WHERE company_id = ? AND operation_id = ?
      UNION ALL
     SELECT CONCAT('event-', id) AS id,
            CASE event_type WHEN 'CREATED' THEN 'Operação criada' WHEN 'FINALIZED' THEN 'Pesagem finalizada' WHEN 'READING_ACCEPTED' THEN 'Leitura aceita' WHEN 'STATUS_CHANGED' THEN 'Status alterado' ELSE REPLACE(event_type, '_', ' ') END AS title,
            'Evento operacional registrado.' AS description, created_at AS event_time, 'warning' AS tone
       FROM operation_events WHERE company_id = ? AND operation_id = ?
      ORDER BY event_time DESC LIMIT 30`, [companyId, operationId, companyId, operationId]);
    operation.events = events.map((e) => ({ id: String(e.id), title: e.title, description: e.description, time: relativeTime(e.event_time), tone: e.tone === 'critical' ? 'critical' : 'warning' }));
    return operation;
}
app.get('/health', async (_req, res) => {
    try {
        await pool.query('SELECT 1');
        res.json({ ok: true, database: 'online', timestamp: nowIso() });
    }
    catch {
        res.status(503).json({ ok: false, database: 'offline', timestamp: nowIso() });
    }
});
const router = express.Router();
router.get('/app/bootstrap', async (req, res) => {
    try {
        const platform = String(req.query.platform || '').toUpperCase() === 'IOS' ? 'IOS' : 'ANDROID';
        const build = Number(req.query.build || 1);
        const [rows] = await pool.query(`SELECT minimum_supported_build_number, maintenance_mode, maintenance_message, store_url
         FROM app_platform_settings WHERE platform = ? LIMIT 1`, [platform]);
        const s = rows[0];
        if (!s)
            return res.json({ state: 'ready' });
        if (s.maintenance_mode)
            return res.json({ state: 'maintenance', message: s.maintenance_message || 'Manutenção em andamento.' });
        if (build < Number(s.minimum_supported_build_number)) {
            const fallback = platform === 'IOS' ? process.env.IOS_STORE_URL : process.env.ANDROID_STORE_URL;
            return res.json({ state: 'update-required', storeUrl: s.store_url || fallback || '' });
        }
        return res.json({ state: 'ready' });
    }
    catch (error) {
        console.error('bootstrap', error);
        return errorResponse(res, 503, 'BOOTSTRAP_UNAVAILABLE', 'Não foi possível iniciar o LoadSense.');
    }
});
router.post('/auth/login', async (req, res) => {
    const companyCode = normalizeCode(req.body?.company_code);
    const email = normalizeEmail(req.body?.email);
    const password = String(req.body?.password || '');
    if (!companyCode || !email || !password)
        return errorResponse(res, 400, 'INVALID_INPUT', 'Informe empresa, e-mail e senha.');
    try {
        const user = await findUser(companyCode, email);
        const invalid = () => errorResponse(res, 401, 'INVALID_CREDENTIALS', 'Empresa, e-mail ou senha inválidos.');
        if (!user || !user.active || !user.company_active || !user.role_active)
            return invalid();
        if (user.locked_until && new Date(user.locked_until).getTime() > Date.now())
            return invalid();
        const ok = await bcrypt.compare(password, user.password_hash);
        if (!ok) {
            const attempts = Number(user.failed_login_attempts || 0) + 1;
            if (attempts >= 5)
                await pool.query(`UPDATE users SET failed_login_attempts = 0, locked_until = DATE_ADD(CURRENT_TIMESTAMP(3), INTERVAL 15 MINUTE) WHERE company_id = ? AND id = ?`, [user.company_id, user.id]);
            else
                await pool.query(`UPDATE users SET failed_login_attempts = ? WHERE company_id = ? AND id = ?`, [attempts, user.company_id, user.id]);
            return invalid();
        }
        await pool.query(`UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = CURRENT_TIMESTAMP(3) WHERE company_id = ? AND id = ?`, [user.company_id, user.id]);
        const body = await sessionBody(user);
        body.refresh_token = await issueRefreshToken(user, req);
        body.expires_in = 900;
        return res.json(body);
    }
    catch (error) {
        console.error('login', error);
        return errorResponse(res, 500, 'LOGIN_ERROR', 'Não foi possível concluir o login.');
    }
});
router.post('/auth/refresh', async (req, res) => {
    const refreshToken = String(req.body?.refresh_token || '');
    if (!refreshToken)
        return errorResponse(res, 401, 'INVALID_REFRESH_TOKEN', 'Token de renovação ausente.');
    const hash = hashToken(refreshToken);
    try {
        const [rows] = await pool.query(`SELECT s.id AS session_id, u.id, u.company_id, u.role_id, u.full_name, u.email,
              u.active, c.slug, c.trade_name, c.active AS company_active,
              r.name AS role_name, r.active AS role_active
         FROM auth_sessions s
         JOIN users u ON u.company_id = s.company_id AND u.id = s.user_id
         JOIN companies c ON c.id = s.company_id
         JOIN roles r ON r.company_id = u.company_id AND r.id = u.role_id
        WHERE s.refresh_token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > CURRENT_TIMESTAMP(3)
        LIMIT 1`, [hash]);
        const user = rows[0];
        if (!user || !user.active || !user.company_active || !user.role_active)
            return errorResponse(res, 401, 'INVALID_REFRESH_TOKEN', 'Token de renovação inválido.');
        const conn = await pool.getConnection();
        try {
            await conn.beginTransaction();
            await conn.query(`UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'ROTATED' WHERE id = ?`, [user.session_id]);
            const newRefresh = await issueRefreshToken(user, req, conn);
            await conn.commit();
            const body = await sessionBody(user);
            body.refresh_token = newRefresh;
            body.expires_in = 900;
            return res.json(body);
        }
        catch (e) {
            await conn.rollback();
            throw e;
        }
        finally {
            conn.release();
        }
    }
    catch (error) {
        console.error('refresh', error);
        return errorResponse(res, 401, 'INVALID_REFRESH_TOKEN', 'Token de renovação inválido.');
    }
});
router.post('/auth/logout', async (req, res) => {
    const refreshToken = String(req.body?.refresh_token || '');
    if (refreshToken)
        await pool.query(`UPDATE auth_sessions SET revoked_at = CURRENT_TIMESTAMP(3), revoke_reason = 'LOGOUT' WHERE refresh_token_hash = ? AND revoked_at IS NULL`, [hashToken(refreshToken)]);
    return res.status(204).send();
});
router.post('/auth/password/forgot', async (req, res) => {
    const companyCode = normalizeCode(req.body?.company_code);
    const email = normalizeEmail(req.body?.email);
    try {
        const user = await findUser(companyCode, email);
        if (user && user.active && user.company_active) {
            const token = randomToken();
            await pool.query(`INSERT INTO password_reset_tokens (company_id, user_id, token_hash, expires_at) VALUES (?, ?, ?, DATE_ADD(CURRENT_TIMESTAMP(3), INTERVAL 30 MINUTE))`, [user.company_id, user.id, hashToken(token)]);
            console.log(`[password-reset] token criado para ${email}; conecte um provedor de e-mail para envio.`);
        }
    }
    catch (error) {
        console.error('password forgot', error);
    }
    return res.status(202).json({ message: 'Se a conta existir, as instruções serão enviadas.' });
});
router.post('/company-requests', async (req, res) => {
    const b = req.body || {};
    if (!b.legal_name || !b.document || !b.responsible_name || !b.email || b.accepted_privacy !== true)
        return errorResponse(res, 400, 'INVALID_INPUT', 'Preencha os dados obrigatórios e aceite o aviso de privacidade.');
    try {
        const [result] = await pool.query(`INSERT INTO company_requests (legal_name, document_number, responsible_name, email, phone, privacy_accepted) VALUES (?, ?, ?, ?, ?, 1)`, [String(b.legal_name).trim(), String(b.document).trim(), String(b.responsible_name).trim(), normalizeEmail(b.email), b.phone || null]);
        return res.status(201).json({ requestId: `LS-${String(result.insertId).padStart(6, '0')}` });
    }
    catch (error) {
        console.error('company request', error);
        return errorResponse(res, 500, 'REQUEST_ERROR', 'Não foi possível registrar a solicitação.');
    }
});
router.get('/me', requireAuth, async (req, res) => {
    const permissions = await getPermissions(req.user.company_id, req.user.role_id);
    const termsAccepted = await getTermsAccepted(req.user.company_id, req.user.id);
    res.json({ user: { id: String(req.user.id), name: req.user.full_name, email: req.user.email, role: req.user.role_name }, company: { id: String(req.user.company_id), code: req.user.slug, name: req.user.trade_name }, permissions, terms_accepted: termsAccepted });
});
router.post('/me/legal-acceptances', requireAuth, async (req, res) => {
    try {
        const [docs] = await pool.query(`SELECT id FROM legal_documents WHERE company_id = ? AND active = 1 AND mandatory = 1`, [req.user.company_id]);
        for (const doc of docs) {
            await pool.query(`INSERT INTO legal_acceptances (company_id, user_id, legal_document_id, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE accepted_at = CURRENT_TIMESTAMP(3), ip_address = VALUES(ip_address), user_agent = VALUES(user_agent)`, [req.user.company_id, req.user.id, doc.id, req.ip || null, req.get('user-agent') || null]);
        }
        const permissions = await getPermissions(req.user.company_id, req.user.role_id);
        return res.json({ user: { id: String(req.user.id), name: req.user.full_name, email: req.user.email, role: req.user.role_name }, company: { id: String(req.user.company_id), code: req.user.slug, name: req.user.trade_name }, permissions, terms_accepted: true });
    }
    catch (error) {
        console.error('legal acceptance', error);
        return errorResponse(res, 500, 'LEGAL_ACCEPTANCE_ERROR', 'Não foi possível registrar o aceite.');
    }
});
router.get('/dashboard', requireAuth, async (req, res) => {
    const companyId = req.user.company_id;
    try {
        const [[metricRows], [activeRows], [alertCountRows], [alertRows]] = await Promise.all([
            pool.query(`SELECT
        SUM(CASE WHEN started_at >= UTC_TIMESTAMP() - INTERVAL 1 DAY THEN 1 ELSE 0 END) AS trips,
        SUM(CASE WHEN state = 'COMPLETED' AND completed_at >= UTC_TIMESTAMP() - INTERVAL 1 DAY THEN 1 ELSE 0 END) AS completed,
        SUM(CASE WHEN status = 'NORMAL' AND started_at >= UTC_TIMESTAMP() - INTERVAL 1 DAY THEN 1 ELSE 0 END) AS normal_count,
        COALESCE(SUM(CASE WHEN state = 'COMPLETED' AND completed_at >= UTC_TIMESTAMP() - INTERVAL 1 DAY THEN COALESCE(actual_cargo_weight_kg,0) ELSE 0 END),0) AS cargo_kg
        FROM weighing_operations WHERE company_id = ? AND state <> 'CANCELLED'`, [companyId]),
            pool.query(`SELECT id FROM weighing_operations WHERE company_id = ? AND state IN ('DRAFT','IN_PROGRESS') ORDER BY started_at DESC LIMIT 1`, [companyId]),
            pool.query(`SELECT COUNT(*) AS c FROM alerts WHERE company_id = ? AND state IN ('OPEN','ACKNOWLEDGED')`, [companyId]),
            pool.query(`SELECT id, title, message, severity, created_at FROM alerts WHERE company_id = ? AND state IN ('OPEN','ACKNOWLEDGED') ORDER BY created_at DESC LIMIT 5`, [companyId]),
        ]);
        const metric = metricRows[0] || {};
        const activeOperation = activeRows[0] ? await getOperationDetail(companyId, activeRows[0].id) : null;
        res.json({
            metrics: [
                { id: 'trips', label: 'Viagens', value: Number(metric.trips || 0), tone: 'orange' },
                { id: 'cargo', label: 'Cargas', value: Number(metric.completed || 0), tone: 'green' },
                { id: 'tons', label: 'Toneladas', value: Number((Number(metric.cargo_kg || 0) / 1000).toFixed(1)), tone: 'yellow' },
                { id: 'alerts', label: 'Alertas ativos', value: Number(alertCountRows[0]?.c || 0), tone: 'red' },
                { id: 'normal_percent', label: 'Operações normais', value: Number((metric.trips ? (Number(metric.normal_count || 0) / Number(metric.trips || 1)) * 100 : 0).toFixed(1)), tone: 'green' },
            ],
            activeOperation: activeOperation ? { id: activeOperation.id, code: activeOperation.code, origin: activeOperation.origin, destination: activeOperation.destination, currentWeightTons: activeOperation.currentWeightTons, targetWeightTons: activeOperation.targetWeightTons, progress: activeOperation.progress, status: activeOperation.status } : null,
            alerts: alertRows.map((a) => ({ id: String(a.id), title: a.title, description: a.message, time: relativeTime(a.created_at), severity: a.severity === 'CRITICAL' ? 'critical' : 'warning' })),
            updatedAt: nowIso(),
        });
    }
    catch (error) {
        console.error('dashboard', error);
        return errorResponse(res, 500, 'DASHBOARD_ERROR', 'Não foi possível carregar os indicadores.');
    }
});
router.get('/operations', requireAuth, async (req, res) => {
    const state = String(req.query.state || '').toUpperCase();
    const filter = state === 'ACTIVE' || state === 'COMPLETED' ? state : undefined;
    try {
        return res.json(await listOperations(req.user.company_id, filter, String(req.query.search || '').trim()));
    }
    catch (error) {
        console.error('operations', error);
        return errorResponse(res, 500, 'OPERATIONS_ERROR', 'Não foi possível carregar as operações.');
    }
});
router.get('/operations/:id', requireAuth, async (req, res) => {
    try {
        const operation = await getOperationDetail(req.user.company_id, Number(req.params.id));
        if (!operation)
            return errorResponse(res, 404, 'OPERATION_NOT_FOUND', 'Operação não encontrada.');
        return res.json(operation);
    }
    catch (error) {
        console.error('operation', error);
        return errorResponse(res, 500, 'OPERATION_ERROR', 'Não foi possível carregar a operação.');
    }
});
router.get('/monitoring/operations', requireAuth, async (req, res) => {
    try {
        return res.json(await listOperations(req.user.company_id, 'ACTIVE', String(req.query.search || '').trim()));
    }
    catch (error) {
        console.error('monitoring', error);
        return errorResponse(res, 500, 'MONITORING_ERROR', 'Não foi possível carregar o monitoramento.');
    }
});
router.get('/alerts', requireAuth, async (req, res) => {
    const state = String(req.query.state || '').toUpperCase();
    try {
        let sql = `SELECT a.id, a.operation_id, a.alert_type, a.severity, a.state, a.title, a.message, a.difference_kg, a.difference_percent, a.created_at,
                      o.operation_code, v.plate, d.full_name AS driver, cp.name AS cargo
                 FROM alerts a
                 JOIN weighing_operations o ON o.company_id = a.company_id AND o.id = a.operation_id
                 JOIN vehicles v ON v.company_id = o.company_id AND v.id = o.vehicle_id
                 LEFT JOIN drivers d ON d.company_id = o.company_id AND d.id = o.driver_id
                 LEFT JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
                WHERE a.company_id = ?`;
        const params = [req.user.company_id];
        if (['OPEN', 'ACKNOWLEDGED', 'RESOLVED'].includes(state)) {
            sql += ` AND a.state = ?`;
            params.push(state);
        }
        sql += ` ORDER BY a.created_at DESC LIMIT 250`;
        const [rows] = await pool.query(sql, params);
        res.json(rows);
    }
    catch (error) {
        console.error('alerts', error);
        return errorResponse(res, 500, 'ALERTS_ERROR', 'Não foi possível carregar os alertas.');
    }
});
router.patch('/alerts/:id', requireAuth, async (req, res) => {
    const state = String(req.body?.state || '').toUpperCase();
    if (!['ACKNOWLEDGED', 'RESOLVED'].includes(state))
        return errorResponse(res, 400, 'INVALID_STATE', 'Estado de alerta inválido.');
    try {
        if (state === 'ACKNOWLEDGED') {
            await pool.query(`UPDATE alerts SET state='ACKNOWLEDGED', acknowledged_by_user_id=?, acknowledged_at=CURRENT_TIMESTAMP(3) WHERE company_id=? AND id=?`, [req.user.id, req.user.company_id, req.params.id]);
        }
        else {
            await pool.query(`UPDATE alerts SET state='RESOLVED', resolved_by_user_id=?, resolved_at=CURRENT_TIMESTAMP(3), resolution_notes=? WHERE company_id=? AND id=?`, [req.user.id, String(req.body?.resolution_notes || 'Resolvido pelo painel.'), req.user.company_id, req.params.id]);
        }
        const [rows] = await pool.query(`SELECT id, state FROM alerts WHERE company_id=? AND id=?`, [req.user.company_id, req.params.id]);
        if (!rows[0])
            return errorResponse(res, 404, 'ALERT_NOT_FOUND', 'Alerta não encontrado.');
        return res.json(rows[0]);
    }
    catch (error) {
        console.error('alert update', error);
        return errorResponse(res, 500, 'ALERT_UPDATE_ERROR', 'Não foi possível atualizar o alerta.');
    }
});
router.get('/settings', requireAuth, async (req, res) => {
    try {
        const [rows] = await pool.query(`SELECT tolerance_percent, critical_limit_percent, tare_tolerance_percent, reading_stability_tolerance_kg, minimum_stable_readings, max_reading_age_seconds, allow_manual_readings, require_manual_reason, require_rfid, automatic_sheet_refresh, critical_alert_notifications, automatic_email_reports, default_weight_unit, tracking_alerts_enabled FROM company_settings WHERE company_id=?`, [req.user.company_id]);
        return res.json(rows[0] || {});
    }
    catch (error) {
        console.error('settings', error);
        return errorResponse(res, 500, 'SETTINGS_ERROR', 'Não foi possível carregar as configurações.');
    }
});
router.patch('/settings', requireAuth, async (req, res) => {
    const b = req.body || {};
    try {
        await pool.query(`INSERT INTO company_settings (company_id, tolerance_percent, critical_limit_percent, default_weight_unit, updated_by_user_id) VALUES (?,?,?,?,?)
      ON DUPLICATE KEY UPDATE tolerance_percent=VALUES(tolerance_percent), critical_limit_percent=VALUES(critical_limit_percent), default_weight_unit=VALUES(default_weight_unit), updated_by_user_id=VALUES(updated_by_user_id)`, [req.user.company_id, Number(b.tolerance_percent ?? 1.5), Number(b.critical_limit_percent ?? 3), ['KG', 'TON'].includes(String(b.default_weight_unit || 'KG').toUpperCase()) ? String(b.default_weight_unit).toUpperCase() : 'KG', req.user.id]);
        const [rows] = await pool.query(`SELECT tolerance_percent, critical_limit_percent, default_weight_unit FROM company_settings WHERE company_id=?`, [req.user.company_id]);
        return res.json(rows[0]);
    }
    catch (error) {
        console.error('settings update', error);
        return errorResponse(res, 500, 'SETTINGS_UPDATE_ERROR', 'Não foi possível salvar as configurações.');
    }
});
router.get('/catalogs', requireAuth, async (req, res) => {
    try {
        const [[vehicles], [drivers], [cargoProducts], [rfidTags], [routes], [units], [stations]] = await Promise.all([
            pool.query(`SELECT id, plate, fleet_code FROM vehicles WHERE company_id=? AND active=1 ORDER BY plate`, [req.user.company_id]),
            pool.query(`SELECT id, full_name, employee_code FROM drivers WHERE company_id=? AND active=1 ORDER BY full_name`, [req.user.company_id]),
            pool.query(`SELECT id, name, default_unit FROM cargo_products WHERE company_id=? AND active=1 ORDER BY name`, [req.user.company_id]),
            pool.query(`SELECT id, code, vehicle_id FROM rfid_tags WHERE company_id=? AND active=1 ORDER BY code`, [req.user.company_id]),
            pool.query(`SELECT id, origin, destination, distance_km FROM routes WHERE company_id=? AND active=1 ORDER BY origin, destination`, [req.user.company_id]),
            pool.query(`SELECT id, code, name FROM operational_units WHERE company_id=? AND active=1 ORDER BY name`, [req.user.company_id]),
            pool.query(`SELECT id, operational_unit_id, code, name FROM weighing_stations WHERE company_id=? AND active=1 ORDER BY name`, [req.user.company_id]),
        ]);
        return res.json({ vehicles, drivers, cargo_products: cargoProducts, rfid_tags: rfidTags, routes, operational_units: units, weighing_stations: stations });
    }
    catch (error) {
        console.error('catalogs', error);
        return errorResponse(res, 500, 'CATALOGS_ERROR', 'Não foi possível carregar os cadastros.');
    }
});
router.post('/operations', requireAuth, async (req, res) => {
    const b = req.body || {};
    if (!b.operational_unit_id || !b.vehicle_id)
        return errorResponse(res, 400, 'INVALID_INPUT', 'Unidade e veículo são obrigatórios.');
    try {
        const [result] = await pool.query(`INSERT INTO weighing_operations
      (company_id, operational_unit_id, weighing_station_id, operation_code, movement_type, weighing_method, state, status, vehicle_id, driver_id, rfid_tag_id, cargo_product_id, route_id, responsible_user_id, created_by_user_id, declared_cargo_weight_kg, declared_quantity_unit)
      VALUES (?, ?, ?, NULL, 'WEIGHING_ONLY', ?, 'DRAFT', 'ANALYSIS', ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [req.user.company_id, b.operational_unit_id, b.weighing_station_id || null, ['THREE_STAGE', 'GROSS_TARE'].includes(String(b.weighing_method || 'THREE_STAGE')) ? b.weighing_method : 'THREE_STAGE', b.vehicle_id, b.driver_id || null, b.rfid_tag_id || null, b.cargo_product_id || null, b.route_id || null, req.user.id, req.user.id, b.declared_cargo_weight_kg ?? null, b.declared_quantity_unit || 'KG']);
        const operationId = result.insertId;
        const operation = await getOperationDetail(req.user.company_id, operationId);
        return res.status(201).json(operation);
    }
    catch (error) {
        console.error('operation create', error);
        return errorResponse(res, 400, 'OPERATION_CREATE_ERROR', error?.sqlMessage || error?.message || 'Não foi possível criar a operação.');
    }
});
router.post('/operations/:id/readings', requireAuth, async (req, res) => {
    const b = req.body || {};
    if (!b.stage || b.weight_kg == null)
        return errorResponse(res, 400, 'INVALID_INPUT', 'Etapa e peso são obrigatórios.');
    try {
        const [ops] = await pool.query(`SELECT id FROM weighing_operations WHERE company_id=? AND id=? LIMIT 1`, [req.user.company_id, req.params.id]);
        if (!ops[0])
            return errorResponse(res, 404, 'OPERATION_NOT_FOUND', 'Operação não encontrada.');
        const [seqRows] = await pool.query(`SELECT COALESCE(MAX(sequence_number),0)+1 AS next_seq FROM weighing_readings WHERE company_id=? AND operation_id=? AND stage=?`, [req.user.company_id, req.params.id, String(b.stage).toUpperCase()]);
        const [result] = await pool.query(`INSERT INTO weighing_readings (company_id, operation_id, stage, sequence_number, weight_kg, source, device_id, is_stable, is_accepted, measured_at, manual_reason, created_by_user_id) VALUES (?,?,?,?,? ,?, ?,?,?,?, ?,?)`, [req.user.company_id, req.params.id, String(b.stage).toUpperCase(), Number(seqRows[0]?.next_seq || 1), Number(b.weight_kg), ['DEVICE', 'MANUAL', 'IMPORT'].includes(String(b.source || 'MANUAL').toUpperCase()) ? String(b.source || 'MANUAL').toUpperCase() : 'MANUAL', b.device_id || null, b.is_stable ? 1 : 0, 0, b.measured_at ? new Date(b.measured_at) : new Date(), b.manual_reason || (String(b.source || 'MANUAL').toUpperCase() === 'MANUAL' ? 'Registrada pelo usuário.' : null), req.user.id]);
        return res.status(201).json({ id: String(result.insertId), operation_id: String(req.params.id) });
    }
    catch (error) {
        console.error('reading create', error);
        return errorResponse(res, 400, 'READING_CREATE_ERROR', error?.sqlMessage || error?.message || 'Não foi possível registrar a leitura.');
    }
});
router.post('/operations/:id/readings/:readingId/accept', requireAuth, async (req, res) => {
    try {
        await pool.query(`CALL sp_accept_weighing_reading(?,?,?)`, [req.user.company_id, req.params.readingId, req.user.id]);
        return res.json({ ok: true });
    }
    catch (error) {
        console.error('reading accept', error);
        return errorResponse(res, 400, 'READING_ACCEPT_ERROR', error?.sqlMessage || error?.message || 'Não foi possível aceitar a leitura.');
    }
});
router.post('/operations/:id/finalize', requireAuth, async (req, res) => {
    try {
        await pool.query(`CALL sp_finalize_weighing_operation(?,?,?)`, [req.user.company_id, req.params.id, req.user.id]);
        const operation = await getOperationDetail(req.user.company_id, Number(req.params.id));
        return res.json(operation);
    }
    catch (error) {
        console.error('operation finalize', error);
        return errorResponse(res, 400, 'OPERATION_FINALIZE_ERROR', error?.sqlMessage || error?.message || 'Não foi possível finalizar a operação.');
    }
});
router.post('/operations/:id/cancel', requireAuth, async (req, res) => {
    const reason = String(req.body?.reason || '').trim();
    if (!reason)
        return errorResponse(res, 400, 'INVALID_INPUT', 'Informe o motivo do cancelamento.');
    try {
        const [result] = await pool.query(`UPDATE weighing_operations SET state='CANCELLED', cancelled_at=CURRENT_TIMESTAMP(3), cancelled_by_user_id=?, cancellation_reason=? WHERE company_id=? AND id=? AND state <> 'COMPLETED'`, [req.user.id, reason, req.user.company_id, req.params.id]);
        if (!result.affectedRows)
            return errorResponse(res, 404, 'OPERATION_NOT_FOUND', 'Operação não encontrada ou já concluída.');
        return res.json({ ok: true });
    }
    catch (error) {
        console.error('operation cancel', error);
        return errorResponse(res, 400, 'OPERATION_CANCEL_ERROR', error?.sqlMessage || error?.message || 'Não foi possível cancelar a operação.');
    }
});
router.get('/reports/summary', requireAuth, async (req, res) => {
    const days = String(req.query.period || '30d') === '7d' ? 7 : String(req.query.period || '30d') === '90d' ? 90 : 30;
    try {
        const [summaryRows] = await pool.query(`SELECT COUNT(*) AS operations,
              SUM(state = 'COMPLETED') AS completed,
              COALESCE(SUM(CASE WHEN state = 'COMPLETED' THEN COALESCE(actual_cargo_weight_kg,0) ELSE 0 END),0) AS cargo_kg,
              COALESCE(AVG(CASE WHEN state = 'COMPLETED' AND difference_percent IS NOT NULL THEN GREATEST(0, 100 - ABS(difference_percent)) END),0) AS efficiency,
              SUM(status IN ('ATTENTION','CRITICAL')) AS divergences,
              SUM(status = 'NORMAL') AS normal_count,
              SUM(status = 'ATTENTION') AS attention_count,
              SUM(status = 'CRITICAL') AS critical_count,
              SUM(status = 'ANALYSIS') AS analysis_count,
              COALESCE(AVG(CASE WHEN departed_at IS NOT NULL AND arrived_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE, departed_at, arrived_at) / 60 END),0) AS trip_hours
         FROM weighing_operations
        WHERE company_id = ? AND started_at >= UTC_TIMESTAMP() - INTERVAL ? DAY`, [req.user.company_id, days]);
        const s = summaryRows[0] || {};
        const [performanceRows] = await pool.query(`SELECT DATE(COALESCE(completed_at, started_at)) AS ref_date,
              GREATEST(0, 100 - COALESCE(AVG(ABS(difference_percent)),0)) AS efficiency
         FROM weighing_operations
        WHERE company_id = ? AND started_at >= UTC_TIMESTAMP() - INTERVAL ? DAY
        GROUP BY DATE(COALESCE(completed_at, started_at)) ORDER BY ref_date ASC LIMIT 31`, [req.user.company_id, days]);
        const [distributionRows] = await pool.query(`SELECT COALESCE(cp.name, 'Outros') AS label, COALESCE(SUM(COALESCE(o.actual_cargo_weight_kg,0)),0) AS cargo_kg
         FROM weighing_operations o
         LEFT JOIN cargo_products cp ON cp.company_id = o.company_id AND cp.id = o.cargo_product_id
        WHERE o.company_id = ? AND o.state = 'COMPLETED' AND o.started_at >= UTC_TIMESTAMP() - INTERVAL ? DAY
        GROUP BY COALESCE(cp.name, 'Outros') ORDER BY cargo_kg DESC LIMIT 4`, [req.user.company_id, days]);
        const total = distributionRows.reduce((n, r) => n + Number(r.cargo_kg || 0), 0);
        const palette = ['#FF5B1F', '#22C55E', '#EAB308', '#64748B'];
        res.json({
            summary: {
                operations: Number(s.operations || 0), completed: Number(s.completed || 0), cargoTons: Number((Number(s.cargo_kg || 0) / 1000).toFixed(1)),
                averageEfficiency: Number(Number(s.efficiency || 0).toFixed(1)), divergences: Number(s.divergences || 0), normal: Number(s.normal_count || 0), attention: Number(s.attention_count || 0), critical: Number(s.critical_count || 0), analysis: Number(s.analysis_count || 0), averageTripHours: Number(Number(s.trip_hours || 0).toFixed(1)),
            },
            performance: performanceRows.map((r) => Number(Number(r.efficiency || 0).toFixed(1))),
            cargoDistribution: distributionRows.map((r, i) => ({ label: r.label, percentage: total ? Number((Number(r.cargo_kg) / total * 100).toFixed(1)) : 0, color: palette[i] })),
        });
    }
    catch (error) {
        console.error('report summary', error);
        return errorResponse(res, 500, 'REPORTS_ERROR', 'Não foi possível carregar o resumo dos relatórios.');
    }
});
router.get('/reports', requireAuth, async (req, res) => {
    try {
        const [rows] = await pool.query(`SELECT id, report_type, period_start, period_end, generated_at FROM generated_reports WHERE company_id = ? ORDER BY generated_at DESC LIMIT 100`, [req.user.company_id]);
        res.json(rows.map((r) => ({ id: String(r.id), title: `Relatório ${r.report_type}`, period: `${r.period_start} a ${r.period_end}`, generatedAt: r.generated_at, type: r.report_type })));
    }
    catch (error) {
        console.error('reports', error);
        return errorResponse(res, 500, 'REPORTS_ERROR', 'Não foi possível carregar os relatórios.');
    }
});
router.post('/reports', requireAuth, async (req, res) => {
    const days = String(req.body?.period || '30d') === '7d' ? 7 : String(req.body?.period || '30d') === '90d' ? 90 : 30;
    try {
        const [result] = await pool.query(`INSERT INTO generated_reports (company_id, report_type, period_start, period_end, generated_by_user_id, file_format, filters_json)
       VALUES (?, 'CUSTOM', UTC_DATE() - INTERVAL ? DAY, UTC_DATE(), ?, 'PDF', ?)`, [req.user.company_id, days - 1, req.user.id, JSON.stringify(req.body?.filters || {})]);
        return res.status(202).json({ id: String(result.insertId), state: 'PENDING' });
    }
    catch (error) {
        console.error('report create', error);
        return errorResponse(res, 500, 'REPORT_GENERATION_ERROR', 'Não foi possível solicitar o relatório.');
    }
});
router.get('/system/status', requireAuth, async (req, res) => {
    try {
        const [rows] = await pool.query(`SELECT COUNT(*) AS total, SUM(state = 'ONLINE') AS online FROM devices WHERE company_id = ? AND active = 1`, [req.user.company_id]);
        const row = rows[0] || {};
        res.json({ database: { state: 'ONLINE', engine: 'MySQL 8' }, devices: { total: Number(row.total || 0), online: Number(row.online || 0) }, api: { state: 'ONLINE', version: 'v1' }, timestamp: nowIso() });
    }
    catch (error) {
        console.error('system status', error);
        return errorResponse(res, 500, 'SYSTEM_STATUS_ERROR', 'Não foi possível consultar o status do sistema.');
    }
});
app.use(API_PREFIX, router);
app.use((err, _req, res, _next) => {
    console.error('unhandled', err);
    if (err?.message === 'CORS origin not allowed')
        return errorResponse(res, 403, 'CORS_FORBIDDEN', 'Origem não autorizada.');
    return errorResponse(res, 500, 'INTERNAL_ERROR', 'Erro interno do servidor.');
});
const server = app.listen(PORT, () => console.log(`LoadSense API: http://localhost:${PORT}${API_PREFIX}`));
process.on('SIGTERM', async () => { server.close(); await pool.end(); });
process.on('SIGINT', async () => { server.close(); await pool.end(); });
