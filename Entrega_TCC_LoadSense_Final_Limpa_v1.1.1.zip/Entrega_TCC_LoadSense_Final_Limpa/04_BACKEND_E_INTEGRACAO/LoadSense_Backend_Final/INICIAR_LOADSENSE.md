# Iniciar o LoadSense integrado

1. Instale Node.js 20+.
2. No MySQL, importe `loadsense_mysql8_v3_final.sql` e depois `migrations/001_api_support.sql`.
3. Copie `.env.example` para `.env` e informe as credenciais do MySQL e um `JWT_SECRET` forte.
4. Entre na pasta do backend e execute `npm install`.
5. Crie o primeiro administrador:

`npm run create-admin -- loadsense-demo admin@loadsense.local "SUA_SENHA" "Administrador LoadSense"`

6. Execute `npm start`.
7. Abra `http://localhost:3333/`.

O mesmo backend atende o app mobile em `/api/v1`. Para Android Emulator, o app deve usar `http://10.0.2.2:3333/api/v1`; para celular físico, use o IP LAN do servidor.

Observação: o banco original não cria usuário padrão; o administrador deve ser criado explicitamente.
