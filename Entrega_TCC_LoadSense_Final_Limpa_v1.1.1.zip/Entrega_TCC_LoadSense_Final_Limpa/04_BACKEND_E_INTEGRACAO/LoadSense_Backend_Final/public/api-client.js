(function () {
    'use strict';
    window.LOADSENSE_REMOTE_DATA = true;
    function getConfiguredBase() {
        const meta = document.querySelector('meta[name="loadsense-api-url"]');
        const configured = meta && meta.content ? meta.content.trim() : '';
        const stored = localStorage.getItem('loadsense_api_url') || '';
        if (configured)
            return configured.replace(/\/$/, '');
        if (stored)
            return stored.replace(/\/$/, '');
        if (window.location.protocol !== 'file:' && (!window.location.port || window.location.port === '3333')) {
            return `${window.location.origin}/api/v1`;
        }
        return 'http://localhost:3333/api/v1';
    }
    const API_BASE = getConfiguredBase();
    let accessToken = null;
    let refreshPromise = null;
    function parseJson(text) {
        if (!text)
            return null;
        try {
            return JSON.parse(text);
        }
        catch (_) {
            return null;
        }
    }
    class LoadSenseApiError extends Error {
        constructor(message, status, code) {
            super(message);
            this.name = 'LoadSenseApiError';
            this.status = status;
            this.code = code;
        }
    }
    async function raw(path, options) {
        const opts = options || {};
        const headers = new Headers(opts.headers || {});
        headers.set('Accept', 'application/json');
        if (opts.body && !headers.has('Content-Type'))
            headers.set('Content-Type', 'application/json');
        const response = await fetch(`${API_BASE}${path}`, { ...opts, headers });
        if (response.status === 204)
            return null;
        const text = await response.text();
        const payload = parseJson(text);
        if (!response.ok) {
            throw new LoadSenseApiError(payload && payload.error && payload.error.message ? payload.error.message : 'Não foi possível concluir a solicitação.', response.status, payload && payload.error ? payload.error.code : undefined);
        }
        return payload;
    }
    async function refresh() {
        if (refreshPromise)
            return refreshPromise;
        const token = localStorage.getItem('loadsense_refresh_token');
        if (!token)
            return false;
        refreshPromise = (async () => {
            try {
                const result = await raw('/auth/refresh', { method: 'POST', body: JSON.stringify({ refresh_token: token }) });
                accessToken = result.access_token;
                localStorage.setItem('loadsense_refresh_token', result.refresh_token);
                localStorage.setItem('loadsense_usuario', JSON.stringify({
                    id: result.user.id, email: result.user.email, nome: result.user.name, perfil: result.user.role,
                    company: result.company, permissions: result.permissions, termsAccepted: result.terms_accepted
                }));
                return true;
            }
            catch (_) {
                accessToken = null;
                localStorage.removeItem('loadsense_refresh_token');
                localStorage.removeItem('loadsense_usuario');
                return false;
            }
        })();
        try {
            return await refreshPromise;
        }
        finally {
            refreshPromise = null;
        }
    }
    async function request(path, options, authenticated = true, retry = true) {
        const opts = { ...(options || {}) };
        const headers = new Headers(opts.headers || {});
        if (authenticated && accessToken)
            headers.set('Authorization', `Bearer ${accessToken}`);
        opts.headers = headers;
        try {
            return await raw(path, opts);
        }
        catch (error) {
            if (authenticated && retry && error instanceof LoadSenseApiError && error.status === 401) {
                if (await refresh())
                    return request(path, options, true, false);
            }
            throw error;
        }
    }
    function storeSession(result) {
        accessToken = result.access_token;
        localStorage.setItem('loadsense_refresh_token', result.refresh_token);
        localStorage.setItem('loadsense_usuario', JSON.stringify({
            id: result.user.id, email: result.user.email, nome: result.user.name, perfil: result.user.role,
            company: result.company, permissions: result.permissions, termsAccepted: result.terms_accepted
        }));
        return result;
    }
    async function resume() {
        if (accessToken)
            return true;
        return refresh();
    }
    const api = {
        baseUrl: API_BASE,
        setBaseUrl(url) {
            if (!url)
                return;
            localStorage.setItem('loadsense_api_url', String(url).replace(/\/$/, ''));
        },
        getAccessToken: () => accessToken,
        resume,
        async login(companyCode, email, password) {
            const result = await raw('/auth/login', { method: 'POST', body: JSON.stringify({ company_code: companyCode, email, password, device: { platform: 'WEB', app_version: '1.0.0' } }) });
            return storeSession(result);
        },
        async logout() {
            const token = localStorage.getItem('loadsense_refresh_token');
            try {
                if (token)
                    await raw('/auth/logout', { method: 'POST', body: JSON.stringify({ refresh_token: token }) });
            }
            finally {
                accessToken = null;
                localStorage.removeItem('loadsense_refresh_token');
                localStorage.removeItem('loadsense_usuario');
            }
        },
        forgotPassword(companyCode, email) {
            return raw('/auth/password/forgot', { method: 'POST', body: JSON.stringify({ company_code: companyCode, email }) });
        },
        requestCompany(data) {
            return raw('/company-requests', { method: 'POST', body: JSON.stringify(data) });
        },
        me: () => request('/me'),
        acceptTerms: () => request('/me/legal-acceptances', { method: 'POST', body: JSON.stringify({}) }),
        dashboard: () => request('/dashboard'),
        operations(search = '', state = '') { return request(`/operations?search=${encodeURIComponent(search)}&state=${encodeURIComponent(state)}`); },
        operation(id) { return request(`/operations/${encodeURIComponent(id)}`); },
        monitoring(search = '') { return request(`/monitoring/operations?search=${encodeURIComponent(search)}`); },
        alerts(state = '') { return request(`/alerts?state=${encodeURIComponent(state)}`); },
        updateAlert(id, state, resolutionNotes = '') { return request(`/alerts/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ state, resolution_notes: resolutionNotes }) }); },
        settings: () => request('/settings'),
        updateSettings(data) { return request('/settings', { method: 'PATCH', body: JSON.stringify(data) }); },
        catalogs: () => request('/catalogs'),
        createOperation(data) { return request('/operations', { method: 'POST', body: JSON.stringify(data) }); },
        addReading(id, data) { return request(`/operations/${encodeURIComponent(id)}/readings`, { method: 'POST', body: JSON.stringify(data) }); },
        acceptReading(id, readingId) { return request(`/operations/${encodeURIComponent(id)}/readings/${encodeURIComponent(readingId)}/accept`, { method: 'POST', body: JSON.stringify({}) }); },
        finalizeOperation(id) { return request(`/operations/${encodeURIComponent(id)}/finalize`, { method: 'POST', body: JSON.stringify({}) }); },
        cancelOperation(id, reason) { return request(`/operations/${encodeURIComponent(id)}/cancel`, { method: 'POST', body: JSON.stringify({ reason }) }); },
        reports(period) { return request(`/reports/summary?period=${encodeURIComponent(period)}`); },
        reportItems: () => request('/reports'),
        createReport(period) { return request('/reports', { method: 'POST', body: JSON.stringify({ period }) }); },
        systemStatus: () => request('/system/status')
    };
    window.LoadSenseAPI = api;
    window.LoadSenseApiError = LoadSenseApiError;
    window.LoadSenseApiReady = Promise.resolve(api);
})();
