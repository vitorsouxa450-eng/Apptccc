(function () {
    'use strict';
    const API = () => window.LoadSenseAPI;
    const path = window.location.pathname.toLowerCase();
    const file = path.split('/').pop();
    const publicPages = ['login.html', 'cadastro.html'];
    function escapeHtml(value) {
        return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
    }
    function fmtKg(v) { return `${Number(v || 0).toLocaleString('pt-BR', { maximumFractionDigits: 0 })} kg`; }
    function fmtDate(v) { if (!v)
        return '—'; const d = new Date(String(v).replace(' ', 'T') + (String(v).includes('Z') ? '' : 'Z')); return isNaN(d) ? String(v) : d.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }); }
    function statusClass(status) { return status === 'Crítico' ? 'status-critical' : status === 'Atenção' ? 'status-atencao' : status === 'Normal' ? 'status-normal' : ''; }
    function toast(message) {
        const el = document.getElementById('toast') || document.getElementById('toastText');
        if (!el)
            return;
        if ('toastText' === el.id)
            el.textContent = message;
        else
            el.textContent = message;
        el.classList.add('show');
        setTimeout(() => el.classList.remove('show'), 2800);
    }
    function redirectLogin() { const login = file === 'dashboard.html' || file === 'planilha.html' || file === 'historico.html' || file === 'alertas.html' || file === 'monitoramento.html' || file === 'configuracoes.html' || file === 'novapesagem.html' || file === 'relatorios.html'; if (login)
        window.location.href = '../Login/Login.html'; }
    function applyUserToPage() {
        try {
            const user = JSON.parse(localStorage.getItem('loadsense_usuario') || '{}');
            document.querySelectorAll('.profile-name').forEach(el => { if (user.nome)
                el.textContent = user.nome; });
            document.querySelectorAll('.profile-role').forEach(el => { if (user.perfil)
                el.textContent = user.perfil; });
            document.querySelectorAll('.avatar').forEach(el => {
                if (!user.nome)
                    return;
                const parts = String(user.nome).trim().split(/\s+/);
                el.textContent = (parts[0]?.[0] || '') + (parts.at(-1)?.[0] || '');
                el.textContent = el.textContent.toUpperCase();
            });
        }
        catch (_) { }
    }
    async function requireSession() {
        if (publicPages.includes(file))
            return true;
        const ok = await API().resume();
        if (!ok) {
            redirectLogin();
            return false;
        }
        applyUserToPage();
        return true;
    }
    async function initCadastro() {
        const form = document.getElementById('cadastroForm');
        if (!form || !API())
            return;
        let documentInput = document.getElementById('documentoEmpresa');
        if (!documentInput) {
            const empresa = document.getElementById('empresa');
            const wrapper = empresa ? empresa.closest('.form-group') : null;
            if (wrapper && wrapper.parentElement) {
                const group = document.createElement('div');
                group.className = 'form-group';
                group.innerHTML = '<label for="documentoEmpresa">CNPJ da empresa</label><div class="input-wrapper"><input type="text" id="documentoEmpresa" name="documentoEmpresa" placeholder="00.000.000/0000-00" autocomplete="organization"></div><small class="error-message" id="documentoEmpresaError"></small>';
                wrapper.parentElement.insertBefore(group, wrapper.nextSibling);
                documentInput = document.getElementById('documentoEmpresa');
            }
        }
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            const nome = document.getElementById('nome')?.value.trim() || '';
            const empresa = document.getElementById('empresa')?.value.trim() || '';
            const email = document.getElementById('email')?.value.trim() || '';
            const accepted = document.getElementById('aceitarTermos')?.checked === true;
            const documentNumber = documentInput?.value.trim() || '';
            if (!nome || !empresa || !email || !documentNumber || !accepted) {
                toast('Preencha nome, empresa, CNPJ, e-mail e aceite o aviso de privacidade.');
                return;
            }
            const button = document.getElementById('cadastroButton');
            if (button) {
                button.disabled = true;
                button.textContent = 'Enviando solicitação...';
            }
            try {
                const result = await API().requestCompany({ legal_name: empresa, document: documentNumber, responsible_name: nome, email, phone: null, accepted_privacy: true });
                toast(`Solicitação enviada: ${result.requestId}`);
                setTimeout(() => { window.location.href = '../Login/Login.html'; }, 1200);
            }
            catch (e) {
                toast(e.message || 'Não foi possível enviar a solicitação.');
                if (button) {
                    button.disabled = false;
                    button.textContent = 'Criar conta →';
                }
            }
        }, { once: true });
    }
    async function initLogin() {
        const form = document.getElementById('loginForm');
        if (!form || !API())
            return;
        let company = document.getElementById('companyCode');
        if (!company) {
            const email = document.getElementById('email');
            const wrapper = email ? email.closest('.form-group') || email.parentElement : null;
            if (wrapper) {
                const label = document.createElement('label');
                label.setAttribute('for', 'companyCode');
                label.textContent = 'Código da empresa';
                const input = document.createElement('input');
                input.id = 'companyCode';
                input.name = 'companyCode';
                input.type = 'text';
                input.autocomplete = 'organization';
                input.placeholder = 'Ex.: loadsense-demo';
                wrapper.parentElement.insertBefore(label, wrapper);
                wrapper.parentElement.insertBefore(input, wrapper);
            }
            company = document.getElementById('companyCode');
        }
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            const email = document.getElementById('email')?.value.trim() || '';
            const password = document.getElementById('senha')?.value || '';
            const companyCode = company?.value.trim() || 'loadsense-demo';
            const button = document.getElementById('loginButton');
            if (!email || !password || !companyCode)
                return;
            if (button) {
                button.disabled = true;
                button.dataset.old = button.textContent;
                button.textContent = 'Entrando...';
            }
            try {
                const session = await API().login(companyCode, email, password);
                if (session.terms_accepted)
                    window.location.href = '../Dashboard/Dashboard.html';
                else
                    window.location.href = '../Configuracoes/Configuracoes.html';
            }
            catch (e) {
                toast(e.message || 'Não foi possível entrar.');
                if (button) {
                    button.disabled = false;
                    button.textContent = button.dataset.old || 'Entrar';
                }
            }
        }, { once: true });
        const forgot = document.getElementById('forgotPassword');
        forgot?.addEventListener('click', async (event) => {
            event.preventDefault();
            const email = document.getElementById('email')?.value.trim() || '';
            const companyCode = company?.value.trim() || 'loadsense-demo';
            if (!email)
                return toast('Informe o e-mail para recuperar o acesso.');
            try {
                await API().forgotPassword(companyCode, email);
                toast('Se a conta existir, as instruções de recuperação serão enviadas.');
            }
            catch (e) {
                toast(e.message);
            }
        }, { once: true });
    }
    async function initDashboard() {
        const data = await API().dashboard();
        const metrics = document.querySelectorAll('.metric-card .metric-value');
        const values = data.metrics || [];
        if (metrics[0])
            metrics[0].textContent = Number((values.find(x => x.id === 'trips')?.value ?? 0)).toLocaleString('pt-BR');
        if (metrics[1])
            metrics[1].textContent = `${Number((values.find(x => x.id === 'tons')?.value ?? 0)).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} t`;
        if (metrics[2])
            metrics[2].textContent = Number((values.find(x => x.id === 'alerts')?.value ?? 0)).toLocaleString('pt-BR');
        if (metrics[3]) {
            const normal = Number((data.metrics || []).find(x => x.id === 'normal_percent')?.value ?? 0);
            metrics[3].textContent = normal ? `${normal.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}%` : '—';
        }
        const list = document.getElementById('operationsList');
        if (list) {
            const ops = await API().operations('', '');
            list.innerHTML = ops.slice(0, 10).map(o => `<div class="operation-row" data-search="${escapeHtml([o.code, o.plate, o.driver, o.cargo].join(' '))}" data-operation-id="${escapeHtml(o.id)}"><span class="operation-id">${escapeHtml(o.code)}</span><span class="operation-date">${escapeHtml(fmtDate(o.scheduledAt))}</span><span class="plate">${escapeHtml(o.plate)}</span><span class="driver">${escapeHtml(o.driver)}</span><span class="weight">${escapeHtml(fmtKg(o.currentWeightTons * 1000))}</span><span class="status-badge ${statusClass(o.status)}">${escapeHtml(o.status)}</span></div>`).join('') || '<div class="no-results" style="display:block">Nenhuma operação registrada.</div>';
            list.querySelectorAll('.operation-row').forEach(row => row.addEventListener('click', () => { if (row.dataset.operationId)
                window.location.href = `../Historico/Historico.html?operation=${encodeURIComponent(row.dataset.operationId)}`; }));
        }
        const date = document.querySelector('.date-label');
        if (date)
            date.textContent = `Atualizado em ${new Date().toLocaleString('pt-BR')}`;
    }
    async function initOperationsTable() {
        const tbody = document.getElementById('tableBody');
        if (!tbody)
            return;
        const ops = await API().operations('', '');
        tbody.innerHTML = ops.map(o => {
            const actual = Number(o.currentWeightTons || 0) * 1000;
            return `<tr data-operation-id="${escapeHtml(o.id)}"><td>${escapeHtml(o.code)}</td><td>${escapeHtml(fmtDate(o.scheduledAt))}</td><td>${escapeHtml(o.plate)}</td><td>${escapeHtml(o.driver)}</td><td>${escapeHtml(o.rfidTag)}</td><td>${escapeHtml(fmtKg(actual))}</td><td>${escapeHtml(o.status)}</td></tr>`;
        }).join('') || `<tr><td colspan="7">Nenhuma operação registrada.</td></tr>`;
        document.getElementById('operationCounter')?.replaceChildren(document.createTextNode(`${ops.length} operações`));
    }
    async function initAlerts() {
        const container = document.getElementById('alertsContainer');
        if (!container)
            return;
        const alerts = await API().alerts();
        container.innerHTML = alerts.map(a => `<article class="alert-card" data-alert-id="${escapeHtml(a.id)}" data-search="${escapeHtml([a.title, a.operation_code, a.plate, a.driver, a.cargo, a.message].join(' '))}"><div><span class="alert-level ${a.severity === 'CRITICAL' ? 'critical' : 'warning'}">${a.severity === 'CRITICAL' ? 'Crítico' : 'Atenção'}</span><h3>${escapeHtml(a.title)}</h3><p>${escapeHtml(a.message)}</p><small>${escapeHtml(a.operation_code || '')} · ${escapeHtml(fmtDate(a.created_at))}</small></div><div class="alert-actions"><button type="button" data-ack="${escapeHtml(a.id)}">${a.state === 'ACKNOWLEDGED' ? 'Resolver' : 'Reconhecer'}</button></div></article>`).join('') || '<p>Nenhum alerta ativo.</p>';
        container.querySelectorAll('[data-ack]').forEach(btn => btn.addEventListener('click', async () => {
            const id = btn.dataset.ack;
            const current = alerts.find(a => String(a.id) === String(id));
            if (!current)
                return;
            try {
                await API().updateAlert(id, current.state === 'ACKNOWLEDGED' ? 'RESOLVED' : 'ACKNOWLEDGED', current.state === 'ACKNOWLEDGED' ? 'Resolvido pelo painel web.' : 'Reconhecido pelo painel web.');
                await initAlerts();
                toast('Alerta atualizado.');
            }
            catch (e) {
                toast(e.message);
            }
        }));
        const counter = document.querySelector('.notification-count') || document.querySelector('.alert-count');
        if (counter)
            counter.textContent = String(alerts.length);
    }
    async function initHistory() {
        const list = document.getElementById('historyList');
        if (!list)
            return;
        const ops = await API().operations('', 'COMPLETED');
        list.innerHTML = ops.map(o => `<article class="history-item" data-operation-id="${escapeHtml(o.id)}" data-search="${escapeHtml([o.code, o.plate, o.driver, o.cargo, o.status].join(' '))}"><div><strong>${escapeHtml(o.code)}</strong><span>${escapeHtml(fmtDate(o.scheduledAt))}</span></div><div><b>${escapeHtml(o.plate)}</b><span>${escapeHtml(o.driver)}</span></div><div><b>${escapeHtml(fmtKg(o.currentWeightTons * 1000))}</b><span>${escapeHtml(o.status)}</span></div></article>`).join('') || '<p>Nenhuma operação concluída.</p>';
    }
    async function initMonitoring() {
        const apiOps = await API().monitoring();
        window.LoadSenseMonitoringData = apiOps.map(o => ({ id: o.id, plate: o.plate, status: o.trackingState === 'STOPPED' ? 'Parado' : o.trackingState === 'ARRIVED' ? 'Chegou' : 'Em trânsito', driver: o.driver, from: o.origin, to: o.destination, eta: o.estimatedArrival, remaining: `${Math.max(0, 100 - Number(o.progress || 0)).toFixed(0)}% restante`, progress: Number(o.progress || 0), current: o.currentLatitude != null && o.currentLongitude != null ? [Number(o.currentLatitude), Number(o.currentLongitude)] : null, start: null, end: null }));
        window.dispatchEvent(new CustomEvent('loadsense:monitoring-data', { detail: window.LoadSenseMonitoringData }));
    }
    async function initReports() {
        const periodMap = { semanal: '7d', mensal: '30d', bimestral: '30d', trimestral: '90d' };
        const cards = document.querySelectorAll('.report-card');
        async function load(period) {
            const data = await API().reports(periodMap[period] || '30d');
            const title = document.getElementById('reportTitle');
            if (title)
                title.textContent = cards[0] ? (cards[0].classList.contains('active') ? 'Relatório Atual' : title.textContent) : title.textContent;
            const rows = document.querySelectorAll('.status-table .table-row');
            const total = Number(data.summary?.operations || 0);
            const vals = [total - Number(data.summary?.divergences || 0), Math.round(Number(data.summary?.divergences || 0) * 0.55), Math.round(Number(data.summary?.divergences || 0) * 0.45), 0];
            rows.forEach((row, i) => { const strong = row.querySelector('strong'); if (strong)
                strong.textContent = Number(vals[i] || 0).toLocaleString('pt-BR'); });
        }
        cards.forEach((card, idx) => card.addEventListener('click', () => { cards.forEach(c => c.classList.remove('active')); card.classList.add('active'); load(['semanal', 'mensal', 'bimestral', 'trimestral'][idx]); }));
        await load('semanal');
    }
    async function initSettings() {
        const tolerance = document.getElementById('weightTolerance');
        const overload = document.getElementById('overloadLimit');
        const unit = document.getElementById('weightUnit');
        if (!tolerance && !overload && !unit)
            return;
        const data = await API().settings();
        if (tolerance)
            tolerance.value = data.tolerance_percent ?? tolerance.value;
        if (overload)
            overload.value = data.critical_limit_percent ?? overload.value;
        if (unit)
            unit.value = data.default_weight_unit ?? unit.value;
        [tolerance, overload, unit].filter(Boolean).forEach(el => el.addEventListener('change', async () => {
            try {
                await API().updateSettings({ tolerance_percent: Number(tolerance?.value || 1.5), critical_limit_percent: Number(overload?.value || 3), default_weight_unit: unit?.value || 'KG' });
                localStorage.setItem('loadsense_configuracoes', JSON.stringify({ weightTolerance: tolerance?.value, overloadLimit: overload?.value, weightUnit: unit?.value }));
                toast('Configuração salva no servidor.');
            }
            catch (e) {
                toast(e.message);
            }
        }));
        const test = document.getElementById('testConnection');
        test?.addEventListener('click', async () => { try {
            const s = await API().systemStatus();
            toast(`API ${s.api.state} · Banco ${s.database.state}`);
        }
        catch (e) {
            toast(e.message);
        } });
    }
    async function initNewWeighing() {
        const register = document.getElementById('registerButton');
        if (!register)
            return;
        register.addEventListener('click', async (event) => {
            event.preventDefault();
            const plate = document.getElementById('plate')?.value.trim();
            const driverName = document.getElementById('driver')?.value.trim();
            const rfid = document.getElementById('rfid')?.value.trim();
            const origin = document.getElementById('origin')?.value.trim();
            const destination = document.getElementById('destination')?.value.trim();
            const cargoName = document.getElementById('cargoType')?.value.trim();
            const empty = Number((document.getElementById('emptyWeight')?.value || '').replace(/[^0-9.,-]/g, '').replace('.', '').replace(',', '.'));
            const cargo = Number((document.getElementById('cargoWeight')?.value || '').replace(/[^0-9.,-]/g, '').replace('.', '').replace(',', '.'));
            const loaded = Number((document.getElementById('loadedWeight')?.value || '').replace(/[^0-9.,-]/g, '').replace('.', '').replace(',', '.'));
            if (!plate || empty <= 0 || cargo <= 0 || loaded <= 0)
                return toast('Preencha veículo e os três pesos.');
            if (Math.abs(loaded - (empty + cargo)) > 0.001)
                return toast('Os pesos não conferem.');
            try {
                const cats = await API().catalogs();
                const vehicle = cats.vehicles.find(v => String(v.plate).toUpperCase() === plate.toUpperCase());
                if (!vehicle)
                    throw new Error('Veículo não encontrado no cadastro.');
                const driver = driverName ? cats.drivers.find(d => d.full_name.toLowerCase() === driverName.toLowerCase()) : null;
                const tag = rfid ? cats.rfid_tags.find(t => t.code.toLowerCase() === rfid.toLowerCase()) : null;
                const product = cargoName ? cats.cargo_products.find(p => p.name.toLowerCase() === cargoName.toLowerCase()) : null;
                const route = cats.routes.find(r => r.origin.toLowerCase() === origin.toLowerCase() && r.destination.toLowerCase() === destination.toLowerCase());
                const unit = cats.operational_units[0];
                if (!unit)
                    throw new Error('Nenhuma unidade operacional cadastrada.');
                const op = await API().createOperation({ operational_unit_id: unit.id, vehicle_id: vehicle.id, driver_id: driver?.id || null, rfid_tag_id: tag?.id || null, cargo_product_id: product?.id || null, route_id: route?.id || null, responsible_user_id: JSON.parse(localStorage.getItem('loadsense_usuario') || '{}').id, weighing_method: 'THREE_STAGE', declared_cargo_weight_kg: cargo, declared_quantity_unit: 'KG' });
                for (const item of [{ stage: 'EMPTY_TRUCK', weight_kg: empty }, { stage: 'SEPARATED_CARGO', weight_kg: cargo }, { stage: 'LOADED_TRUCK', weight_kg: loaded }]) {
                    const reading = await API().addReading(op.id, { ...item, source: 'MANUAL', is_stable: 1, measured_at: new Date().toISOString(), manual_reason: 'Registrada pelo operador no painel web.' });
                    await API().acceptReading(op.id, reading.id);
                }
                await API().finalizeOperation(op.id);
                toast('Pesagem registrada no banco de dados.');
                setTimeout(() => { window.location.href = '../Dashboard/Dashboard.html'; }, 900);
            }
            catch (e) {
                toast(e.message || 'Não foi possível registrar a pesagem.');
            }
        });
    }
    document.addEventListener('DOMContentLoaded', async () => {
        if (!publicPages.includes(file)) {
            const ok = await requireSession();
            if (!ok)
                return;
        }
        try {
            if (file === 'login.html')
                await initLogin();
            else if (file === 'cadastro.html')
                await initCadastro();
            else if (file === 'dashboard.html')
                await initDashboard();
            else if (file === 'planilha.html')
                await initOperationsTable();
            else if (file === 'alertas.html')
                await initAlerts();
            else if (file === 'historico.html')
                await initHistory();
            else if (file === 'monitoramento.html')
                await initMonitoring();
            else if (file === 'configuracoes.html')
                await initSettings();
            else if (file === 'novapesagem.html')
                await initNewWeighing();
        }
        catch (error) {
            console.error('LoadSense integration error:', error);
            if (error && error.status === 401)
                redirectLogin();
            else
                toast(error.message || 'Não foi possível carregar os dados do servidor.');
        }
    });
})();
