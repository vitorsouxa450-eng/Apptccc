# LoadSense Backend / API v1

Ponte única entre MySQL, aplicativo e site. Os clientes não acessam o MySQL diretamente.

## Instalação

1. Importe `loadsense_mysql8_v3_final.sql`.
2. Execute `migrations/001_api_support.sql`.
3. Crie o usuário MySQL da API com permissões apenas no schema `loadsense`.
4. Copie `.env.example` para `.env` e ajuste os valores.
5. Execute `npm install`.
6. Crie o primeiro administrador:

```bash
npm run create-admin -- loadsense-demo admin@loadsense.com "SuaSenhaForte" "Administrador LoadSense"
```

7. Inicie:

```bash
npm run dev
```

API: `http://localhost:3333/api/v1`

## Endpoints

`/health`, `/app/bootstrap`, `/auth/login`, `/auth/refresh`, `/auth/logout`, `/auth/password/forgot`, `/company-requests`, `/me`, `/me/legal-acceptances`, `/dashboard`, `/operations`, `/operations/:id`, `/monitoring/operations`, `/reports/summary`, `/reports`, `POST /reports`, `/system/status`.

## Segurança

JWT de curta duração; refresh tokens aleatórios e rotativos armazenados como SHA-256; bcrypt; isolamento por `company_id`; bloqueio temporário de login; HTTPS e CORS restrito em produção.

## Observações

O SQL do projeto deliberadamente não cria uma senha padrão. A extensão cria as duas tabelas necessárias para completar o fluxo de solicitação de empresa e recuperação de acesso.

O endpoint de recuperação cria e armazena o token de forma segura, mas o envio do e-mail depende de um provedor transacional que ainda não faz parte dos arquivos entregues.

A solicitação `POST /reports` registra a geração como `PENDING`; um worker/serviço de geração de PDF e armazenamento do arquivo ainda precisa ser conectado quando o provedor de relatórios estiver definido.

O painel web não foi enviado nesta conversa. O backend já fica compartilhado entre web e mobile; a adaptação do site deve apontar para a mesma base `/api/v1`.


## Web

O site HTML integrado fica em `public/` e é servido pelo mesmo processo da API. Depois de iniciar o backend, abra `http://localhost:3333/`.

Para hospedar o site separadamente, configure `localStorage.loadsense_api_url` para a URL completa da API, por exemplo `https://api.seudominio.com/api/v1`.

O site usa o mesmo login, sessão, empresas, operações, alertas, configurações, relatórios e catálogo do aplicativo.
