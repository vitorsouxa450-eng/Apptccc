
USE loadsense;

CREATE TABLE IF NOT EXISTS company_requests (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    legal_name          VARCHAR(180) NOT NULL,
    document_number     VARCHAR(20) NOT NULL,
    responsible_name    VARCHAR(140) NOT NULL,
    email               VARCHAR(160) NOT NULL,
    phone               VARCHAR(30) NULL,
    privacy_accepted    TINYINT(1) NOT NULL DEFAULT 0,
    status              ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_company_requests_status_date (status, created_at),
    KEY idx_company_requests_document (document_number),
    CONSTRAINT chk_company_requests_privacy CHECK (privacy_accepted IN (0,1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    user_id             BIGINT UNSIGNED NOT NULL,
    token_hash          CHAR(64) NOT NULL,
    expires_at          DATETIME(3) NOT NULL,
    used_at             DATETIME(3) NULL,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_password_reset_token_hash (token_hash),
    KEY idx_password_reset_user_expiry (company_id, user_id, expires_at),
    CONSTRAINT fk_password_reset_user
        FOREIGN KEY (company_id, user_id)
        REFERENCES users(company_id, id)
        ON DELETE CASCADE
) ENGINE=InnoDB;
