

CREATE DATABASE IF NOT EXISTS loadsense
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

USE loadsense;

SET NAMES utf8mb4;

SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS companies (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    legal_name          VARCHAR(180) NOT NULL,
    trade_name          VARCHAR(140) NOT NULL,
    document_number     VARCHAR(20) NULL,
    slug                VARCHAR(80) NOT NULL,
    email               VARCHAR(160) NULL,
    phone               VARCHAR(30) NULL,
    timezone_name       VARCHAR(60) NOT NULL DEFAULT 'America/Sao_Paulo',
    active              TINYINT(1) NOT NULL DEFAULT 1,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                      ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_companies_slug (slug),
    UNIQUE KEY uq_companies_document (document_number),
    CONSTRAINT chk_companies_active CHECK (active IN (0, 1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS operational_units (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    code                VARCHAR(40) NOT NULL,
    name                VARCHAR(140) NOT NULL,
    description         VARCHAR(255) NULL,
    address_line        VARCHAR(255) NULL,
    city                VARCHAR(100) NULL,
    state_code          CHAR(2) NULL,
    postal_code         VARCHAR(12) NULL,
    latitude            DECIMAL(10,7) NULL,
    longitude           DECIMAL(10,7) NULL,
    active              TINYINT(1) NOT NULL DEFAULT 1,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                      ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_units_company_code (company_id, code),
    UNIQUE KEY uq_units_company_id (company_id, id),
    CONSTRAINT fk_units_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT chk_units_active CHECK (active IN (0, 1)),
    CONSTRAINT chk_units_coordinates CHECK (
        (latitude IS NULL AND longitude IS NULL)
        OR (
            latitude IS NOT NULL
            AND longitude IS NOT NULL
            AND latitude BETWEEN -90 AND 90
            AND longitude BETWEEN -180 AND 180
        )
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS permissions (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code                VARCHAR(80) NOT NULL,
    description         VARCHAR(255) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_permissions_code (code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS roles (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    name                VARCHAR(60) NOT NULL,
    description         VARCHAR(255) NULL,
    is_system_role      TINYINT(1) NOT NULL DEFAULT 0,
    active              TINYINT(1) NOT NULL DEFAULT 1,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_roles_company_name (company_id, name),
    UNIQUE KEY uq_roles_company_id (company_id, id),
    CONSTRAINT fk_roles_company
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    CONSTRAINT chk_roles_flags CHECK (
        is_system_role IN (0, 1) AND active IN (0, 1)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id             BIGINT UNSIGNED NOT NULL,
    permission_id       BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (role_id, permission_id),
    CONSTRAINT fk_role_permissions_role
        FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    CONSTRAINT fk_role_permissions_permission
        FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
    id                          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id                  BIGINT UNSIGNED NOT NULL,
    role_id                     BIGINT UNSIGNED NOT NULL,
    full_name                   VARCHAR(140) NOT NULL,
    email                       VARCHAR(160) NOT NULL,
    password_hash               VARCHAR(255) NOT NULL,
    phone                       VARCHAR(30) NULL,
    active                      TINYINT(1) NOT NULL DEFAULT 1,
    must_change_password        TINYINT(1) NOT NULL DEFAULT 0,
    receive_critical_alerts     TINYINT(1) NOT NULL DEFAULT 1,
    receive_automatic_reports   TINYINT(1) NOT NULL DEFAULT 0,
    failed_login_attempts       SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until                DATETIME(3) NULL,
    last_login_at               DATETIME(3) NULL,
    created_at                  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at                  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                              ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_company_email (company_id, email),
    UNIQUE KEY uq_users_company_id (company_id, id),
    KEY idx_users_role (company_id, role_id),
    CONSTRAINT fk_users_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT fk_users_role
        FOREIGN KEY (company_id, role_id)
        REFERENCES roles(company_id, id),
    CONSTRAINT chk_users_flags CHECK (
        active IN (0, 1)
        AND must_change_password IN (0, 1)
        AND receive_critical_alerts IN (0, 1)
        AND receive_automatic_reports IN (0, 1)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS drivers (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    full_name               VARCHAR(140) NOT NULL,
    document_number         VARCHAR(20) NULL,
    employee_code           VARCHAR(40) NULL,
    license_number          VARCHAR(40) NULL,
    license_category        VARCHAR(10) NULL,
    license_expiration_date DATE NULL,
    phone                   VARCHAR(30) NULL,
    active                  TINYINT(1) NOT NULL DEFAULT 1,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                          ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_drivers_company_document (company_id, document_number),
    UNIQUE KEY uq_drivers_company_employee (company_id, employee_code),
    UNIQUE KEY uq_drivers_company_id (company_id, id),
    CONSTRAINT fk_drivers_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT chk_drivers_active CHECK (active IN (0, 1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS vehicles (
    id                          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id                  BIGINT UNSIGNED NOT NULL,
    plate                       VARCHAR(10) NOT NULL,
    fleet_code                  VARCHAR(40) NULL,
    vehicle_type                ENUM(
                                    'TRUCK',
                                    'TRACTOR',
                                    'SEMI_TRAILER',
                                    'TRAILER',
                                    'OTHER'
                                ) NOT NULL DEFAULT 'TRUCK',
    manufacturer                VARCHAR(80) NULL,
    model                       VARCHAR(100) NULL,
    manufacture_year            SMALLINT UNSIGNED NULL,
    axle_count                  TINYINT UNSIGNED NULL,
    registered_tare_kg          DECIMAL(14,3) NULL,
    gross_weight_limit_kg       DECIMAL(14,3) NULL,
    payload_limit_kg            DECIMAL(14,3) NULL,
    active                      TINYINT(1) NOT NULL DEFAULT 1,
    created_at                  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at                  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                              ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_vehicles_company_plate (company_id, plate),
    UNIQUE KEY uq_vehicles_company_fleet (company_id, fleet_code),
    UNIQUE KEY uq_vehicles_company_id (company_id, id),
    CONSTRAINT fk_vehicles_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT chk_vehicles_weights CHECK (
        (registered_tare_kg IS NULL OR registered_tare_kg >= 0)
        AND (gross_weight_limit_kg IS NULL OR gross_weight_limit_kg >= 0)
        AND (payload_limit_kg IS NULL OR payload_limit_kg >= 0)
        AND (
            registered_tare_kg IS NULL
            OR gross_weight_limit_kg IS NULL
            OR gross_weight_limit_kg >= registered_tare_kg
        )
    ),
    CONSTRAINT chk_vehicles_active CHECK (active IN (0, 1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rfid_tags (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    code                    VARCHAR(100) NOT NULL,
    vehicle_id              BIGINT UNSIGNED NULL,
    active                  TINYINT(1) NOT NULL DEFAULT 1,
    activated_at            DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    deactivated_at          DATETIME(3) NULL,
    notes                   VARCHAR(255) NULL,
    active_vehicle_marker   BIGINT UNSIGNED
        GENERATED ALWAYS AS (IF(active = 1, vehicle_id, NULL)) STORED,
    PRIMARY KEY (id),
    UNIQUE KEY uq_rfid_company_code (company_id, code),
    UNIQUE KEY uq_rfid_active_vehicle (company_id, active_vehicle_marker),
    UNIQUE KEY uq_rfid_company_id (company_id, id),
    KEY idx_rfid_vehicle (company_id, vehicle_id),
    CONSTRAINT fk_rfid_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT fk_rfid_vehicle
        FOREIGN KEY (company_id, vehicle_id)
        REFERENCES vehicles(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_rfid_active CHECK (active IN (0, 1)),
    CONSTRAINT chk_rfid_dates CHECK (
        deactivated_at IS NULL OR deactivated_at >= activated_at
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cargo_products (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    code                VARCHAR(50) NULL,
    name                VARCHAR(140) NOT NULL,
    description         VARCHAR(255) NULL,
    default_unit        ENUM('KG', 'TON', 'UNIT', 'BOX', 'BAG', 'PALLET', 'OTHER')
                        NOT NULL DEFAULT 'KG',
    active              TINYINT(1) NOT NULL DEFAULT 1,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                      ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_products_company_code (company_id, code),
    UNIQUE KEY uq_products_company_name (company_id, name),
    UNIQUE KEY uq_products_company_id (company_id, id),
    CONSTRAINT fk_products_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT chk_products_active CHECK (active IN (0, 1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS routes (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    code                VARCHAR(50) NULL,
    origin              VARCHAR(160) NOT NULL,
    destination         VARCHAR(160) NOT NULL,
    distance_km         DECIMAL(10,2) NULL,
    description         VARCHAR(255) NULL,
    active              TINYINT(1) NOT NULL DEFAULT 1,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                      ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_routes_company_code (company_id, code),
    UNIQUE KEY uq_routes_company_path (company_id, origin, destination),
    UNIQUE KEY uq_routes_company_id (company_id, id),
    CONSTRAINT fk_routes_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT chk_routes_distance CHECK (distance_km IS NULL OR distance_km >= 0),
    CONSTRAINT chk_routes_active CHECK (active IN (0, 1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS devices (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    operational_unit_id     BIGINT UNSIGNED NULL,
    name                    VARCHAR(120) NOT NULL,
    device_type             ENUM(
                                'ESP32',
                                'RFID_READER',
                                'SCALE_CONTROLLER',
                                'LOAD_CELL',
                                'GPRS_MODEM',
                                'OTHER'
                            ) NOT NULL,
    serial_number           VARCHAR(100) NULL,
    mac_address             VARCHAR(30) NULL,
    ip_address              VARCHAR(45) NULL,
    firmware_version        VARCHAR(50) NULL,
    api_key_hash            VARCHAR(255) NULL,
    state                   ENUM('ONLINE', 'OFFLINE', 'MAINTENANCE', 'DISABLED')
                            NOT NULL DEFAULT 'OFFLINE',
    last_seen_at            DATETIME(3) NULL,
    last_calibrated_at      DATETIME(3) NULL,
    metadata                JSON NULL,
    active                  TINYINT(1) NOT NULL DEFAULT 1,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                          ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_devices_company_serial (company_id, serial_number),
    UNIQUE KEY uq_devices_company_mac (company_id, mac_address),
    UNIQUE KEY uq_devices_company_id (company_id, id),
    KEY idx_devices_unit_state (company_id, operational_unit_id, state),
    CONSTRAINT fk_devices_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT fk_devices_unit
        FOREIGN KEY (company_id, operational_unit_id)
        REFERENCES operational_units(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_devices_active CHECK (active IN (0, 1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS device_calibrations (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    device_id               BIGINT UNSIGNED NOT NULL,
    calibration_factor      DECIMAL(20,8) NOT NULL,
    reference_weight_kg     DECIMAL(14,3) NOT NULL,
    accuracy_class          VARCHAR(20) NULL,
    certificate_number      VARCHAR(100) NULL,
    result                  ENUM('PENDING', 'APPROVED', 'REJECTED')
                            NOT NULL DEFAULT 'PENDING',
    performed_by_user_id    BIGINT UNSIGNED NULL,
    performed_at            DATETIME(3) NOT NULL,
    expires_at              DATETIME(3) NULL,
    notes                   TEXT NULL,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_calibrations_company_id (company_id, id),
    KEY idx_calibrations_device_date (company_id, device_id, performed_at),
    CONSTRAINT fk_calibrations_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT fk_calibrations_device
        FOREIGN KEY (company_id, device_id)
        REFERENCES devices(company_id, id),
    CONSTRAINT fk_calibrations_user
        FOREIGN KEY (company_id, performed_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_calibration_values CHECK (
        calibration_factor > 0
        AND reference_weight_kg > 0
        AND (expires_at IS NULL OR expires_at >= performed_at)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS weighing_stations (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    operational_unit_id     BIGINT UNSIGNED NOT NULL,
    code                    VARCHAR(50) NOT NULL,
    name                    VARCHAR(120) NOT NULL,
    scale_device_id         BIGINT UNSIGNED NULL,
    rfid_reader_device_id   BIGINT UNSIGNED NULL,
    description             VARCHAR(255) NULL,
    active                  TINYINT(1) NOT NULL DEFAULT 1,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                          ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_stations_company_code (company_id, code),
    UNIQUE KEY uq_stations_company_unit_id (company_id, operational_unit_id, id),
    UNIQUE KEY uq_stations_company_id (company_id, id),
    CONSTRAINT fk_stations_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT fk_stations_unit
        FOREIGN KEY (company_id, operational_unit_id)
        REFERENCES operational_units(company_id, id),
    CONSTRAINT fk_stations_scale_device
        FOREIGN KEY (company_id, scale_device_id)
        REFERENCES devices(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_stations_rfid_device
        FOREIGN KEY (company_id, rfid_reader_device_id)
        REFERENCES devices(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_stations_active CHECK (active IN (0, 1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS company_settings (
    company_id                          BIGINT UNSIGNED NOT NULL,
    tolerance_percent                   DECIMAL(8,3) NOT NULL DEFAULT 1.500,
    critical_limit_percent              DECIMAL(8,3) NOT NULL DEFAULT 3.000,
    tare_tolerance_percent              DECIMAL(8,3) NOT NULL DEFAULT 5.000,
    reading_stability_tolerance_kg      DECIMAL(10,3) NOT NULL DEFAULT 2.000,
    minimum_stable_readings             TINYINT UNSIGNED NOT NULL DEFAULT 3,
    max_reading_age_seconds             INT UNSIGNED NOT NULL DEFAULT 120,
    allow_manual_readings               TINYINT(1) NOT NULL DEFAULT 1,
    require_manual_reason               TINYINT(1) NOT NULL DEFAULT 1,
    require_rfid                         TINYINT(1) NOT NULL DEFAULT 0,
    automatic_sheet_refresh             TINYINT(1) NOT NULL DEFAULT 1,
    critical_alert_notifications        TINYINT(1) NOT NULL DEFAULT 1,
    automatic_email_reports             TINYINT(1) NOT NULL DEFAULT 0,
    default_weight_unit                 ENUM('KG', 'TON') NOT NULL DEFAULT 'KG',
    updated_by_user_id                  BIGINT UNSIGNED NULL,
    updated_at                          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                                      ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (company_id),
    CONSTRAINT fk_settings_company
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    CONSTRAINT fk_settings_user
        FOREIGN KEY (company_id, updated_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_settings_limits CHECK (
        tolerance_percent >= 0
        AND critical_limit_percent >= tolerance_percent
        AND tare_tolerance_percent >= 0
        AND reading_stability_tolerance_kg >= 0
        AND minimum_stable_readings > 0
        AND max_reading_age_seconds > 0
    ),
    CONSTRAINT chk_settings_flags CHECK (
        allow_manual_readings IN (0, 1)
        AND require_manual_reason IN (0, 1)
        AND require_rfid IN (0, 1)
        AND automatic_sheet_refresh IN (0, 1)
        AND critical_alert_notifications IN (0, 1)
        AND automatic_email_reports IN (0, 1)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS weighing_operations (
    id                              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id                      BIGINT UNSIGNED NOT NULL,
    operational_unit_id             BIGINT UNSIGNED NOT NULL,
    weighing_station_id             BIGINT UNSIGNED NULL,
    operation_code                  VARCHAR(40) NOT NULL,

    movement_type                   ENUM('ENTRY', 'EXIT', 'TRANSFER', 'WEIGHING_ONLY')
                                    NOT NULL DEFAULT 'WEIGHING_ONLY',
    weighing_method                 ENUM('THREE_STAGE', 'GROSS_TARE')
                                    NOT NULL DEFAULT 'THREE_STAGE',
    state                           ENUM('DRAFT', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')
                                    NOT NULL DEFAULT 'DRAFT',
    status                          ENUM('ANALYSIS', 'NORMAL', 'ATTENTION', 'CRITICAL')
                                    NOT NULL DEFAULT 'ANALYSIS',

    vehicle_id                      BIGINT UNSIGNED NOT NULL,
    driver_id                       BIGINT UNSIGNED NULL,
    rfid_tag_id                     BIGINT UNSIGNED NULL,
    cargo_product_id                BIGINT UNSIGNED NULL,
    route_id                        BIGINT UNSIGNED NULL,
    responsible_user_id             BIGINT UNSIGNED NOT NULL,
    created_by_user_id              BIGINT UNSIGNED NOT NULL,

    declared_quantity               DECIMAL(14,3) NULL,
    declared_quantity_unit          ENUM('KG', 'TON', 'UNIT', 'BOX', 'BAG', 'PALLET', 'OTHER')
                                    NULL,
    declared_cargo_weight_kg        DECIMAL(14,3) NULL,

    empty_truck_weight_kg           DECIMAL(14,3) NULL,
    separated_cargo_weight_kg       DECIMAL(14,3) NULL,
    expected_gross_weight_kg        DECIMAL(14,3) NULL,
    loaded_truck_weight_kg          DECIMAL(14,3) NULL,
    actual_cargo_weight_kg          DECIMAL(14,3) NULL,
    difference_kg                   DECIMAL(14,3) NULL,
    difference_percent              DECIMAL(10,4) NULL,
    tare_difference_percent         DECIMAL(10,4) NULL,

    registered_tare_snapshot_kg     DECIMAL(14,3) NULL,
    gross_limit_snapshot_kg         DECIMAL(14,3) NULL,
    payload_limit_snapshot_kg       DECIMAL(14,3) NULL,
    tolerance_percent_snapshot      DECIMAL(8,3) NOT NULL,
    critical_limit_snapshot         DECIMAL(8,3) NOT NULL,
    tare_tolerance_snapshot         DECIMAL(8,3) NOT NULL,

    invoice_number                  VARCHAR(80) NULL,
    mdfe_number                     VARCHAR(80) NULL,
    ciot_number                     VARCHAR(80) NULL,
    status_reason                   VARCHAR(500) NULL,
    observations                    TEXT NULL,

    calculation_version             INT UNSIGNED NOT NULL DEFAULT 0,
    row_version                     INT UNSIGNED NOT NULL DEFAULT 1,
    started_at                      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    completed_at                    DATETIME(3) NULL,
    cancelled_at                    DATETIME(3) NULL,
    cancelled_by_user_id            BIGINT UNSIGNED NULL,
    cancellation_reason             VARCHAR(500) NULL,
    created_at                      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at                      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                                  ON UPDATE CURRENT_TIMESTAMP(3),

    PRIMARY KEY (id),
    UNIQUE KEY uq_operations_company_code (company_id, operation_code),
    UNIQUE KEY uq_operations_company_id (company_id, id),
    KEY idx_operations_state_date (company_id, state, started_at),
    KEY idx_operations_status_date (company_id, status, completed_at),
    KEY idx_operations_vehicle_date (company_id, vehicle_id, started_at),
    KEY idx_operations_driver_date (company_id, driver_id, started_at),
    KEY idx_operations_product_date (company_id, cargo_product_id, started_at),
    KEY idx_operations_station_date (company_id, weighing_station_id, started_at),

    CONSTRAINT fk_operations_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT fk_operations_unit
        FOREIGN KEY (company_id, operational_unit_id)
        REFERENCES operational_units(company_id, id),
    CONSTRAINT fk_operations_station
        FOREIGN KEY (company_id, operational_unit_id, weighing_station_id)
        REFERENCES weighing_stations(company_id, operational_unit_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_operations_vehicle
        FOREIGN KEY (company_id, vehicle_id)
        REFERENCES vehicles(company_id, id),
    CONSTRAINT fk_operations_driver
        FOREIGN KEY (company_id, driver_id)
        REFERENCES drivers(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_operations_rfid
        FOREIGN KEY (company_id, rfid_tag_id)
        REFERENCES rfid_tags(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_operations_product
        FOREIGN KEY (company_id, cargo_product_id)
        REFERENCES cargo_products(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_operations_route
        FOREIGN KEY (company_id, route_id)
        REFERENCES routes(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_operations_responsible_user
        FOREIGN KEY (company_id, responsible_user_id)
        REFERENCES users(company_id, id),
    CONSTRAINT fk_operations_created_by_user
        FOREIGN KEY (company_id, created_by_user_id)
        REFERENCES users(company_id, id),
    CONSTRAINT fk_operations_cancelled_by_user
        FOREIGN KEY (company_id, cancelled_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,

    CONSTRAINT chk_operations_nonnegative CHECK (
        (declared_quantity IS NULL OR declared_quantity >= 0)
        AND (declared_cargo_weight_kg IS NULL OR declared_cargo_weight_kg >= 0)
        AND (empty_truck_weight_kg IS NULL OR empty_truck_weight_kg >= 0)
        AND (separated_cargo_weight_kg IS NULL OR separated_cargo_weight_kg >= 0)
        AND (expected_gross_weight_kg IS NULL OR expected_gross_weight_kg >= 0)
        AND (loaded_truck_weight_kg IS NULL OR loaded_truck_weight_kg >= 0)
        AND (actual_cargo_weight_kg IS NULL OR actual_cargo_weight_kg >= 0)
    ),
    CONSTRAINT chk_operations_snapshot_limits CHECK (
        tolerance_percent_snapshot >= 0
        AND critical_limit_snapshot >= tolerance_percent_snapshot
        AND tare_tolerance_snapshot >= 0
    ),
    CONSTRAINT chk_operations_cancelled CHECK (
        state <> 'CANCELLED'
        OR (cancelled_at IS NOT NULL AND cancellation_reason IS NOT NULL)
    ),
    CONSTRAINT chk_operations_completed CHECK (
        state <> 'COMPLETED'
        OR (
            empty_truck_weight_kg IS NOT NULL
            AND loaded_truck_weight_kg IS NOT NULL
            AND actual_cargo_weight_kg IS NOT NULL
            AND completed_at IS NOT NULL
            AND (
                weighing_method <> 'THREE_STAGE'
                OR separated_cargo_weight_kg IS NOT NULL
            )
        )
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS weighing_readings (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    operation_id            BIGINT UNSIGNED NOT NULL,
    stage                   ENUM('EMPTY_TRUCK', 'SEPARATED_CARGO', 'LOADED_TRUCK')
                            NOT NULL,
    sequence_number         INT UNSIGNED NOT NULL,
    weight_kg               DECIMAL(14,3) NOT NULL,
    source                  ENUM('DEVICE', 'MANUAL', 'IMPORT') NOT NULL DEFAULT 'DEVICE',
    device_id               BIGINT UNSIGNED NULL,
    is_stable               TINYINT(1) NOT NULL DEFAULT 0,
    is_accepted             TINYINT(1) NOT NULL DEFAULT 0,
    checksum_valid          TINYINT(1) NULL,
    signal_strength_dbm     SMALLINT NULL,
    manual_reason           VARCHAR(500) NULL,
    measured_at             DATETIME(3) NOT NULL,
    received_at             DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    accepted_at             DATETIME(3) NULL,
    accepted_by_user_id     BIGINT UNSIGNED NULL,
    created_by_user_id      BIGINT UNSIGNED NULL,
    raw_payload             JSON NULL,
    accepted_marker         TINYINT
        GENERATED ALWAYS AS (IF(is_accepted = 1, 1, NULL)) STORED,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_readings_operation_sequence (operation_id, stage, sequence_number),
    UNIQUE KEY uq_readings_accepted_stage (operation_id, stage, accepted_marker),
    UNIQUE KEY uq_readings_company_id (company_id, id),
    KEY idx_readings_operation_stage_date (company_id, operation_id, stage, measured_at),
    KEY idx_readings_device_date (company_id, device_id, measured_at),
    CONSTRAINT fk_readings_operation
        FOREIGN KEY (company_id, operation_id)
        REFERENCES weighing_operations(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT fk_readings_device
        FOREIGN KEY (company_id, device_id)
        REFERENCES devices(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_readings_accepted_user
        FOREIGN KEY (company_id, accepted_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_readings_created_user
        FOREIGN KEY (company_id, created_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_readings_weight CHECK (weight_kg >= 0),
    CONSTRAINT chk_readings_flags CHECK (
        is_stable IN (0, 1)
        AND is_accepted IN (0, 1)
        AND (checksum_valid IS NULL OR checksum_valid IN (0, 1))
    ),
    CONSTRAINT chk_readings_manual CHECK (
        source <> 'MANUAL' OR created_by_user_id IS NOT NULL
    ),
    CONSTRAINT chk_readings_acceptance CHECK (
        is_accepted = 0
        OR (accepted_at IS NOT NULL AND accepted_by_user_id IS NOT NULL)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alerts (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    operation_id            BIGINT UNSIGNED NOT NULL,
    calculation_version     INT UNSIGNED NOT NULL,
    alert_type              ENUM(
                                'OVER_GROSS_LIMIT',
                                'OVER_PAYLOAD_LIMIT',
                                'POSSIBLE_MISSING_CARGO',
                                'POSSIBLE_EXTRA_CARGO',
                                'TARE_DIVERGENCE',
                                'UNSTABLE_READING',
                                'MANUAL_READING',
                                'WEIGHING_INCONSISTENCY',
                                'DEVICE_OFFLINE'
                            ) NOT NULL,
    severity                ENUM('ATTENTION', 'CRITICAL') NOT NULL,
    state                   ENUM('OPEN', 'ACKNOWLEDGED', 'RESOLVED')
                            NOT NULL DEFAULT 'OPEN',
    source                  ENUM('SYSTEM', 'MANUAL') NOT NULL DEFAULT 'SYSTEM',
    title                   VARCHAR(180) NOT NULL,
    message                 TEXT NOT NULL,
    difference_kg           DECIMAL(14,3) NULL,
    difference_percent      DECIMAL(10,4) NULL,
    created_by_user_id      BIGINT UNSIGNED NULL,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    acknowledged_by_user_id BIGINT UNSIGNED NULL,
    acknowledged_at         DATETIME(3) NULL,
    resolved_by_user_id     BIGINT UNSIGNED NULL,
    resolved_at             DATETIME(3) NULL,
    resolution_notes        TEXT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_alerts_calculation_type (
        operation_id, calculation_version, alert_type
    ),
    UNIQUE KEY uq_alerts_company_id (company_id, id),
    KEY idx_alerts_state_severity_date (company_id, state, severity, created_at),
    KEY idx_alerts_operation (company_id, operation_id),
    CONSTRAINT fk_alerts_operation
        FOREIGN KEY (company_id, operation_id)
        REFERENCES weighing_operations(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT fk_alerts_created_user
        FOREIGN KEY (company_id, created_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_alerts_ack_user
        FOREIGN KEY (company_id, acknowledged_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_alerts_resolved_user
        FOREIGN KEY (company_id, resolved_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_alerts_acknowledged CHECK (
        state <> 'ACKNOWLEDGED'
        OR (acknowledged_at IS NOT NULL AND acknowledged_by_user_id IS NOT NULL)
    ),
    CONSTRAINT chk_alerts_resolved CHECK (
        state <> 'RESOLVED'
        OR (resolved_at IS NOT NULL AND resolution_notes IS NOT NULL)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS operation_events (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    operation_id        BIGINT UNSIGNED NOT NULL,
    event_type          ENUM(
                            'CREATED',
                            'READING_RECEIVED',
                            'READING_ACCEPTED',
                            'FINALIZED',
                            'CANCELLED',
                            'REOPENED',
                            'STATUS_CHANGED',
                            'NOTE_ADDED'
                        ) NOT NULL,
    user_id             BIGINT UNSIGNED NULL,
    device_id           BIGINT UNSIGNED NULL,
    event_data          JSON NULL,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_operation_events_timeline (company_id, operation_id, created_at),
    CONSTRAINT fk_operation_events_operation
        FOREIGN KEY (company_id, operation_id)
        REFERENCES weighing_operations(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT fk_operation_events_user
        FOREIGN KEY (company_id, user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_operation_events_device
        FOREIGN KEY (company_id, device_id)
        REFERENCES devices(company_id, id)
        ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS operation_attachments (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    operation_id        BIGINT UNSIGNED NOT NULL,
    attachment_type     ENUM('WEIGHING_TICKET', 'PHOTO', 'DOCUMENT', 'OTHER')
                        NOT NULL,
    original_name       VARCHAR(255) NOT NULL,
    stored_name         VARCHAR(255) NOT NULL,
    mime_type           VARCHAR(120) NULL,
    size_bytes          BIGINT UNSIGNED NULL,
    file_location       TEXT NOT NULL,
    checksum_sha256     CHAR(64) NULL,
    uploaded_by_user_id BIGINT UNSIGNED NOT NULL,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_attachments_operation (company_id, operation_id, created_at),
    CONSTRAINT fk_attachments_operation
        FOREIGN KEY (company_id, operation_id)
        REFERENCES weighing_operations(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT fk_attachments_user
        FOREIGN KEY (company_id, uploaded_by_user_id)
        REFERENCES users(company_id, id),
    CONSTRAINT chk_attachments_size CHECK (size_bytes IS NULL OR size_bytes >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS generated_reports (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    report_type         ENUM('DAILY', 'WEEKLY', 'MONTHLY', 'BIMONTHLY', 'QUARTERLY', 'CUSTOM')
                        NOT NULL,
    period_start        DATE NOT NULL,
    period_end          DATE NOT NULL,
    generated_by_user_id BIGINT UNSIGNED NOT NULL,
    file_format         ENUM('PDF', 'CSV', 'XLSX', 'JSON') NULL,
    file_location       TEXT NULL,
    filters_json        JSON NULL,
    summary_json        JSON NULL,
    recommendations     TEXT NULL,
    generated_at        DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_reports_company_period (company_id, period_start, period_end),
    CONSTRAINT fk_reports_company
        FOREIGN KEY (company_id) REFERENCES companies(id),
    CONSTRAINT fk_reports_user
        FOREIGN KEY (company_id, generated_by_user_id)
        REFERENCES users(company_id, id),
    CONSTRAINT chk_reports_period CHECK (period_end >= period_start)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NULL,
    user_id             BIGINT UNSIGNED NULL,
    action              VARCHAR(100) NOT NULL,
    entity_name         VARCHAR(100) NOT NULL,
    entity_id           VARCHAR(100) NULL,
    old_values          JSON NULL,
    new_values          JSON NULL,
    ip_address          VARCHAR(45) NULL,
    user_agent          VARCHAR(500) NULL,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_audit_company_date (company_id, created_at),
    KEY idx_audit_entity (entity_name, entity_id, created_at),
    CONSTRAINT fk_audit_company
        FOREIGN KEY (company_id) REFERENCES companies(id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_audit_user
        FOREIGN KEY (company_id, user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

DELIMITER $$

DROP TRIGGER IF EXISTS trg_operations_before_insert$$
CREATE TRIGGER trg_operations_before_insert
BEFORE INSERT ON weighing_operations
FOR EACH ROW
BEGIN
    DECLARE v_tolerance DECIMAL(8,3);
    DECLARE v_critical DECIMAL(8,3);
    DECLARE v_tare_tolerance DECIMAL(8,3);
    DECLARE v_registered_tare DECIMAL(14,3);
    DECLARE v_gross_limit DECIMAL(14,3);
    DECLARE v_payload_limit DECIMAL(14,3);
    DECLARE v_require_rfid TINYINT;
    DECLARE v_rfid_vehicle_id BIGINT UNSIGNED;

    IF NEW.operation_code IS NULL OR TRIM(NEW.operation_code) = '' THEN
        SET NEW.operation_code = CONCAT('PES-', UUID_SHORT());
    END IF;

    SELECT tolerance_percent,
           critical_limit_percent,
           tare_tolerance_percent,
           require_rfid
      INTO v_tolerance,
           v_critical,
           v_tare_tolerance,
           v_require_rfid
      FROM company_settings
     WHERE company_id = NEW.company_id;

    SELECT registered_tare_kg,
           gross_weight_limit_kg,
           payload_limit_kg
      INTO v_registered_tare,
           v_gross_limit,
           v_payload_limit
      FROM vehicles
     WHERE company_id = NEW.company_id
       AND id = NEW.vehicle_id;

    SET NEW.tolerance_percent_snapshot = v_tolerance;
    SET NEW.critical_limit_snapshot = v_critical;
    SET NEW.tare_tolerance_snapshot = v_tare_tolerance;
    SET NEW.registered_tare_snapshot_kg = v_registered_tare;
    SET NEW.gross_limit_snapshot_kg = v_gross_limit;
    SET NEW.payload_limit_snapshot_kg = v_payload_limit;

    IF v_require_rfid = 1 AND NEW.rfid_tag_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A empresa exige uma etiqueta RFID na operação.';
    END IF;

    IF NEW.rfid_tag_id IS NOT NULL THEN
        SELECT MAX(vehicle_id)
          INTO v_rfid_vehicle_id
          FROM rfid_tags
         WHERE company_id = NEW.company_id
           AND id = NEW.rfid_tag_id
           AND active = 1;

        IF v_rfid_vehicle_id IS NULL OR v_rfid_vehicle_id <> NEW.vehicle_id THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'A etiqueta RFID não está ativa para o veículo informado.';
        END IF;
    END IF;
END$$

DROP TRIGGER IF EXISTS trg_operations_before_update$$
CREATE TRIGGER trg_operations_before_update
BEFORE UPDATE ON weighing_operations
FOR EACH ROW
BEGIN
    DECLARE v_rfid_vehicle_id BIGINT UNSIGNED;
    DECLARE v_registered_tare DECIMAL(14,3);
    DECLARE v_gross_limit DECIMAL(14,3);
    DECLARE v_payload_limit DECIMAL(14,3);

    IF NEW.company_id <> OLD.company_id THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A empresa de uma operação não pode ser alterada.';
    END IF;

    SET NEW.row_version = OLD.row_version + 1;

    IF NEW.vehicle_id <> OLD.vehicle_id THEN
        SELECT registered_tare_kg,
               gross_weight_limit_kg,
               payload_limit_kg
          INTO v_registered_tare,
               v_gross_limit,
               v_payload_limit
          FROM vehicles
         WHERE company_id = NEW.company_id
           AND id = NEW.vehicle_id;

        SET NEW.registered_tare_snapshot_kg = v_registered_tare;
        SET NEW.gross_limit_snapshot_kg = v_gross_limit;
        SET NEW.payload_limit_snapshot_kg = v_payload_limit;
    END IF;

    IF (
        NOT (NEW.rfid_tag_id <=> OLD.rfid_tag_id)
        OR NEW.vehicle_id <> OLD.vehicle_id
    ) AND NEW.rfid_tag_id IS NOT NULL THEN
        SELECT MAX(vehicle_id)
          INTO v_rfid_vehicle_id
          FROM rfid_tags
         WHERE company_id = NEW.company_id
           AND id = NEW.rfid_tag_id
           AND active = 1;

        IF v_rfid_vehicle_id IS NULL OR v_rfid_vehicle_id <> NEW.vehicle_id THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'A etiqueta RFID não está ativa para o veículo informado.';
        END IF;
    END IF;
END$$

DROP TRIGGER IF EXISTS trg_operation_created_event$$
CREATE TRIGGER trg_operation_created_event
AFTER INSERT ON weighing_operations
FOR EACH ROW
BEGIN
    INSERT INTO operation_events (
        company_id,
        operation_id,
        event_type,
        user_id,
        event_data
    ) VALUES (
        NEW.company_id,
        NEW.id,
        'CREATED',
        NEW.created_by_user_id,
        JSON_OBJECT(
            'operation_code', NEW.operation_code,
            'movement_type', NEW.movement_type,
            'weighing_method', NEW.weighing_method
        )
    );
END$$

DROP TRIGGER IF EXISTS trg_readings_before_insert$$
CREATE TRIGGER trg_readings_before_insert
BEFORE INSERT ON weighing_readings
FOR EACH ROW
BEGIN
    DECLARE v_allow_manual TINYINT;
    DECLARE v_require_reason TINYINT;
    DECLARE v_operation_state VARCHAR(30);

    SELECT allow_manual_readings, require_manual_reason
      INTO v_allow_manual, v_require_reason
      FROM company_settings
     WHERE company_id = NEW.company_id;

    SELECT state
      INTO v_operation_state
      FROM weighing_operations
     WHERE company_id = NEW.company_id
       AND id = NEW.operation_id;

    IF v_operation_state IN ('COMPLETED', 'CANCELLED') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Não é possível registrar leitura em operação concluída ou cancelada.';
    END IF;

    IF NEW.source = 'DEVICE' AND NEW.device_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Uma leitura automática deve informar o dispositivo de origem.';
    END IF;

    IF NEW.source = 'MANUAL' THEN
        IF v_allow_manual = 0 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Leituras manuais estão desabilitadas para esta empresa.';
        END IF;

        IF NEW.created_by_user_id IS NULL THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Uma leitura manual deve informar o usuário responsável.';
        END IF;

        IF v_require_reason = 1
           AND (NEW.manual_reason IS NULL OR TRIM(NEW.manual_reason) = '') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'O motivo da leitura manual é obrigatório.';
        END IF;
    END IF;
END$$

DROP TRIGGER IF EXISTS trg_readings_before_update$$
CREATE TRIGGER trg_readings_before_update
BEFORE UPDATE ON weighing_readings
FOR EACH ROW
BEGIN
    DECLARE v_allow_manual TINYINT;
    DECLARE v_require_reason TINYINT;

    SELECT allow_manual_readings, require_manual_reason
      INTO v_allow_manual, v_require_reason
      FROM company_settings
     WHERE company_id = NEW.company_id;

    IF NEW.source = 'DEVICE' AND NEW.device_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Uma leitura automática deve informar o dispositivo de origem.';
    END IF;

    IF NEW.source = 'MANUAL' THEN
        IF v_allow_manual = 0 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Leituras manuais estão desabilitadas para esta empresa.';
        END IF;

        IF NEW.created_by_user_id IS NULL THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Uma leitura manual deve informar o usuário responsável.';
        END IF;

        IF v_require_reason = 1
           AND (NEW.manual_reason IS NULL OR TRIM(NEW.manual_reason) = '') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'O motivo da leitura manual é obrigatório.';
        END IF;
    END IF;
END$$

DELIMITER ;

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_accept_weighing_reading$$
CREATE PROCEDURE sp_accept_weighing_reading (
    IN p_company_id BIGINT UNSIGNED,
    IN p_reading_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_operation_id BIGINT UNSIGNED;
    DECLARE v_stage VARCHAR(30);
    DECLARE v_weight DECIMAL(14,3);
    DECLARE v_source VARCHAR(20);
    DECLARE v_is_stable TINYINT;
    DECLARE v_operation_state VARCHAR(30);
    DECLARE v_require_stable TINYINT DEFAULT 1;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT r.operation_id,
           r.stage,
           r.weight_kg,
           r.source,
           r.is_stable,
           o.state
      INTO v_operation_id,
           v_stage,
           v_weight,
           v_source,
           v_is_stable,
           v_operation_state
      FROM weighing_readings r
      JOIN weighing_operations o
        ON o.company_id = r.company_id
       AND o.id = r.operation_id
     WHERE r.company_id = p_company_id
       AND r.id = p_reading_id
     FOR UPDATE;

    IF v_operation_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Leitura não encontrada.';
    END IF;

    IF v_operation_state IN ('COMPLETED', 'CANCELLED') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Não é possível aceitar leitura em operação concluída ou cancelada.';
    END IF;

    IF v_source = 'DEVICE' AND v_is_stable = 0 AND v_require_stable = 1 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A leitura automática precisa estar estável antes de ser aceita.';
    END IF;

    UPDATE weighing_readings
       SET is_accepted = 0,
           accepted_at = NULL,
           accepted_by_user_id = NULL
     WHERE company_id = p_company_id
       AND operation_id = v_operation_id
       AND stage = v_stage
       AND is_accepted = 1;

    UPDATE weighing_readings
       SET is_accepted = 1,
           accepted_at = CURRENT_TIMESTAMP(3),
           accepted_by_user_id = p_user_id
     WHERE company_id = p_company_id
       AND id = p_reading_id;

    IF v_stage = 'EMPTY_TRUCK' THEN
        UPDATE weighing_operations
           SET empty_truck_weight_kg = v_weight,
               state = 'IN_PROGRESS'
         WHERE company_id = p_company_id
           AND id = v_operation_id;
    ELSEIF v_stage = 'SEPARATED_CARGO' THEN
        UPDATE weighing_operations
           SET separated_cargo_weight_kg = v_weight,
               state = 'IN_PROGRESS'
         WHERE company_id = p_company_id
           AND id = v_operation_id;
    ELSEIF v_stage = 'LOADED_TRUCK' THEN
        UPDATE weighing_operations
           SET loaded_truck_weight_kg = v_weight,
               state = 'IN_PROGRESS'
         WHERE company_id = p_company_id
           AND id = v_operation_id;
    END IF;

    INSERT INTO operation_events (
        company_id,
        operation_id,
        event_type,
        user_id,
        event_data
    ) VALUES (
        p_company_id,
        v_operation_id,
        'READING_ACCEPTED',
        p_user_id,
        JSON_OBJECT(
            'reading_id', p_reading_id,
            'stage', v_stage,
            'weight_kg', v_weight,
            'source', v_source
        )
    );

    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_finalize_weighing_operation$$
CREATE PROCEDURE sp_finalize_weighing_operation (
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_method VARCHAR(30);
    DECLARE v_state VARCHAR(30);
    DECLARE v_empty DECIMAL(14,3);
    DECLARE v_separated DECIMAL(14,3);
    DECLARE v_declared DECIMAL(14,3);
    DECLARE v_loaded DECIMAL(14,3);
    DECLARE v_expected DECIMAL(14,3);
    DECLARE v_actual_cargo DECIMAL(14,3);
    DECLARE v_difference DECIMAL(14,3);
    DECLARE v_difference_percent DECIMAL(10,4);
    DECLARE v_tare_difference_percent DECIMAL(10,4);
    DECLARE v_registered_tare DECIMAL(14,3);
    DECLARE v_gross_limit DECIMAL(14,3);
    DECLARE v_payload_limit DECIMAL(14,3);
    DECLARE v_tolerance DECIMAL(8,3);
    DECLARE v_critical DECIMAL(8,3);
    DECLARE v_tare_tolerance DECIMAL(8,3);
    DECLARE v_new_status VARCHAR(20) DEFAULT 'NORMAL';
    DECLARE v_status_reason VARCHAR(500) DEFAULT 'Pesagem dentro dos limites configurados.';
    DECLARE v_new_version INT UNSIGNED;
    DECLARE v_manual_count INT DEFAULT 0;
    DECLARE v_unstable_count INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT weighing_method,
           state,
           empty_truck_weight_kg,
           separated_cargo_weight_kg,
           declared_cargo_weight_kg,
           loaded_truck_weight_kg,
           registered_tare_snapshot_kg,
           gross_limit_snapshot_kg,
           payload_limit_snapshot_kg,
           tolerance_percent_snapshot,
           critical_limit_snapshot,
           tare_tolerance_snapshot,
           calculation_version + 1
      INTO v_method,
           v_state,
           v_empty,
           v_separated,
           v_declared,
           v_loaded,
           v_registered_tare,
           v_gross_limit,
           v_payload_limit,
           v_tolerance,
           v_critical,
           v_tare_tolerance,
           v_new_version
      FROM weighing_operations
     WHERE company_id = p_company_id
       AND id = p_operation_id
     FOR UPDATE;

    IF v_method IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação de pesagem não encontrada.';
    END IF;

    IF v_state = 'CANCELLED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Uma operação cancelada não pode ser finalizada.';
    END IF;

    IF v_empty IS NULL OR v_loaded IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'As leituras do caminhão vazio e carregado são obrigatórias.';
    END IF;

    IF v_method = 'THREE_STAGE' AND v_separated IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A pesagem em três etapas exige o peso da carga separada.';
    END IF;

    SET v_actual_cargo = v_loaded - v_empty;

    IF v_actual_cargo < 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O peso carregado não pode ser menor que o peso vazio.';
    END IF;

    IF v_method = 'THREE_STAGE' THEN
        SET v_expected = v_empty + v_separated;
    ELSEIF v_declared IS NOT NULL THEN
        SET v_expected = v_empty + v_declared;
    ELSE
        SET v_expected = v_loaded;
    END IF;

    SET v_difference = v_loaded - v_expected;
    SET v_difference_percent =
        CASE
            WHEN v_expected > 0 THEN ROUND((v_difference / v_expected) * 100, 4)
            ELSE 0
        END;

    SET v_tare_difference_percent =
        CASE
            WHEN v_registered_tare IS NOT NULL AND v_registered_tare > 0
                THEN ROUND((ABS(v_empty - v_registered_tare) / v_registered_tare) * 100, 4)
            ELSE NULL
        END;

    IF ABS(v_difference_percent) > v_critical THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Divergência de peso acima do limite crítico.';
    ELSEIF ABS(v_difference_percent) > v_tolerance THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'Divergência de peso acima da tolerância operacional.';
    END IF;

    IF v_gross_limit IS NOT NULL AND v_gross_limit > 0 AND v_loaded > v_gross_limit THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Peso bruto acima do limite cadastrado para o veículo.';
    END IF;

    IF v_payload_limit IS NOT NULL AND v_payload_limit > 0 AND v_actual_cargo > v_payload_limit THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Carga líquida acima da capacidade cadastrada para o veículo.';
    END IF;

    IF v_tare_difference_percent IS NOT NULL
       AND v_tare_difference_percent > v_tare_tolerance
       AND v_new_status = 'NORMAL' THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'Peso vazio divergente da tara cadastrada.';
    END IF;

    SELECT COUNT(*)
      INTO v_manual_count
      FROM weighing_readings
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND is_accepted = 1
       AND source = 'MANUAL';

    SELECT COUNT(*)
      INTO v_unstable_count
      FROM weighing_readings
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND is_accepted = 1
       AND is_stable = 0;

    IF v_manual_count > 0 AND v_new_status = 'NORMAL' THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'A operação contém ao menos uma leitura manual.';
    END IF;

    IF v_unstable_count > 0 THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'A operação contém leitura aceita sem estabilidade.';
    END IF;

    UPDATE alerts
       SET state = 'RESOLVED',
           resolved_by_user_id = p_user_id,
           resolved_at = CURRENT_TIMESTAMP(3),
           resolution_notes = 'Alerta substituído por um novo cálculo da operação.'
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND source = 'SYSTEM'
       AND state IN ('OPEN', 'ACKNOWLEDGED');

    UPDATE weighing_operations
       SET expected_gross_weight_kg = v_expected,
           actual_cargo_weight_kg = v_actual_cargo,
           difference_kg = v_difference,
           difference_percent = v_difference_percent,
           tare_difference_percent = v_tare_difference_percent,
           status = v_new_status,
           status_reason = v_status_reason,
           calculation_version = v_new_version,
           state = 'COMPLETED',
           completed_at = CURRENT_TIMESTAMP(3)
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    IF v_gross_limit IS NOT NULL AND v_gross_limit > 0 AND v_loaded > v_gross_limit THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'OVER_GROSS_LIMIT', 'CRITICAL',
            'Peso bruto acima do limite',
            CONCAT(
                'Peso medido: ', FORMAT(v_loaded, 3),
                ' kg. Limite do veículo: ', FORMAT(v_gross_limit, 3), ' kg.'
            ),
            v_loaded - v_gross_limit,
            ROUND(((v_loaded - v_gross_limit) / v_gross_limit) * 100, 4)
        );
    END IF;

    IF v_payload_limit IS NOT NULL AND v_payload_limit > 0 AND v_actual_cargo > v_payload_limit THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'OVER_PAYLOAD_LIMIT', 'CRITICAL',
            'Carga acima da capacidade',
            CONCAT(
                'Carga calculada: ', FORMAT(v_actual_cargo, 3),
                ' kg. Capacidade cadastrada: ', FORMAT(v_payload_limit, 3), ' kg.'
            ),
            v_actual_cargo - v_payload_limit,
            ROUND(((v_actual_cargo - v_payload_limit) / v_payload_limit) * 100, 4)
        );
    END IF;

    IF ABS(v_difference_percent) > v_tolerance THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id,
            p_operation_id,
            v_new_version,
            IF(v_difference < 0, 'POSSIBLE_MISSING_CARGO', 'POSSIBLE_EXTRA_CARGO'),
            IF(ABS(v_difference_percent) > v_critical, 'CRITICAL', 'ATTENTION'),
            IF(v_difference < 0, 'Possível falta de carga', 'Possível excesso de carga'),
            CONCAT(
                'Diferença detectada: ', FORMAT(v_difference, 3),
                ' kg (', FORMAT(v_difference_percent, 4), '%).'
            ),
            v_difference,
            v_difference_percent
        );
    END IF;

    IF v_tare_difference_percent IS NOT NULL
       AND v_tare_difference_percent > v_tare_tolerance THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'TARE_DIVERGENCE', 'ATTENTION',
            'Divergência na tara do veículo',
            CONCAT(
                'Peso vazio medido: ', FORMAT(v_empty, 3),
                ' kg. Tara cadastrada: ', FORMAT(v_registered_tare, 3),
                ' kg. Divergência: ', FORMAT(v_tare_difference_percent, 4), '%.'
            ),
            v_empty - v_registered_tare,
            v_tare_difference_percent
        );
    END IF;

    IF v_manual_count > 0 THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'MANUAL_READING', 'ATTENTION',
            'Leitura manual utilizada',
            CONCAT('A operação possui ', v_manual_count, ' leitura(s) manual(is) aceita(s).')
        );
    END IF;

    IF v_unstable_count > 0 THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'UNSTABLE_READING', 'CRITICAL',
            'Leitura instável aceita',
            CONCAT('A operação possui ', v_unstable_count, ' leitura(s) aceita(s) sem estabilidade.')
        );
    END IF;

    INSERT INTO operation_events (
        company_id,
        operation_id,
        event_type,
        user_id,
        event_data
    ) VALUES (
        p_company_id,
        p_operation_id,
        'FINALIZED',
        p_user_id,
        JSON_OBJECT(
            'calculation_version', v_new_version,
            'status', v_new_status,
            'expected_gross_weight_kg', v_expected,
            'loaded_truck_weight_kg', v_loaded,
            'actual_cargo_weight_kg', v_actual_cargo,
            'difference_kg', v_difference,
            'difference_percent', v_difference_percent
        )
    );

    COMMIT;
END$$

DROP PROCEDURE IF EXISTS sp_cancel_weighing_operation$$
CREATE PROCEDURE sp_cancel_weighing_operation (
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED,
    IN p_reason VARCHAR(500)
)
BEGIN
    IF p_reason IS NULL OR TRIM(p_reason) = '' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O motivo do cancelamento é obrigatório.';
    END IF;

    UPDATE weighing_operations
       SET state = 'CANCELLED',
           cancelled_at = CURRENT_TIMESTAMP(3),
           cancelled_by_user_id = p_user_id,
           cancellation_reason = p_reason
     WHERE company_id = p_company_id
       AND id = p_operation_id
       AND state <> 'COMPLETED';

    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada ou já concluída.';
    END IF;

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id,
        p_operation_id,
        'CANCELLED',
        p_user_id,
        JSON_OBJECT('reason', p_reason)
    );
END$$

DELIMITER ;

CREATE OR REPLACE VIEW vw_weighing_operation_details AS
SELECT
    o.id,
    o.company_id,
    c.trade_name AS company_name,
    o.operation_code,
    o.movement_type,
    o.weighing_method,
    o.state,
    o.status,
    o.status_reason,
    o.started_at,
    o.completed_at,
    u.name AS operational_unit_name,
    ws.name AS weighing_station_name,
    v.plate AS vehicle_plate,
    v.fleet_code,
    d.full_name AS driver_name,
    rfid.code AS rfid_code,
    cp.name AS cargo_product_name,
    rt.origin,
    rt.destination,
    responsible.full_name AS responsible_user_name,
    creator.full_name AS created_by_user_name,
    o.empty_truck_weight_kg,
    o.separated_cargo_weight_kg,
    o.expected_gross_weight_kg,
    o.loaded_truck_weight_kg,
    o.actual_cargo_weight_kg,
    o.difference_kg,
    o.difference_percent,
    o.tare_difference_percent,
    o.gross_limit_snapshot_kg,
    o.payload_limit_snapshot_kg,
    o.observations
FROM weighing_operations o
JOIN companies c
  ON c.id = o.company_id
JOIN operational_units u
  ON u.company_id = o.company_id
 AND u.id = o.operational_unit_id
LEFT JOIN weighing_stations ws
  ON ws.company_id = o.company_id
 AND ws.id = o.weighing_station_id
JOIN vehicles v
  ON v.company_id = o.company_id
 AND v.id = o.vehicle_id
LEFT JOIN drivers d
  ON d.company_id = o.company_id
 AND d.id = o.driver_id
LEFT JOIN rfid_tags rfid
  ON rfid.company_id = o.company_id
 AND rfid.id = o.rfid_tag_id
LEFT JOIN cargo_products cp
  ON cp.company_id = o.company_id
 AND cp.id = o.cargo_product_id
LEFT JOIN routes rt
  ON rt.company_id = o.company_id
 AND rt.id = o.route_id
JOIN users responsible
  ON responsible.company_id = o.company_id
 AND responsible.id = o.responsible_user_id
JOIN users creator
  ON creator.company_id = o.company_id
 AND creator.id = o.created_by_user_id;

CREATE OR REPLACE VIEW vw_open_alerts AS
SELECT
    a.id,
    a.company_id,
    o.operation_code,
    a.alert_type,
    a.severity,
    a.state,
    a.title,
    a.message,
    a.difference_kg,
    a.difference_percent,
    a.created_at,
    v.plate AS vehicle_plate
FROM alerts a
JOIN weighing_operations o
  ON o.company_id = a.company_id
 AND o.id = a.operation_id
JOIN vehicles v
  ON v.company_id = o.company_id
 AND v.id = o.vehicle_id
WHERE a.state IN ('OPEN', 'ACKNOWLEDGED');

CREATE OR REPLACE VIEW vw_dashboard_daily AS
SELECT
    company_id,
    DATE(COALESCE(completed_at, started_at)) AS reference_date,
    COUNT(*) AS total_operations,
    SUM(state = 'COMPLETED') AS completed_operations,
    SUM(status = 'NORMAL') AS normal_operations,
    SUM(status = 'ATTENTION') AS attention_operations,
    SUM(status = 'CRITICAL') AS critical_operations,
    ROUND(SUM(COALESCE(actual_cargo_weight_kg, 0)), 3) AS total_cargo_weight_kg,
    ROUND(AVG(ABS(difference_percent)), 4) AS average_absolute_difference_percent
FROM weighing_operations
GROUP BY company_id, DATE(COALESCE(completed_at, started_at));

CREATE OR REPLACE VIEW vw_latest_device_calibration AS
SELECT dc.*
FROM device_calibrations dc
JOIN (
    SELECT company_id, device_id, MAX(performed_at) AS max_performed_at
    FROM device_calibrations
    GROUP BY company_id, device_id
) latest
  ON latest.company_id = dc.company_id
 AND latest.device_id = dc.device_id
 AND latest.max_performed_at = dc.performed_at;

INSERT IGNORE INTO permissions (code, description) VALUES
    ('DASHBOARD_VIEW', 'Visualizar dashboard e indicadores'),
    ('OPERATION_CREATE', 'Criar operações de pesagem'),
    ('OPERATION_VIEW', 'Visualizar operações de pesagem'),
    ('OPERATION_UPDATE', 'Alterar operações em andamento'),
    ('OPERATION_FINALIZE', 'Finalizar e recalcular operações'),
    ('OPERATION_CANCEL', 'Cancelar operações'),
    ('READING_CREATE', 'Registrar leituras de pesagem'),
    ('READING_ACCEPT', 'Aceitar a leitura oficial de uma etapa'),
    ('ALERT_VIEW', 'Visualizar alertas'),
    ('ALERT_MANAGE', 'Reconhecer e resolver alertas'),
    ('REPORT_GENERATE', 'Gerar e exportar relatórios'),
    ('VEHICLE_MANAGE', 'Gerenciar veículos e etiquetas RFID'),
    ('DRIVER_MANAGE', 'Gerenciar motoristas'),
    ('PRODUCT_MANAGE', 'Gerenciar produtos e tipos de carga'),
    ('DEVICE_MANAGE', 'Gerenciar hardware, dispositivos e calibrações'),
    ('USER_MANAGE', 'Gerenciar usuários, perfis e permissões'),
    ('SETTINGS_MANAGE', 'Alterar configurações da empresa'),
    ('AUDIT_VIEW', 'Consultar registros de auditoria');

INSERT INTO companies (
    legal_name,
    trade_name,
    document_number,
    slug,
    email,
    timezone_name
)
SELECT
    'LoadSense Tecnologia e Logística LTDA',
    'LoadSense Demonstração',
    NULL,
    'loadsense-demo',
    'contato@loadsense.local',
    'America/Sao_Paulo'
WHERE NOT EXISTS (
    SELECT 1 FROM companies WHERE slug = 'loadsense-demo'
);

SET @company_id := (
    SELECT id FROM companies WHERE slug = 'loadsense-demo' LIMIT 1
);

INSERT INTO operational_units (
    company_id, code, name, description, city, state_code
)
SELECT
    @company_id,
    'MATRIZ',
    'Unidade Principal',
    'Unidade inicial do projeto LoadSense',
    'Taboão da Serra',
    'SP'
WHERE NOT EXISTS (
    SELECT 1
      FROM operational_units
     WHERE company_id = @company_id
       AND code = 'MATRIZ'
);

INSERT INTO company_settings (company_id)
SELECT @company_id
WHERE NOT EXISTS (
    SELECT 1 FROM company_settings WHERE company_id = @company_id
);

INSERT INTO roles (
    company_id, name, description, is_system_role
)
SELECT @company_id, 'ADMINISTRATOR', 'Acesso total ao sistema', 1
WHERE NOT EXISTS (
    SELECT 1 FROM roles
     WHERE company_id = @company_id AND name = 'ADMINISTRATOR'
);

INSERT INTO roles (
    company_id, name, description, is_system_role
)
SELECT @company_id, 'SUPERVISOR', 'Supervisão, alertas e relatórios', 1
WHERE NOT EXISTS (
    SELECT 1 FROM roles
     WHERE company_id = @company_id AND name = 'SUPERVISOR'
);

INSERT INTO roles (
    company_id, name, description, is_system_role
)
SELECT @company_id, 'OPERATOR', 'Cadastro e execução das pesagens', 1
WHERE NOT EXISTS (
    SELECT 1 FROM roles
     WHERE company_id = @company_id AND name = 'OPERATOR'
);

SET @admin_role_id := (
    SELECT id FROM roles
     WHERE company_id = @company_id AND name = 'ADMINISTRATOR'
     LIMIT 1
);

SET @supervisor_role_id := (
    SELECT id FROM roles
     WHERE company_id = @company_id AND name = 'SUPERVISOR'
     LIMIT 1
);

SET @operator_role_id := (
    SELECT id FROM roles
     WHERE company_id = @company_id AND name = 'OPERATOR'
     LIMIT 1
);

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT @admin_role_id, p.id
FROM permissions p;

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT @supervisor_role_id, p.id
FROM permissions p
WHERE p.code IN (
    'DASHBOARD_VIEW',
    'OPERATION_CREATE',
    'OPERATION_VIEW',
    'OPERATION_UPDATE',
    'OPERATION_FINALIZE',
    'OPERATION_CANCEL',
    'READING_CREATE',
    'READING_ACCEPT',
    'ALERT_VIEW',
    'ALERT_MANAGE',
    'REPORT_GENERATE',
    'VEHICLE_MANAGE',
    'DRIVER_MANAGE',
    'PRODUCT_MANAGE',
    'DEVICE_MANAGE',
    'AUDIT_VIEW'
);

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT @operator_role_id, p.id
FROM permissions p
WHERE p.code IN (
    'DASHBOARD_VIEW',
    'OPERATION_CREATE',
    'OPERATION_VIEW',
    'OPERATION_UPDATE',
    'READING_CREATE',
    'READING_ACCEPT',
    'ALERT_VIEW'
);

USE loadsense;
SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS app_platform_settings (
    platform                        ENUM('ANDROID', 'IOS') NOT NULL,
    current_version_name            VARCHAR(30) NOT NULL DEFAULT '1.0.0',
    current_build_number            INT UNSIGNED NOT NULL DEFAULT 1,
    minimum_supported_build_number  INT UNSIGNED NOT NULL DEFAULT 1,
    maintenance_mode                TINYINT(1) NOT NULL DEFAULT 0,
    maintenance_message             VARCHAR(500) NULL,
    store_url                       VARCHAR(500) NULL,
    updated_at                      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                                  ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (platform),
    CONSTRAINT chk_app_platform_builds CHECK (
        current_build_number > 0
        AND minimum_supported_build_number > 0
        AND current_build_number >= minimum_supported_build_number
    ),
    CONSTRAINT chk_app_platform_maintenance CHECK (maintenance_mode IN (0, 1))
) ENGINE=InnoDB;

INSERT INTO app_platform_settings (
    platform,
    current_version_name,
    current_build_number,
    minimum_supported_build_number,
    maintenance_mode
) VALUES
    ('ANDROID', '1.0.0', 1, 1, 0),
    ('IOS',     '1.0.0', 1, 1, 0)
ON DUPLICATE KEY UPDATE platform = VALUES(platform);

CREATE TABLE IF NOT EXISTS user_app_preferences (
    company_id                  BIGINT UNSIGNED NOT NULL,
    user_id                     BIGINT UNSIGNED NOT NULL,
    theme                       ENUM('SYSTEM', 'DARK', 'LIGHT') NOT NULL DEFAULT 'DARK',
    language_code               VARCHAR(10) NOT NULL DEFAULT 'pt-BR',
    push_notifications_enabled  TINYINT(1) NOT NULL DEFAULT 1,
    sound_alerts_enabled        TINYINT(1) NOT NULL DEFAULT 1,
    automatic_sync_enabled      TINYINT(1) NOT NULL DEFAULT 1,
    dashboard_alert_limit       TINYINT UNSIGNED NOT NULL DEFAULT 3,
    alerts_page_size            SMALLINT UNSIGNED NOT NULL DEFAULT 20,
    default_period_days         SMALLINT UNSIGNED NOT NULL DEFAULT 30,
    created_at                  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at                  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                              ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (company_id, user_id),
    CONSTRAINT fk_app_preferences_user
        FOREIGN KEY (company_id, user_id)
        REFERENCES users(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT chk_app_preferences_flags CHECK (
        push_notifications_enabled IN (0, 1)
        AND sound_alerts_enabled IN (0, 1)
        AND automatic_sync_enabled IN (0, 1)
    ),
    CONSTRAINT chk_app_preferences_limits CHECK (
        dashboard_alert_limit BETWEEN 1 AND 10
        AND alerts_page_size BETWEEN 5 AND 100
        AND default_period_days BETWEEN 1 AND 366
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_devices (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    user_id                 BIGINT UNSIGNED NOT NULL,
    device_uuid             VARCHAR(160) NOT NULL,
    platform                ENUM('ANDROID', 'IOS', 'WEB') NOT NULL,
    device_name             VARCHAR(160) NULL,
    app_version_name        VARCHAR(30) NULL,
    app_build_number        INT UNSIGNED NULL,
    os_version              VARCHAR(60) NULL,
    push_token              VARCHAR(512) NULL,
    biometric_login_enabled TINYINT(1) NOT NULL DEFAULT 0,
    notifications_enabled   TINYINT(1) NOT NULL DEFAULT 1,
    active                  TINYINT(1) NOT NULL DEFAULT 1,
    last_seen_at            DATETIME(3) NULL,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                              ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_user_devices_user_uuid (company_id, user_id, device_uuid),
    UNIQUE KEY uq_user_devices_company_id (company_id, id),
    UNIQUE KEY uq_user_devices_company_user_id (company_id, user_id, id),
    KEY idx_user_devices_user_active (company_id, user_id, active),
    KEY idx_user_devices_push_token (push_token(191)),
    CONSTRAINT fk_user_devices_user
        FOREIGN KEY (company_id, user_id)
        REFERENCES users(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT chk_user_devices_flags CHECK (
        biometric_login_enabled IN (0, 1)
        AND notifications_enabled IN (0, 1)
        AND active IN (0, 1)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS route_waypoints (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    route_id            BIGINT UNSIGNED NOT NULL,
    sequence_number     SMALLINT UNSIGNED NOT NULL,
    waypoint_type       ENUM('ORIGIN', 'WAYPOINT', 'DESTINATION') NOT NULL,
    label               VARCHAR(160) NULL,
    latitude            DECIMAL(10,7) NOT NULL,
    longitude           DECIMAL(10,7) NOT NULL,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_route_waypoints_sequence (company_id, route_id, sequence_number),
    UNIQUE KEY uq_route_waypoints_company_id (company_id, id),
    KEY idx_route_waypoints_route (company_id, route_id, sequence_number),
    CONSTRAINT fk_route_waypoints_route
        FOREIGN KEY (company_id, route_id)
        REFERENCES routes(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT chk_route_waypoints_coordinates CHECK (
        latitude BETWEEN -90 AND 90
        AND longitude BETWEEN -180 AND 180
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS operation_tracking_status (
    company_id              BIGINT UNSIGNED NOT NULL,
    operation_id            BIGINT UNSIGNED NOT NULL,
    tracking_state          ENUM(
                                'NOT_STARTED',
                                'IN_TRANSIT',
                                'STOPPED',
                                'ARRIVED',
                                'SIGNAL_LOST',
                                'CANCELLED'
                            ) NOT NULL DEFAULT 'NOT_STARTED',
    current_latitude        DECIMAL(10,7) NULL,
    current_longitude       DECIMAL(10,7) NULL,
    speed_kmh               DECIMAL(8,2) NULL,
    heading_degrees         DECIMAL(6,2) NULL,
    progress_percent        DECIMAL(6,3) NULL,
    estimated_arrival_at    DATETIME(3) NULL,
    last_position_at        DATETIME(3) NULL,
    updated_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                              ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (company_id, operation_id),
    KEY idx_tracking_status_state (company_id, tracking_state, last_position_at),
    CONSTRAINT fk_tracking_status_operation
        FOREIGN KEY (company_id, operation_id)
        REFERENCES weighing_operations(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT chk_tracking_status_coordinates CHECK (
        (current_latitude IS NULL OR current_latitude BETWEEN -90 AND 90)
        AND (current_longitude IS NULL OR current_longitude BETWEEN -180 AND 180)
    ),
    CONSTRAINT chk_tracking_status_values CHECK (
        (speed_kmh IS NULL OR speed_kmh >= 0)
        AND (heading_degrees IS NULL OR heading_degrees BETWEEN 0 AND 360)
        AND (progress_percent IS NULL OR progress_percent BETWEEN 0 AND 100)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS operation_tracking_points (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    operation_id            BIGINT UNSIGNED NOT NULL,
    device_id               BIGINT UNSIGNED NULL,
    latitude                DECIMAL(10,7) NOT NULL,
    longitude               DECIMAL(10,7) NOT NULL,
    speed_kmh               DECIMAL(8,2) NULL,
    heading_degrees         DECIMAL(6,2) NULL,
    accuracy_meters         DECIMAL(8,2) NULL,
    progress_percent        DECIMAL(6,3) NULL,
    estimated_arrival_at    DATETIME(3) NULL,
    signal_strength_dbm     SMALLINT NULL,
    raw_payload             JSON NULL,
    recorded_at             DATETIME(3) NOT NULL,
    received_at             DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_tracking_points_company_id (company_id, id),
    KEY idx_tracking_points_operation_time (company_id, operation_id, recorded_at),
    KEY idx_tracking_points_device_time (company_id, device_id, recorded_at),
    CONSTRAINT fk_tracking_points_operation
        FOREIGN KEY (company_id, operation_id)
        REFERENCES weighing_operations(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT fk_tracking_points_device
        FOREIGN KEY (company_id, device_id)
        REFERENCES devices(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_tracking_points_coordinates CHECK (
        latitude BETWEEN -90 AND 90
        AND longitude BETWEEN -180 AND 180
    ),
    CONSTRAINT chk_tracking_points_values CHECK (
        (speed_kmh IS NULL OR speed_kmh >= 0)
        AND (heading_degrees IS NULL OR heading_degrees BETWEEN 0 AND 360)
        AND (accuracy_meters IS NULL OR accuracy_meters >= 0)
        AND (progress_percent IS NULL OR progress_percent BETWEEN 0 AND 100)
    )
) ENGINE=InnoDB;

DROP TRIGGER IF EXISTS trg_tracking_point_after_insert;
DELIMITER $$
CREATE TRIGGER trg_tracking_point_after_insert
AFTER INSERT ON operation_tracking_points
FOR EACH ROW
BEGIN
    DECLARE v_tracking_state VARCHAR(20);

    SET v_tracking_state = CASE
        WHEN NEW.progress_percent IS NOT NULL AND NEW.progress_percent >= 100
            THEN 'ARRIVED'
        WHEN NEW.speed_kmh IS NOT NULL AND NEW.speed_kmh <= 0.10
            THEN 'STOPPED'
        ELSE 'IN_TRANSIT'
    END;

    INSERT INTO operation_tracking_status (
        company_id,
        operation_id,
        tracking_state,
        current_latitude,
        current_longitude,
        speed_kmh,
        heading_degrees,
        progress_percent,
        estimated_arrival_at,
        last_position_at
    ) VALUES (
        NEW.company_id,
        NEW.operation_id,
        v_tracking_state,
        NEW.latitude,
        NEW.longitude,
        NEW.speed_kmh,
        NEW.heading_degrees,
        NEW.progress_percent,
        NEW.estimated_arrival_at,
        NEW.recorded_at
    )
    ON DUPLICATE KEY UPDATE
        tracking_state = IF(
            last_position_at IS NULL OR NEW.recorded_at >= last_position_at,
            v_tracking_state,
            tracking_state
        ),
        current_latitude = IF(
            last_position_at IS NULL OR NEW.recorded_at >= last_position_at,
            NEW.latitude,
            current_latitude
        ),
        current_longitude = IF(
            last_position_at IS NULL OR NEW.recorded_at >= last_position_at,
            NEW.longitude,
            current_longitude
        ),
        speed_kmh = IF(
            last_position_at IS NULL OR NEW.recorded_at >= last_position_at,
            NEW.speed_kmh,
            speed_kmh
        ),
        heading_degrees = IF(
            last_position_at IS NULL OR NEW.recorded_at >= last_position_at,
            NEW.heading_degrees,
            heading_degrees
        ),
        progress_percent = IF(
            last_position_at IS NULL OR NEW.recorded_at >= last_position_at,
            NEW.progress_percent,
            progress_percent
        ),
        estimated_arrival_at = IF(
            last_position_at IS NULL OR NEW.recorded_at >= last_position_at,
            NEW.estimated_arrival_at,
            estimated_arrival_at
        ),
        last_position_at = GREATEST(COALESCE(last_position_at, NEW.recorded_at), NEW.recorded_at);
END$$
DELIMITER ;

CREATE TABLE IF NOT EXISTS auth_sessions (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    user_id             BIGINT UNSIGNED NOT NULL,
    user_device_id      BIGINT UNSIGNED NULL,
    refresh_token_hash  CHAR(64) NOT NULL,
    issued_at           DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    last_used_at        DATETIME(3) NULL,
    expires_at          DATETIME(3) NOT NULL,
    revoked_at          DATETIME(3) NULL,
    revoke_reason       VARCHAR(255) NULL,
    ip_address          VARCHAR(45) NULL,
    user_agent          VARCHAR(500) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_auth_sessions_refresh_hash (refresh_token_hash),
    KEY idx_auth_sessions_user_expiry (company_id, user_id, expires_at),
    KEY idx_auth_sessions_device (company_id, user_device_id),
    CONSTRAINT fk_auth_sessions_user
        FOREIGN KEY (company_id, user_id)
        REFERENCES users(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT fk_auth_sessions_device
        FOREIGN KEY (company_id, user_id, user_device_id)
        REFERENCES user_devices(company_id, user_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_auth_sessions_dates CHECK (
        expires_at > issued_at
        AND (revoked_at IS NULL OR revoked_at >= issued_at)
    ),
    CONSTRAINT chk_auth_sessions_revoke_reason CHECK (
        revoked_at IS NULL OR revoke_reason IS NOT NULL
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS legal_documents (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    document_type           ENUM('TERMS_OF_USE', 'PRIVACY_POLICY') NOT NULL,
    version                 VARCHAR(30) NOT NULL,
    title                   VARCHAR(180) NOT NULL,
    content_format          ENUM('MARKDOWN', 'HTML', 'PLAIN_TEXT') NOT NULL DEFAULT 'MARKDOWN',
    content                 MEDIUMTEXT NOT NULL,
    content_hash            CHAR(64) NOT NULL,
    mandatory               TINYINT(1) NOT NULL DEFAULT 1,
    requires_reacceptance   TINYINT(1) NOT NULL DEFAULT 1,
    active                  TINYINT(1) NOT NULL DEFAULT 0,
    published_at            DATETIME(3) NULL,
    effective_at            DATETIME(3) NULL,
    created_by_user_id      BIGINT UNSIGNED NULL,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                              ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_legal_documents_version (company_id, document_type, version),
    UNIQUE KEY uq_legal_documents_company_id (company_id, id),
    KEY idx_legal_documents_active (company_id, document_type, active, effective_at),
    CONSTRAINT fk_legal_documents_company
        FOREIGN KEY (company_id) REFERENCES companies(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_legal_documents_created_user
        FOREIGN KEY (company_id, created_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_legal_documents_flags CHECK (
        mandatory IN (0, 1)
        AND requires_reacceptance IN (0, 1)
        AND active IN (0, 1)
    ),
    CONSTRAINT chk_legal_documents_dates CHECK (
        effective_at IS NULL
        OR published_at IS NULL
        OR effective_at >= published_at
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS legal_acceptances (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    user_id                 BIGINT UNSIGNED NOT NULL,
    legal_document_id       BIGINT UNSIGNED NOT NULL,
    user_device_id          BIGINT UNSIGNED NULL,
    accepted_at             DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    ip_address              VARCHAR(45) NULL,
    user_agent              VARCHAR(500) NULL,
    app_version_name        VARCHAR(30) NULL,
    app_build_number        INT UNSIGNED NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_legal_acceptance_user_document (company_id, user_id, legal_document_id),
    KEY idx_legal_acceptances_user_date (company_id, user_id, accepted_at),
    CONSTRAINT fk_legal_acceptances_user
        FOREIGN KEY (company_id, user_id)
        REFERENCES users(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT fk_legal_acceptances_document
        FOREIGN KEY (company_id, legal_document_id)
        REFERENCES legal_documents(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_legal_acceptances_device
        FOREIGN KEY (company_id, user_id, user_device_id)
        REFERENCES user_devices(company_id, user_id, id)
        ON DELETE RESTRICT
) ENGINE=InnoDB;

DROP PROCEDURE IF EXISTS sp_add_index_if_missing;
DELIMITER $$
CREATE PROCEDURE sp_add_index_if_missing(
    IN p_table_name VARCHAR(64),
    IN p_index_name VARCHAR(64),
    IN p_index_columns VARCHAR(500)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
          FROM information_schema.statistics
         WHERE table_schema = DATABASE()
           AND table_name = p_table_name
           AND index_name = p_index_name
    ) THEN
        SET @ddl = CONCAT(
            'ALTER TABLE `', REPLACE(p_table_name, '`', '``'),
            '` ADD INDEX `', REPLACE(p_index_name, '`', '``'),
            '` (', p_index_columns, ')'
        );
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

CALL sp_add_index_if_missing(
    'weighing_operations',
    'idx_operations_company_started_period',
    '`company_id`, `started_at`'
);

CALL sp_add_index_if_missing(
    'weighing_operations',
    'idx_operations_company_completed_period',
    '`company_id`, `completed_at`'
);

CALL sp_add_index_if_missing(
    'alerts',
    'idx_alerts_company_created_period',
    '`company_id`, `created_at`'
);

CALL sp_add_index_if_missing(
    'generated_reports',
    'idx_reports_company_generated_period',
    '`company_id`, `generated_at`'
);

CALL sp_add_index_if_missing(
    'operation_events',
    'idx_events_company_created_period',
    '`company_id`, `created_at`'
);

CALL sp_add_index_if_missing(
    'operation_tracking_points',
    'idx_tracking_points_company_recorded_period',
    '`company_id`, `recorded_at`'
);

DROP PROCEDURE IF EXISTS sp_add_index_if_missing;

CREATE OR REPLACE VIEW vw_active_operation_tracking AS
SELECT
    ots.company_id,
    ots.operation_id,
    o.operation_code,
    o.state AS weighing_state,
    o.status AS weighing_status,
    v.plate AS vehicle_plate,
    d.full_name AS driver_name,
    rt.origin,
    rt.destination,
    ots.tracking_state,
    ots.current_latitude,
    ots.current_longitude,
    ots.speed_kmh,
    ots.heading_degrees,
    ots.progress_percent,
    ots.estimated_arrival_at,
    ots.last_position_at
FROM operation_tracking_status ots
JOIN weighing_operations o
  ON o.company_id = ots.company_id
 AND o.id = ots.operation_id
JOIN vehicles v
  ON v.company_id = o.company_id
 AND v.id = o.vehicle_id
LEFT JOIN drivers d
  ON d.company_id = o.company_id
 AND d.id = o.driver_id
LEFT JOIN routes rt
  ON rt.company_id = o.company_id
 AND rt.id = o.route_id
WHERE ots.tracking_state IN ('IN_TRANSIT', 'STOPPED', 'SIGNAL_LOST');

CREATE OR REPLACE VIEW vw_pending_legal_documents AS
SELECT
    u.company_id,
    u.id AS user_id,
    ld.id AS legal_document_id,
    ld.document_type,
    ld.version,
    ld.title,
    ld.content_format,
    ld.content,
    ld.content_hash,
    ld.effective_at
FROM users u
JOIN legal_documents ld
  ON ld.company_id = u.company_id
 AND ld.active = 1
 AND ld.mandatory = 1
 AND (ld.effective_at IS NULL OR ld.effective_at <= CURRENT_TIMESTAMP(3))
LEFT JOIN legal_acceptances la
  ON la.company_id = u.company_id
 AND la.user_id = u.id
 AND la.legal_document_id = ld.id
WHERE u.active = 1
  AND la.id IS NULL;

DROP PROCEDURE IF EXISTS sp_accept_legal_document;
DELIMITER $$
CREATE PROCEDURE sp_accept_legal_document(
    IN p_company_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED,
    IN p_legal_document_id BIGINT UNSIGNED,
    IN p_user_device_id BIGINT UNSIGNED,
    IN p_ip_address VARCHAR(45),
    IN p_user_agent VARCHAR(500),
    IN p_app_version_name VARCHAR(30),
    IN p_app_build_number INT UNSIGNED
)
BEGIN
    DECLARE v_document_exists INT DEFAULT 0;
    DECLARE v_user_exists INT DEFAULT 0;

    SELECT COUNT(*)
      INTO v_user_exists
      FROM users
     WHERE company_id = p_company_id
       AND id = p_user_id
       AND active = 1;

    IF v_user_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Usuário inexistente ou inativo.';
    END IF;

    SELECT COUNT(*)
      INTO v_document_exists
      FROM legal_documents
     WHERE company_id = p_company_id
       AND id = p_legal_document_id
       AND active = 1
       AND (effective_at IS NULL OR effective_at <= CURRENT_TIMESTAMP(3));

    IF v_document_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Documento legal inexistente, inativo ou ainda não vigente.';
    END IF;

    INSERT INTO legal_acceptances (
        company_id,
        user_id,
        legal_document_id,
        user_device_id,
        accepted_at,
        ip_address,
        user_agent,
        app_version_name,
        app_build_number
    ) VALUES (
        p_company_id,
        p_user_id,
        p_legal_document_id,
        p_user_device_id,
        CURRENT_TIMESTAMP(3),
        p_ip_address,
        p_user_agent,
        p_app_version_name,
        p_app_build_number
    )
    ON DUPLICATE KEY UPDATE
        user_device_id = VALUES(user_device_id),
        accepted_at = VALUES(accepted_at),
        ip_address = VALUES(ip_address),
        user_agent = VALUES(user_agent),
        app_version_name = VALUES(app_version_name),
        app_build_number = VALUES(app_build_number);

    INSERT INTO audit_logs (
        company_id,
        user_id,
        action,
        entity_name,
        entity_id,
        new_values,
        ip_address,
        user_agent
    ) VALUES (
        p_company_id,
        p_user_id,
        'ACCEPT_LEGAL_DOCUMENT',
        'legal_documents',
        CAST(p_legal_document_id AS CHAR),
        JSON_OBJECT('accepted_at', CURRENT_TIMESTAMP(3)),
        p_ip_address,
        p_user_agent
    );
END$$
DELIMITER ;

USE loadsense;
SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS schema_migrations (
    version         INT UNSIGNED NOT NULL,
    name            VARCHAR(160) NOT NULL,
    applied_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (version)
) ENGINE=InnoDB;

INSERT INTO schema_migrations (version, name)
VALUES (3, 'LoadSense V3 - transporte, tracking, IA e planos')
ON DUPLICATE KEY UPDATE name = VALUES(name);

DROP PROCEDURE IF EXISTS sp_v3_add_column_if_missing;
DROP PROCEDURE IF EXISTS sp_v3_add_index_if_missing;
DROP PROCEDURE IF EXISTS sp_v3_add_check_if_missing;

DELIMITER $$
CREATE PROCEDURE sp_v3_add_column_if_missing(
    IN p_table_name VARCHAR(64),
    IN p_column_name VARCHAR(64),
    IN p_definition TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
          FROM information_schema.columns
         WHERE table_schema = DATABASE()
           AND table_name = p_table_name
           AND column_name = p_column_name
    ) THEN
        SET @ddl = CONCAT(
            'ALTER TABLE `', REPLACE(p_table_name, '`', '``'),
            '` ADD COLUMN `', REPLACE(p_column_name, '`', '``'), '` ', p_definition
        );
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_v3_add_index_if_missing(
    IN p_table_name VARCHAR(64),
    IN p_index_name VARCHAR(64),
    IN p_index_type VARCHAR(30),
    IN p_index_columns TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
          FROM information_schema.statistics
         WHERE table_schema = DATABASE()
           AND table_name = p_table_name
           AND index_name = p_index_name
    ) THEN
        SET @ddl = CONCAT(
            'ALTER TABLE `', REPLACE(p_table_name, '`', '``'),
            '` ADD ', p_index_type, ' `', REPLACE(p_index_name, '`', '``'),
            '` (', p_index_columns, ')' 
        );
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_v3_add_check_if_missing(
    IN p_table_name VARCHAR(64),
    IN p_constraint_name VARCHAR(64),
    IN p_expression TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
          FROM information_schema.table_constraints
         WHERE constraint_schema = DATABASE()
           AND table_name = p_table_name
           AND constraint_name = p_constraint_name
           AND constraint_type = 'CHECK'
    ) THEN
        SET @ddl = CONCAT(
            'ALTER TABLE `', REPLACE(p_table_name, '`', '``'),
            '` ADD CONSTRAINT `', REPLACE(p_constraint_name, '`', '``'),
            '` CHECK (', p_expression, ')'
        );
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

CALL sp_v3_add_column_if_missing(
    'weighing_operations', 'planned_departure_at', 'DATETIME(3) NULL AFTER completed_at'
);
CALL sp_v3_add_column_if_missing(
    'weighing_operations', 'departed_at', 'DATETIME(3) NULL AFTER planned_departure_at'
);
CALL sp_v3_add_column_if_missing(
    'weighing_operations', 'planned_arrival_at', 'DATETIME(3) NULL AFTER departed_at'
);
CALL sp_v3_add_column_if_missing(
    'weighing_operations', 'arrived_at', 'DATETIME(3) NULL AFTER planned_arrival_at'
);

CALL sp_v3_add_index_if_missing(
    'weighing_operations',
    'idx_operations_company_planned_arrival',
    'INDEX', '`company_id`, `planned_arrival_at`'
);
CALL sp_v3_add_index_if_missing(
    'weighing_operations',
    'idx_operations_company_departed',
    'INDEX', '`company_id`, `departed_at`'
);
CALL sp_v3_add_index_if_missing(
    'weighing_operations',
    'idx_operations_company_arrived',
    'INDEX', '`company_id`, `arrived_at`'
);

CALL sp_v3_add_check_if_missing(
    'weighing_operations',
    'chk_operations_transport_schedule',
    '(planned_departure_at IS NULL OR planned_arrival_at IS NULL OR planned_arrival_at >= planned_departure_at)'
);
CALL sp_v3_add_check_if_missing(
    'weighing_operations',
    'chk_operations_transport_actual',
    '(departed_at IS NULL OR arrived_at IS NULL OR arrived_at >= departed_at)'
);

CALL sp_v3_add_column_if_missing(
    'company_settings', 'tracking_alerts_enabled',
    'TINYINT(1) NOT NULL DEFAULT 1 AFTER automatic_email_reports'
);
CALL sp_v3_add_column_if_missing(
    'company_settings', 'stop_speed_threshold_kmh',
    'DECIMAL(8,2) NOT NULL DEFAULT 1.00 AFTER tracking_alerts_enabled'
);
CALL sp_v3_add_column_if_missing(
    'company_settings', 'unplanned_stop_alert_minutes',
    'SMALLINT UNSIGNED NOT NULL DEFAULT 15 AFTER stop_speed_threshold_kmh'
);
CALL sp_v3_add_column_if_missing(
    'company_settings', 'delivery_delay_alert_minutes',
    'SMALLINT UNSIGNED NOT NULL DEFAULT 15 AFTER unplanned_stop_alert_minutes'
);
CALL sp_v3_add_column_if_missing(
    'company_settings', 'signal_loss_alert_minutes',
    'SMALLINT UNSIGNED NOT NULL DEFAULT 10 AFTER delivery_delay_alert_minutes'
);
CALL sp_v3_add_column_if_missing(
    'company_settings', 'route_deviation_alerts_enabled',
    'TINYINT(1) NOT NULL DEFAULT 1 AFTER signal_loss_alert_minutes'
);
CALL sp_v3_add_column_if_missing(
    'company_settings', 'route_deviation_tolerance_meters',
    'INT UNSIGNED NOT NULL DEFAULT 500 AFTER route_deviation_alerts_enabled'
);

CALL sp_v3_add_check_if_missing(
    'company_settings',
    'chk_settings_tracking_v3',
    'tracking_alerts_enabled IN (0,1) AND route_deviation_alerts_enabled IN (0,1) AND stop_speed_threshold_kmh >= 0 AND unplanned_stop_alert_minutes > 0 AND delivery_delay_alert_minutes > 0 AND signal_loss_alert_minutes > 0 AND route_deviation_tolerance_meters > 0'
);

ALTER TABLE alerts
    MODIFY COLUMN calculation_version INT UNSIGNED NULL,
    MODIFY COLUMN alert_type ENUM(
        'OVER_GROSS_LIMIT',
        'OVER_PAYLOAD_LIMIT',
        'POSSIBLE_MISSING_CARGO',
        'POSSIBLE_EXTRA_CARGO',
        'TARE_DIVERGENCE',
        'UNSTABLE_READING',
        'MANUAL_READING',
        'WEIGHING_INCONSISTENCY',
        'DEVICE_OFFLINE',
        'UNPLANNED_STOP',
        'DELIVERY_DELAY',
        'ROUTE_DEVIATION',
        'TRACKING_SIGNAL_LOST'
    ) NOT NULL;

CALL sp_v3_add_column_if_missing(
    'alerts', 'alert_context',
    "ENUM('WEIGHING','TRACKING','DEVICE','AI','SYSTEM') NOT NULL DEFAULT 'WEIGHING' AFTER operation_id"
);
CALL sp_v3_add_column_if_missing(
    'alerts', 'deduplication_key',
    'VARCHAR(190) NULL AFTER source'
);
CALL sp_v3_add_column_if_missing(
    'alerts', 'context_json',
    'JSON NULL AFTER difference_percent'
);
CALL sp_v3_add_column_if_missing(
    'alerts', 'detected_at',
    'DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) AFTER context_json'
);

CALL sp_v3_add_index_if_missing(
    'alerts', 'uq_alerts_company_dedup',
    'UNIQUE INDEX', '`company_id`, `deduplication_key`'
);
CALL sp_v3_add_index_if_missing(
    'alerts', 'idx_alerts_context_state_date',
    'INDEX', '`company_id`, `alert_context`, `state`, `created_at`'
);

UPDATE alerts
   SET alert_context = 'DEVICE'
 WHERE alert_type = 'DEVICE_OFFLINE'
   AND alert_context = 'WEIGHING';

ALTER TABLE operation_events
    MODIFY COLUMN event_type ENUM(
        'CREATED',
        'READING_RECEIVED',
        'READING_ACCEPTED',
        'FINALIZED',
        'CANCELLED',
        'REOPENED',
        'STATUS_CHANGED',
        'NOTE_ADDED',
        'TRANSPORT_SCHEDULED',
        'TRACKING_STARTED',
        'TRACKING_STOPPED',
        'TRACKING_RESUMED',
        'TRACKING_ARRIVED',
        'TRACKING_SIGNAL_LOST',
        'TRACKING_CANCELLED',
        'DELIVERY_DELAY',
        'ROUTE_DEVIATION'
    ) NOT NULL;

CALL sp_v3_add_column_if_missing(
    'operation_tracking_points', 'route_deviation_meters',
    'DECIMAL(10,2) NULL AFTER progress_percent'
);
CALL sp_v3_add_check_if_missing(
    'operation_tracking_points',
    'chk_tracking_points_route_deviation_v3',
    '(route_deviation_meters IS NULL OR route_deviation_meters >= 0)'
);

CALL sp_v3_add_column_if_missing(
    'operation_tracking_status', 'stopped_since',
    'DATETIME(3) NULL AFTER tracking_state'
);
CALL sp_v3_add_column_if_missing(
    'operation_tracking_status', 'last_moving_at',
    'DATETIME(3) NULL AFTER stopped_since'
);
CALL sp_v3_add_column_if_missing(
    'operation_tracking_status', 'route_deviation_meters',
    'DECIMAL(10,2) NULL AFTER progress_percent'
);
CALL sp_v3_add_column_if_missing(
    'operation_tracking_status', 'delay_minutes',
    'INT UNSIGNED NULL AFTER estimated_arrival_at'
);
CALL sp_v3_add_check_if_missing(
    'operation_tracking_status',
    'chk_tracking_status_route_deviation_v3',
    '(route_deviation_meters IS NULL OR route_deviation_meters >= 0)'
);

CALL sp_v3_add_index_if_missing(
    'generated_reports', 'uq_reports_company_id',
    'UNIQUE INDEX', '`company_id`, `id`'
);

CREATE TABLE IF NOT EXISTS ai_analysis_runs (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    scope                   ENUM('PERIOD', 'OPERATION', 'REPORT') NOT NULL DEFAULT 'PERIOD',
    operation_id            BIGINT UNSIGNED NULL,
    generated_report_id     BIGINT UNSIGNED NULL,
    period_start            DATETIME(3) NULL,
    period_end              DATETIME(3) NULL,
    status                  ENUM('PENDING', 'RUNNING', 'COMPLETED', 'FAILED', 'CANCELLED')
                            NOT NULL DEFAULT 'PENDING',
    model_provider          VARCHAR(80) NULL,
    model_name              VARCHAR(120) NULL,
    prompt_version          VARCHAR(40) NULL,
    generated_by_user_id    BIGINT UNSIGNED NULL,
    input_summary_json      JSON NULL,
    result_summary_json     JSON NULL,
    error_message           TEXT NULL,
    started_at              DATETIME(3) NULL,
    completed_at            DATETIME(3) NULL,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_ai_runs_company_id (company_id, id),
    KEY idx_ai_runs_company_status_date (company_id, status, created_at),
    KEY idx_ai_runs_company_period (company_id, period_start, period_end),
    CONSTRAINT fk_ai_runs_company
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    CONSTRAINT fk_ai_runs_operation
        FOREIGN KEY (company_id, operation_id)
        REFERENCES weighing_operations(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_ai_runs_report
        FOREIGN KEY (company_id, generated_report_id)
        REFERENCES generated_reports(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_ai_runs_user
        FOREIGN KEY (company_id, generated_by_user_id)
        REFERENCES users(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_ai_runs_period CHECK (
        period_start IS NULL OR period_end IS NULL OR period_end >= period_start
    ),
    CONSTRAINT chk_ai_runs_scope CHECK (
        (scope <> 'OPERATION' OR operation_id IS NOT NULL)
        AND (scope <> 'REPORT' OR generated_report_id IS NOT NULL)
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ai_insights (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    analysis_run_id         BIGINT UNSIGNED NOT NULL,
    operation_id            BIGINT UNSIGNED NULL,
    insight_type            ENUM('PATTERN', 'RECOMMENDATION', 'FORECAST', 'ANOMALY') NOT NULL,
    severity                ENUM('INFO', 'ATTENTION', 'CRITICAL') NOT NULL DEFAULT 'INFO',
    title                   VARCHAR(180) NOT NULL,
    description             TEXT NOT NULL,
    confidence_percent      DECIMAL(5,2) NULL,
    evidence_json           JSON NULL,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_ai_insights_company_id (company_id, id),
    KEY idx_ai_insights_run_type (company_id, analysis_run_id, insight_type),
    KEY idx_ai_insights_operation (company_id, operation_id, created_at),
    CONSTRAINT fk_ai_insights_run
        FOREIGN KEY (company_id, analysis_run_id)
        REFERENCES ai_analysis_runs(company_id, id)
        ON DELETE CASCADE,
    CONSTRAINT fk_ai_insights_operation
        FOREIGN KEY (company_id, operation_id)
        REFERENCES weighing_operations(company_id, id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_ai_insights_confidence CHECK (
        confidence_percent IS NULL OR confidence_percent BETWEEN 0 AND 100
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS subscription_plans (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code                    VARCHAR(50) NOT NULL,
    name                    VARCHAR(100) NOT NULL,
    description             VARCHAR(255) NULL,
    monthly_price_brl       DECIMAL(10,2) NULL,
    features_json           JSON NULL,
    sort_order              SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    active                  TINYINT(1) NOT NULL DEFAULT 1,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                              ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_subscription_plans_code (code),
    CONSTRAINT chk_subscription_plans_price CHECK (
        monthly_price_brl IS NULL OR monthly_price_brl >= 0
    ),
    CONSTRAINT chk_subscription_plans_active CHECK (active IN (0,1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS company_subscriptions (
    id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id              BIGINT UNSIGNED NOT NULL,
    plan_id                 BIGINT UNSIGNED NOT NULL,
    status                  ENUM('TRIAL', 'ACTIVE', 'PAST_DUE', 'CANCELLED', 'EXPIRED')
                            NOT NULL DEFAULT 'TRIAL',
    starts_at               DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    current_period_start    DATETIME(3) NULL,
    current_period_end      DATETIME(3) NULL,
    cancelled_at            DATETIME(3) NULL,
    cancellation_reason     VARCHAR(500) NULL,
    created_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at              DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
                                              ON UPDATE CURRENT_TIMESTAMP(3),
    current_marker          TINYINT
        GENERATED ALWAYS AS (
            IF(status IN ('TRIAL','ACTIVE','PAST_DUE'), 1, NULL)
        ) STORED,
    PRIMARY KEY (id),
    UNIQUE KEY uq_company_subscription_current (company_id, current_marker),
    KEY idx_company_subscriptions_history (company_id, starts_at),
    CONSTRAINT fk_company_subscriptions_company
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    CONSTRAINT fk_company_subscriptions_plan
        FOREIGN KEY (plan_id) REFERENCES subscription_plans(id) ON DELETE RESTRICT,
    CONSTRAINT chk_company_subscriptions_period CHECK (
        current_period_start IS NULL
        OR current_period_end IS NULL
        OR current_period_end >= current_period_start
    )
) ENGINE=InnoDB;

INSERT INTO subscription_plans (code, name, description, monthly_price_brl, sort_order)
VALUES
    ('BASIC', 'Basic', 'Plano inicial da plataforma.', NULL, 10),
    ('BASIC_PLUS', 'Basic Plus', 'Plano intermediário apresentado no protótipo.', 79.90, 20),
    ('PREMIUM', 'Premium', 'Plano avançado apresentado no protótipo.', 149.90, 30)
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    description = VALUES(description),
    monthly_price_brl = COALESCE(VALUES(monthly_price_brl), monthly_price_brl),
    sort_order = VALUES(sort_order);

INSERT IGNORE INTO permissions (code, description) VALUES
    ('TRACKING_VIEW', 'Visualizar monitoramento e trajeto das operações'),
    ('TRACKING_MANAGE', 'Gerenciar horários, viagem e estados de monitoramento'),
    ('AI_VIEW', 'Visualizar análises e insights da LoadSense AI'),
    ('AI_GENERATE', 'Solicitar novas análises da LoadSense AI'),
    ('SUBSCRIPTION_VIEW', 'Visualizar plano e assinatura da empresa'),
    ('SUBSCRIPTION_MANAGE', 'Gerenciar plano e assinatura da empresa');

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
  FROM roles r
 CROSS JOIN permissions p
 WHERE r.name = 'ADMINISTRATOR'
   AND p.code IN (
       'TRACKING_VIEW', 'TRACKING_MANAGE', 'AI_VIEW', 'AI_GENERATE',
       'SUBSCRIPTION_VIEW', 'SUBSCRIPTION_MANAGE'
   );

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
  FROM roles r
 CROSS JOIN permissions p
 WHERE r.name = 'SUPERVISOR'
   AND p.code IN (
       'TRACKING_VIEW', 'TRACKING_MANAGE', 'AI_VIEW', 'AI_GENERATE',
       'SUBSCRIPTION_VIEW'
   );

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
  FROM roles r
 CROSS JOIN permissions p
 WHERE r.name = 'OPERATOR'
   AND p.code IN ('TRACKING_VIEW');

SET FOREIGN_KEY_CHECKS = 1;

DROP TRIGGER IF EXISTS trg_tracking_point_after_insert;
DELIMITER $$
CREATE TRIGGER trg_tracking_point_after_insert
AFTER INSERT ON operation_tracking_points
FOR EACH ROW
BEGIN
    DECLARE v_prev_state VARCHAR(30);
    DECLARE v_prev_stopped_since DATETIME(3);
    DECLARE v_prev_last_moving_at DATETIME(3);
    DECLARE v_prev_last_position_at DATETIME(3);
    DECLARE v_tracking_state VARCHAR(30);
    DECLARE v_stopped_since DATETIME(3);
    DECLARE v_last_moving_at DATETIME(3);
    DECLARE v_stop_threshold DECIMAL(8,2);
    DECLARE v_stop_minutes INT UNSIGNED;
    DECLARE v_delay_threshold INT UNSIGNED;
    DECLARE v_route_tolerance INT UNSIGNED;
    DECLARE v_tracking_alerts TINYINT;
    DECLARE v_route_alerts TINYINT;
    DECLARE v_planned_arrival DATETIME(3);
    DECLARE v_departed_at DATETIME(3);
    DECLARE v_delay_minutes INT;
    DECLARE v_stop_duration INT;
    DECLARE v_stop_key VARCHAR(190);

    SELECT
        MAX(tracking_state),
        MAX(stopped_since),
        MAX(last_moving_at),
        MAX(last_position_at)
      INTO
        v_prev_state,
        v_prev_stopped_since,
        v_prev_last_moving_at,
        v_prev_last_position_at
      FROM operation_tracking_status
     WHERE company_id = NEW.company_id
       AND operation_id = NEW.operation_id;

    
    IF v_prev_last_position_at IS NULL OR NEW.recorded_at >= v_prev_last_position_at THEN
        SET v_stop_threshold = COALESCE((
            SELECT stop_speed_threshold_kmh
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 1.00);

        SET v_stop_minutes = COALESCE((
            SELECT unplanned_stop_alert_minutes
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 15);

        SET v_delay_threshold = COALESCE((
            SELECT delivery_delay_alert_minutes
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 15);

        SET v_route_tolerance = COALESCE((
            SELECT route_deviation_tolerance_meters
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 500);

        SET v_tracking_alerts = COALESCE((
            SELECT tracking_alerts_enabled
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 1);

        SET v_route_alerts = COALESCE((
            SELECT route_deviation_alerts_enabled
              FROM company_settings
             WHERE company_id = NEW.company_id
             LIMIT 1
        ), 1);

        SELECT planned_arrival_at, departed_at
          INTO v_planned_arrival, v_departed_at
          FROM weighing_operations
         WHERE company_id = NEW.company_id
           AND id = NEW.operation_id
         LIMIT 1;

        SET v_tracking_state = CASE
            WHEN NEW.progress_percent IS NOT NULL AND NEW.progress_percent >= 100
                THEN 'ARRIVED'
            WHEN NEW.speed_kmh IS NOT NULL AND NEW.speed_kmh > v_stop_threshold
                THEN 'IN_TRANSIT'
            WHEN v_departed_at IS NULL AND COALESCE(NEW.progress_percent, 0) <= 0
                THEN 'NOT_STARTED'
            ELSE 'STOPPED'
        END;

        SET v_stopped_since = CASE
            WHEN v_tracking_state = 'STOPPED' AND v_prev_state = 'STOPPED'
                THEN COALESCE(v_prev_stopped_since, NEW.recorded_at)
            WHEN v_tracking_state = 'STOPPED'
                THEN NEW.recorded_at
            ELSE NULL
        END;

        SET v_last_moving_at = CASE
            WHEN v_tracking_state IN ('IN_TRANSIT', 'ARRIVED')
                THEN NEW.recorded_at
            ELSE v_prev_last_moving_at
        END;

        SET v_delay_minutes = CASE
            WHEN v_planned_arrival IS NOT NULL
             AND NEW.estimated_arrival_at IS NOT NULL
             AND NEW.estimated_arrival_at > v_planned_arrival
                THEN TIMESTAMPDIFF(MINUTE, v_planned_arrival, NEW.estimated_arrival_at)
            ELSE 0
        END;

        INSERT INTO operation_tracking_status (
            company_id,
            operation_id,
            tracking_state,
            stopped_since,
            last_moving_at,
            current_latitude,
            current_longitude,
            speed_kmh,
            heading_degrees,
            progress_percent,
            route_deviation_meters,
            estimated_arrival_at,
            delay_minutes,
            last_position_at
        ) VALUES (
            NEW.company_id,
            NEW.operation_id,
            v_tracking_state,
            v_stopped_since,
            v_last_moving_at,
            NEW.latitude,
            NEW.longitude,
            NEW.speed_kmh,
            NEW.heading_degrees,
            NEW.progress_percent,
            NEW.route_deviation_meters,
            NEW.estimated_arrival_at,
            GREATEST(v_delay_minutes, 0),
            NEW.recorded_at
        )
        ON DUPLICATE KEY UPDATE
            tracking_state = v_tracking_state,
            stopped_since = v_stopped_since,
            last_moving_at = v_last_moving_at,
            current_latitude = NEW.latitude,
            current_longitude = NEW.longitude,
            speed_kmh = NEW.speed_kmh,
            heading_degrees = NEW.heading_degrees,
            progress_percent = NEW.progress_percent,
            route_deviation_meters = NEW.route_deviation_meters,
            estimated_arrival_at = NEW.estimated_arrival_at,
            delay_minutes = GREATEST(v_delay_minutes, 0),
            last_position_at = NEW.recorded_at;

        
        IF v_tracking_state = 'IN_TRANSIT' AND v_departed_at IS NULL THEN
            UPDATE weighing_operations
               SET departed_at = COALESCE(departed_at, NEW.recorded_at)
             WHERE company_id = NEW.company_id
               AND id = NEW.operation_id;
            SET v_departed_at = NEW.recorded_at;
        END IF;

        
        IF v_tracking_state = 'ARRIVED' THEN
            UPDATE weighing_operations
               SET arrived_at = COALESCE(arrived_at, NEW.recorded_at)
             WHERE company_id = NEW.company_id
               AND id = NEW.operation_id;
        END IF;

        
        IF v_tracking_state = 'IN_TRANSIT'
           AND (v_prev_state IS NULL OR v_prev_state IN ('NOT_STARTED', 'SIGNAL_LOST')) THEN
            INSERT INTO operation_events (
                company_id, operation_id, event_type, device_id, event_data
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING_STARTED', NEW.device_id,
                JSON_OBJECT('recorded_at', NEW.recorded_at)
            );
        ELSEIF v_tracking_state = 'IN_TRANSIT' AND v_prev_state = 'STOPPED' THEN
            INSERT INTO operation_events (
                company_id, operation_id, event_type, device_id, event_data
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING_RESUMED', NEW.device_id,
                JSON_OBJECT('recorded_at', NEW.recorded_at)
            );
        ELSEIF v_tracking_state = 'STOPPED' AND COALESCE(v_prev_state, '') <> 'STOPPED' THEN
            INSERT INTO operation_events (
                company_id, operation_id, event_type, device_id, event_data
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING_STOPPED', NEW.device_id,
                JSON_OBJECT('recorded_at', NEW.recorded_at)
            );
        ELSEIF v_tracking_state = 'ARRIVED' AND COALESCE(v_prev_state, '') <> 'ARRIVED' THEN
            INSERT INTO operation_events (
                company_id, operation_id, event_type, device_id, event_data
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING_ARRIVED', NEW.device_id,
                JSON_OBJECT('recorded_at', NEW.recorded_at)
            );
        END IF;

        
        IF v_prev_state = 'SIGNAL_LOST' THEN
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'Sinal de rastreamento restabelecido automaticamente.'
             WHERE company_id = NEW.company_id
               AND operation_id = NEW.operation_id
               AND deduplication_key = CONCAT('TRACKING_SIGNAL_LOST:', NEW.operation_id)
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;

        
        IF v_tracking_alerts = 1
           AND v_tracking_state = 'STOPPED'
           AND v_stopped_since IS NOT NULL
           AND v_departed_at IS NOT NULL THEN
            SET v_stop_duration = TIMESTAMPDIFF(MINUTE, v_stopped_since, NEW.recorded_at);
            IF v_stop_duration >= v_stop_minutes THEN
                SET v_stop_key = CONCAT(
                    'UNPLANNED_STOP:', NEW.operation_id, ':',
                    DATE_FORMAT(v_stopped_since, '%Y%m%d%H%i%s%f')
                );

                INSERT INTO alerts (
                    company_id, operation_id, alert_context, calculation_version,
                    alert_type, severity, state, source, deduplication_key,
                    title, message, context_json, detected_at
                ) VALUES (
                    NEW.company_id, NEW.operation_id, 'TRACKING', NULL,
                    'UNPLANNED_STOP', 'ATTENTION', 'OPEN', 'SYSTEM', v_stop_key,
                    'Parada não programada',
                    CONCAT('Veículo parado há aproximadamente ', v_stop_duration, ' minuto(s).'),
                    JSON_OBJECT(
                        'stopped_since', v_stopped_since,
                        'duration_minutes', v_stop_duration,
                        'latitude', NEW.latitude,
                        'longitude', NEW.longitude
                    ),
                    NEW.recorded_at
                )
                ON DUPLICATE KEY UPDATE
                    state = 'OPEN',
                    acknowledged_by_user_id = NULL,
                    acknowledged_at = NULL,
                    resolved_by_user_id = NULL,
                    resolved_at = NULL,
                    resolution_notes = NULL,
                    message = VALUES(message),
                    context_json = VALUES(context_json),
                    detected_at = VALUES(detected_at);
            END IF;
        END IF;

        
        IF v_prev_state = 'STOPPED'
           AND v_tracking_state = 'IN_TRANSIT'
           AND v_prev_stopped_since IS NOT NULL THEN
            SET v_stop_key = CONCAT(
                'UNPLANNED_STOP:', NEW.operation_id, ':',
                DATE_FORMAT(v_prev_stopped_since, '%Y%m%d%H%i%s%f')
            );
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'Veículo voltou a se movimentar.'
             WHERE company_id = NEW.company_id
               AND deduplication_key = v_stop_key
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;

        
        IF v_tracking_alerts = 1
           AND v_planned_arrival IS NOT NULL
           AND v_delay_minutes >= v_delay_threshold
           AND v_tracking_state <> 'ARRIVED' THEN
            INSERT INTO alerts (
                company_id, operation_id, alert_context, calculation_version,
                alert_type, severity, state, source, deduplication_key,
                title, message, context_json, detected_at
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING', NULL,
                'DELIVERY_DELAY', 'ATTENTION', 'OPEN', 'SYSTEM',
                CONCAT('DELIVERY_DELAY:', NEW.operation_id),
                'Atraso na entrega',
                CONCAT('ETA atual indica atraso de aproximadamente ', v_delay_minutes, ' minuto(s).'),
                JSON_OBJECT(
                    'planned_arrival_at', v_planned_arrival,
                    'estimated_arrival_at', NEW.estimated_arrival_at,
                    'delay_minutes', v_delay_minutes
                ),
                NEW.recorded_at
            )
            ON DUPLICATE KEY UPDATE
                state = 'OPEN',
                acknowledged_by_user_id = NULL,
                acknowledged_at = NULL,
                resolved_by_user_id = NULL,
                resolved_at = NULL,
                resolution_notes = NULL,
                message = VALUES(message),
                context_json = VALUES(context_json),
                detected_at = VALUES(detected_at);
        ELSEIF v_tracking_state <> 'ARRIVED' THEN
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'ETA voltou a ficar dentro da tolerância planejada.'
             WHERE company_id = NEW.company_id
               AND operation_id = NEW.operation_id
               AND deduplication_key = CONCAT('DELIVERY_DELAY:', NEW.operation_id)
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;

        
        IF v_tracking_alerts = 1
           AND v_route_alerts = 1
           AND NEW.route_deviation_meters IS NOT NULL
           AND NEW.route_deviation_meters > v_route_tolerance
           AND v_tracking_state <> 'ARRIVED' THEN
            INSERT INTO alerts (
                company_id, operation_id, alert_context, calculation_version,
                alert_type, severity, state, source, deduplication_key,
                title, message, context_json, detected_at
            ) VALUES (
                NEW.company_id, NEW.operation_id, 'TRACKING', NULL,
                'ROUTE_DEVIATION', 'ATTENTION', 'OPEN', 'SYSTEM',
                CONCAT('ROUTE_DEVIATION:', NEW.operation_id),
                'Desvio de rota detectado',
                CONCAT(
                    'Veículo está aproximadamente ', FORMAT(NEW.route_deviation_meters, 0),
                    ' m fora da rota de referência.'
                ),
                JSON_OBJECT(
                    'route_deviation_meters', NEW.route_deviation_meters,
                    'tolerance_meters', v_route_tolerance,
                    'latitude', NEW.latitude,
                    'longitude', NEW.longitude
                ),
                NEW.recorded_at
            )
            ON DUPLICATE KEY UPDATE
                state = 'OPEN',
                acknowledged_by_user_id = NULL,
                acknowledged_at = NULL,
                resolved_by_user_id = NULL,
                resolved_at = NULL,
                resolution_notes = NULL,
                message = VALUES(message),
                context_json = VALUES(context_json),
                detected_at = VALUES(detected_at);
        ELSEIF NEW.route_deviation_meters IS NOT NULL
           AND NEW.route_deviation_meters <= v_route_tolerance THEN
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'Veículo retornou à faixa de tolerância da rota.'
             WHERE company_id = NEW.company_id
               AND operation_id = NEW.operation_id
               AND deduplication_key = CONCAT('ROUTE_DEVIATION:', NEW.operation_id)
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;

        
        IF v_tracking_state = 'ARRIVED' THEN
            UPDATE alerts
               SET state = 'RESOLVED',
                   resolved_at = CURRENT_TIMESTAMP(3),
                   resolution_notes = 'Transporte concluído/veículo chegou ao destino.'
             WHERE company_id = NEW.company_id
               AND operation_id = NEW.operation_id
               AND alert_context = 'TRACKING'
               AND alert_type IN (
                   'UNPLANNED_STOP', 'DELIVERY_DELAY', 'ROUTE_DEVIATION', 'TRACKING_SIGNAL_LOST'
               )
               AND state IN ('OPEN', 'ACKNOWLEDGED');
        END IF;
    END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS sp_set_transport_schedule;
DROP PROCEDURE IF EXISTS sp_start_transport;
DROP PROCEDURE IF EXISTS sp_mark_transport_arrived;
DROP PROCEDURE IF EXISTS sp_cancel_transport;
DROP PROCEDURE IF EXISTS sp_evaluate_tracking_alerts;

DELIMITER $$
CREATE PROCEDURE sp_set_transport_schedule(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED,
    IN p_planned_departure_at DATETIME(3),
    IN p_planned_arrival_at DATETIME(3)
)
BEGIN
    IF p_planned_departure_at IS NOT NULL
       AND p_planned_arrival_at IS NOT NULL
       AND p_planned_arrival_at < p_planned_departure_at THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A chegada planejada não pode ser anterior à saída planejada.';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM weighing_operations
         WHERE company_id = p_company_id AND id = p_operation_id
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada.';
    END IF;

    UPDATE weighing_operations
       SET planned_departure_at = p_planned_departure_at,
           planned_arrival_at = p_planned_arrival_at
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id, p_operation_id, 'TRANSPORT_SCHEDULED', p_user_id,
        JSON_OBJECT(
            'planned_departure_at', p_planned_departure_at,
            'planned_arrival_at', p_planned_arrival_at
        )
    );
END$$

CREATE PROCEDURE sp_start_transport(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_weighing_state VARCHAR(30);
    DECLARE v_tracking_state VARCHAR(30);
    DECLARE v_now DATETIME(3);

    SET v_now = CURRENT_TIMESTAMP(3);

    SELECT MAX(state)
      INTO v_weighing_state
      FROM weighing_operations
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    IF v_weighing_state IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada.';
    END IF;

    IF v_weighing_state <> 'COMPLETED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A pesagem deve estar concluída antes de iniciar o transporte.';
    END IF;

    SELECT MAX(tracking_state)
      INTO v_tracking_state
      FROM operation_tracking_status
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id;

    IF v_tracking_state IN ('ARRIVED', 'CANCELLED') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O transporte já foi encerrado.';
    END IF;

    UPDATE weighing_operations
       SET departed_at = COALESCE(departed_at, v_now)
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    INSERT INTO operation_tracking_status (
        company_id, operation_id, tracking_state, last_moving_at
    ) VALUES (
        p_company_id, p_operation_id, 'IN_TRANSIT', v_now
    )
    ON DUPLICATE KEY UPDATE
        tracking_state = 'IN_TRANSIT',
        stopped_since = NULL,
        last_moving_at = v_now;

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id, p_operation_id, 'TRACKING_STARTED', p_user_id,
        JSON_OBJECT('departed_at', v_now, 'source', 'MANUAL_OR_API')
    );
END$$

CREATE PROCEDURE sp_mark_transport_arrived(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_now DATETIME(3);
    DECLARE v_tracking_state VARCHAR(30);
    SET v_now = CURRENT_TIMESTAMP(3);

    IF NOT EXISTS (
        SELECT 1 FROM weighing_operations
         WHERE company_id = p_company_id
           AND id = p_operation_id
           AND state = 'COMPLETED'
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada ou pesagem ainda não concluída.';
    END IF;

    SELECT MAX(tracking_state)
      INTO v_tracking_state
      FROM operation_tracking_status
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id;

    IF v_tracking_state = 'CANCELLED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O transporte está cancelado.';
    END IF;

    UPDATE weighing_operations
       SET arrived_at = COALESCE(arrived_at, v_now)
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    INSERT INTO operation_tracking_status (
        company_id, operation_id, tracking_state,
        stopped_since, progress_percent, delay_minutes, last_position_at
    ) VALUES (
        p_company_id, p_operation_id, 'ARRIVED', NULL, 100.000, 0, v_now
    )
    ON DUPLICATE KEY UPDATE
        tracking_state = 'ARRIVED',
        stopped_since = NULL,
        progress_percent = 100.000,
        delay_minutes = 0,
        last_position_at = GREATEST(COALESCE(last_position_at, v_now), v_now);

    UPDATE alerts
       SET state = 'RESOLVED',
           resolved_at = v_now,
           resolution_notes = 'Transporte concluído/veículo chegou ao destino.'
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND alert_context = 'TRACKING'
       AND state IN ('OPEN', 'ACKNOWLEDGED');

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id, p_operation_id, 'TRACKING_ARRIVED', p_user_id,
        JSON_OBJECT('arrived_at', v_now, 'source', 'MANUAL_OR_API')
    );
END$$

CREATE PROCEDURE sp_cancel_transport(
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED,
    IN p_reason VARCHAR(500)
)
BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_tracking_state VARCHAR(30);

    IF p_reason IS NULL OR TRIM(p_reason) = '' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O motivo do cancelamento do transporte é obrigatório.';
    END IF;

    SELECT COUNT(*)
      INTO v_exists
      FROM weighing_operations
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    IF v_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação não encontrada.';
    END IF;

    SELECT MAX(tracking_state)
      INTO v_tracking_state
      FROM operation_tracking_status
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id;

    IF v_tracking_state = 'ARRIVED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O transporte já foi concluído e não pode ser cancelado.';
    END IF;

    INSERT INTO operation_tracking_status (
        company_id, operation_id, tracking_state, stopped_since
    ) VALUES (
        p_company_id, p_operation_id, 'CANCELLED', NULL
    )
    ON DUPLICATE KEY UPDATE
        tracking_state = 'CANCELLED',
        stopped_since = NULL;

    UPDATE alerts
       SET state = 'RESOLVED',
           resolved_at = CURRENT_TIMESTAMP(3),
           resolution_notes = CONCAT('Transporte cancelado: ', p_reason)
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND alert_context = 'TRACKING'
       AND state IN ('OPEN', 'ACKNOWLEDGED');

    INSERT INTO operation_events (
        company_id, operation_id, event_type, user_id, event_data
    ) VALUES (
        p_company_id, p_operation_id, 'TRACKING_CANCELLED', p_user_id,
        JSON_OBJECT('reason', p_reason)
    );
END$$

CREATE PROCEDURE sp_evaluate_tracking_alerts(
    IN p_company_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_signal_loss_minutes INT UNSIGNED;
    DECLARE v_delay_minutes INT UNSIGNED;
    DECLARE v_tracking_alerts TINYINT;

    SET v_signal_loss_minutes = COALESCE((
        SELECT signal_loss_alert_minutes
          FROM company_settings
         WHERE company_id = p_company_id
         LIMIT 1
    ), 10);

    SET v_delay_minutes = COALESCE((
        SELECT delivery_delay_alert_minutes
          FROM company_settings
         WHERE company_id = p_company_id
         LIMIT 1
    ), 15);

    SET v_tracking_alerts = COALESCE((
        SELECT tracking_alerts_enabled
          FROM company_settings
         WHERE company_id = p_company_id
         LIMIT 1
    ), 1);

    IF v_tracking_alerts = 1 THEN
        
        INSERT INTO alerts (
            company_id, operation_id, alert_context, calculation_version,
            alert_type, severity, state, source, deduplication_key,
            title, message, context_json, detected_at
        )
        SELECT
            ots.company_id,
            ots.operation_id,
            'TRACKING',
            NULL,
            'TRACKING_SIGNAL_LOST',
            'ATTENTION',
            'OPEN',
            'SYSTEM',
            CONCAT('TRACKING_SIGNAL_LOST:', ots.operation_id),
            'Sinal de rastreamento perdido',
            CONCAT(
                'Nenhuma posição recebida há aproximadamente ',
                TIMESTAMPDIFF(
                    MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
                ),
                ' minuto(s).'
            ),
            JSON_OBJECT(
                'last_position_at', ots.last_position_at,
                'departed_at', o.departed_at,
                'minutes_without_signal', TIMESTAMPDIFF(
                    MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
                )
            ),
            CURRENT_TIMESTAMP(3)
        FROM operation_tracking_status ots
        JOIN weighing_operations o
          ON o.company_id = ots.company_id
         AND o.id = ots.operation_id
        WHERE ots.company_id = p_company_id
          AND ots.tracking_state IN ('IN_TRANSIT', 'STOPPED')
          AND COALESCE(ots.last_position_at, o.departed_at) IS NOT NULL
          AND TIMESTAMPDIFF(
              MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
          ) >= v_signal_loss_minutes
        ON DUPLICATE KEY UPDATE
            state = 'OPEN',
            acknowledged_by_user_id = NULL,
            acknowledged_at = NULL,
            resolved_by_user_id = NULL,
            resolved_at = NULL,
            resolution_notes = NULL,
            message = VALUES(message),
            context_json = VALUES(context_json),
            detected_at = VALUES(detected_at);

        INSERT INTO operation_events (
            company_id, operation_id, event_type, event_data
        )
        SELECT
            ots.company_id,
            ots.operation_id,
            'TRACKING_SIGNAL_LOST',
            JSON_OBJECT(
                'last_position_at', ots.last_position_at,
                'departed_at', o.departed_at
            )
        FROM operation_tracking_status ots
        JOIN weighing_operations o
          ON o.company_id = ots.company_id
         AND o.id = ots.operation_id
        WHERE ots.company_id = p_company_id
          AND ots.tracking_state IN ('IN_TRANSIT', 'STOPPED')
          AND COALESCE(ots.last_position_at, o.departed_at) IS NOT NULL
          AND TIMESTAMPDIFF(
              MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
          ) >= v_signal_loss_minutes;

        UPDATE operation_tracking_status ots
        JOIN weighing_operations o
          ON o.company_id = ots.company_id
         AND o.id = ots.operation_id
           SET ots.tracking_state = 'SIGNAL_LOST'
         WHERE ots.company_id = p_company_id
           AND ots.tracking_state IN ('IN_TRANSIT', 'STOPPED')
           AND COALESCE(ots.last_position_at, o.departed_at) IS NOT NULL
           AND TIMESTAMPDIFF(
               MINUTE, COALESCE(ots.last_position_at, o.departed_at), CURRENT_TIMESTAMP(3)
           ) >= v_signal_loss_minutes;

        
        INSERT INTO alerts (
            company_id, operation_id, alert_context, calculation_version,
            alert_type, severity, state, source, deduplication_key,
            title, message, context_json, detected_at
        )
        SELECT
            o.company_id,
            o.id,
            'TRACKING',
            NULL,
            'DELIVERY_DELAY',
            'ATTENTION',
            'OPEN',
            'SYSTEM',
            CONCAT('DELIVERY_DELAY:', o.id),
            'Atraso na entrega',
            CONCAT(
                'O horário planejado de chegada foi excedido em aproximadamente ',
                TIMESTAMPDIFF(MINUTE, o.planned_arrival_at, CURRENT_TIMESTAMP(3)),
                ' minuto(s).'
            ),
            JSON_OBJECT(
                'planned_arrival_at', o.planned_arrival_at,
                'delay_minutes', TIMESTAMPDIFF(MINUTE, o.planned_arrival_at, CURRENT_TIMESTAMP(3)),
                'source', 'CURRENT_TIME'
            ),
            CURRENT_TIMESTAMP(3)
        FROM weighing_operations o
        LEFT JOIN operation_tracking_status ots
          ON ots.company_id = o.company_id
         AND ots.operation_id = o.id
        WHERE o.company_id = p_company_id
          AND o.state = 'COMPLETED'
          AND o.planned_arrival_at IS NOT NULL
          AND o.arrived_at IS NULL
          AND COALESCE(ots.tracking_state, 'NOT_STARTED') NOT IN ('ARRIVED', 'CANCELLED')
          AND TIMESTAMPDIFF(MINUTE, o.planned_arrival_at, CURRENT_TIMESTAMP(3)) >= v_delay_minutes
        ON DUPLICATE KEY UPDATE
            state = 'OPEN',
            message = VALUES(message),
            context_json = VALUES(context_json),
            detected_at = VALUES(detected_at);

        UPDATE operation_tracking_status ots
        JOIN weighing_operations o
          ON o.company_id = ots.company_id
         AND o.id = ots.operation_id
           SET ots.delay_minutes = GREATEST(
               0,
               TIMESTAMPDIFF(MINUTE, o.planned_arrival_at, CURRENT_TIMESTAMP(3))
           )
         WHERE ots.company_id = p_company_id
           AND o.planned_arrival_at IS NOT NULL
           AND o.arrived_at IS NULL
           AND ots.tracking_state NOT IN ('ARRIVED', 'CANCELLED');
    END IF;
END$$
DELIMITER ;

DELIMITER $$
DROP PROCEDURE IF EXISTS sp_finalize_weighing_operation$$
CREATE PROCEDURE sp_finalize_weighing_operation (
    IN p_company_id BIGINT UNSIGNED,
    IN p_operation_id BIGINT UNSIGNED,
    IN p_user_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_method VARCHAR(30);
    DECLARE v_state VARCHAR(30);
    DECLARE v_empty DECIMAL(14,3);
    DECLARE v_separated DECIMAL(14,3);
    DECLARE v_declared DECIMAL(14,3);
    DECLARE v_loaded DECIMAL(14,3);
    DECLARE v_expected DECIMAL(14,3);
    DECLARE v_actual_cargo DECIMAL(14,3);
    DECLARE v_difference DECIMAL(14,3);
    DECLARE v_difference_percent DECIMAL(10,4);
    DECLARE v_tare_difference_percent DECIMAL(10,4);
    DECLARE v_registered_tare DECIMAL(14,3);
    DECLARE v_gross_limit DECIMAL(14,3);
    DECLARE v_payload_limit DECIMAL(14,3);
    DECLARE v_tolerance DECIMAL(8,3);
    DECLARE v_critical DECIMAL(8,3);
    DECLARE v_tare_tolerance DECIMAL(8,3);
    DECLARE v_new_status VARCHAR(20) DEFAULT 'NORMAL';
    DECLARE v_status_reason VARCHAR(500) DEFAULT 'Pesagem dentro dos limites configurados.';
    DECLARE v_new_version INT UNSIGNED;
    DECLARE v_manual_count INT DEFAULT 0;
    DECLARE v_unstable_count INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT weighing_method,
           state,
           empty_truck_weight_kg,
           separated_cargo_weight_kg,
           declared_cargo_weight_kg,
           loaded_truck_weight_kg,
           registered_tare_snapshot_kg,
           gross_limit_snapshot_kg,
           payload_limit_snapshot_kg,
           tolerance_percent_snapshot,
           critical_limit_snapshot,
           tare_tolerance_snapshot,
           calculation_version + 1
      INTO v_method,
           v_state,
           v_empty,
           v_separated,
           v_declared,
           v_loaded,
           v_registered_tare,
           v_gross_limit,
           v_payload_limit,
           v_tolerance,
           v_critical,
           v_tare_tolerance,
           v_new_version
      FROM weighing_operations
     WHERE company_id = p_company_id
       AND id = p_operation_id
     FOR UPDATE;

    IF v_method IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operação de pesagem não encontrada.';
    END IF;

    IF v_state = 'CANCELLED' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Uma operação cancelada não pode ser finalizada.';
    END IF;

    IF v_empty IS NULL OR v_loaded IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'As leituras do caminhão vazio e carregado são obrigatórias.';
    END IF;

    IF v_method = 'THREE_STAGE' AND v_separated IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'A pesagem em três etapas exige o peso da carga separada.';
    END IF;

    SET v_actual_cargo = v_loaded - v_empty;

    IF v_actual_cargo < 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'O peso carregado não pode ser menor que o peso vazio.';
    END IF;

    IF v_method = 'THREE_STAGE' THEN
        SET v_expected = v_empty + v_separated;
    ELSEIF v_declared IS NOT NULL THEN
        SET v_expected = v_empty + v_declared;
    ELSE
        SET v_expected = v_loaded;
    END IF;

    SET v_difference = v_loaded - v_expected;
    SET v_difference_percent =
        CASE
            WHEN v_expected > 0 THEN ROUND((v_difference / v_expected) * 100, 4)
            ELSE 0
        END;

    SET v_tare_difference_percent =
        CASE
            WHEN v_registered_tare IS NOT NULL AND v_registered_tare > 0
                THEN ROUND((ABS(v_empty - v_registered_tare) / v_registered_tare) * 100, 4)
            ELSE NULL
        END;

    IF ABS(v_difference_percent) > v_critical THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Divergência de peso acima do limite crítico.';
    ELSEIF ABS(v_difference_percent) > v_tolerance THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'Divergência de peso acima da tolerância operacional.';
    END IF;

    IF v_gross_limit IS NOT NULL AND v_gross_limit > 0 AND v_loaded > v_gross_limit THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Peso bruto acima do limite cadastrado para o veículo.';
    END IF;

    IF v_payload_limit IS NOT NULL AND v_payload_limit > 0 AND v_actual_cargo > v_payload_limit THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'Carga líquida acima da capacidade cadastrada para o veículo.';
    END IF;

    IF v_tare_difference_percent IS NOT NULL
       AND v_tare_difference_percent > v_tare_tolerance
       AND v_new_status = 'NORMAL' THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'Peso vazio divergente da tara cadastrada.';
    END IF;

    SELECT COUNT(*)
      INTO v_manual_count
      FROM weighing_readings
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND is_accepted = 1
       AND source = 'MANUAL';

    SELECT COUNT(*)
      INTO v_unstable_count
      FROM weighing_readings
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND is_accepted = 1
       AND is_stable = 0;

    IF v_manual_count > 0 AND v_new_status = 'NORMAL' THEN
        SET v_new_status = 'ATTENTION';
        SET v_status_reason = 'A operação contém ao menos uma leitura manual.';
    END IF;

    IF v_unstable_count > 0 THEN
        SET v_new_status = 'CRITICAL';
        SET v_status_reason = 'A operação contém leitura aceita sem estabilidade.';
    END IF;

    UPDATE alerts
       SET state = 'RESOLVED',
           resolved_by_user_id = p_user_id,
           resolved_at = CURRENT_TIMESTAMP(3),
           resolution_notes = 'Alerta substituído por um novo cálculo da operação.'
     WHERE company_id = p_company_id
       AND operation_id = p_operation_id
       AND source = 'SYSTEM'
       AND alert_context = 'WEIGHING'
       AND state IN ('OPEN', 'ACKNOWLEDGED');

    UPDATE weighing_operations
       SET expected_gross_weight_kg = v_expected,
           actual_cargo_weight_kg = v_actual_cargo,
           difference_kg = v_difference,
           difference_percent = v_difference_percent,
           tare_difference_percent = v_tare_difference_percent,
           status = v_new_status,
           status_reason = v_status_reason,
           calculation_version = v_new_version,
           state = 'COMPLETED',
           completed_at = CURRENT_TIMESTAMP(3)
     WHERE company_id = p_company_id
       AND id = p_operation_id;

    IF v_gross_limit IS NOT NULL AND v_gross_limit > 0 AND v_loaded > v_gross_limit THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'OVER_GROSS_LIMIT', 'CRITICAL',
            'Peso bruto acima do limite',
            CONCAT(
                'Peso medido: ', FORMAT(v_loaded, 3),
                ' kg. Limite do veículo: ', FORMAT(v_gross_limit, 3), ' kg.'
            ),
            v_loaded - v_gross_limit,
            ROUND(((v_loaded - v_gross_limit) / v_gross_limit) * 100, 4)
        );
    END IF;

    IF v_payload_limit IS NOT NULL AND v_payload_limit > 0 AND v_actual_cargo > v_payload_limit THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'OVER_PAYLOAD_LIMIT', 'CRITICAL',
            'Carga acima da capacidade',
            CONCAT(
                'Carga calculada: ', FORMAT(v_actual_cargo, 3),
                ' kg. Capacidade cadastrada: ', FORMAT(v_payload_limit, 3), ' kg.'
            ),
            v_actual_cargo - v_payload_limit,
            ROUND(((v_actual_cargo - v_payload_limit) / v_payload_limit) * 100, 4)
        );
    END IF;

    IF ABS(v_difference_percent) > v_tolerance THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id,
            p_operation_id,
            v_new_version,
            IF(v_difference < 0, 'POSSIBLE_MISSING_CARGO', 'POSSIBLE_EXTRA_CARGO'),
            IF(ABS(v_difference_percent) > v_critical, 'CRITICAL', 'ATTENTION'),
            IF(v_difference < 0, 'Possível falta de carga', 'Possível excesso de carga'),
            CONCAT(
                'Diferença detectada: ', FORMAT(v_difference, 3),
                ' kg (', FORMAT(v_difference_percent, 4), '%).'
            ),
            v_difference,
            v_difference_percent
        );
    END IF;

    IF v_tare_difference_percent IS NOT NULL
       AND v_tare_difference_percent > v_tare_tolerance THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message,
            difference_kg, difference_percent
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'TARE_DIVERGENCE', 'ATTENTION',
            'Divergência na tara do veículo',
            CONCAT(
                'Peso vazio medido: ', FORMAT(v_empty, 3),
                ' kg. Tara cadastrada: ', FORMAT(v_registered_tare, 3),
                ' kg. Divergência: ', FORMAT(v_tare_difference_percent, 4), '%.'
            ),
            v_empty - v_registered_tare,
            v_tare_difference_percent
        );
    END IF;

    IF v_manual_count > 0 THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'MANUAL_READING', 'ATTENTION',
            'Leitura manual utilizada',
            CONCAT('A operação possui ', v_manual_count, ' leitura(s) manual(is) aceita(s).')
        );
    END IF;

    IF v_unstable_count > 0 THEN
        INSERT INTO alerts (
            company_id, operation_id, calculation_version,
            alert_type, severity, title, message
        ) VALUES (
            p_company_id, p_operation_id, v_new_version,
            'UNSTABLE_READING', 'CRITICAL',
            'Leitura instável aceita',
            CONCAT('A operação possui ', v_unstable_count, ' leitura(s) aceita(s) sem estabilidade.')
        );
    END IF;

    INSERT INTO operation_events (
        company_id,
        operation_id,
        event_type,
        user_id,
        event_data
    ) VALUES (
        p_company_id,
        p_operation_id,
        'FINALIZED',
        p_user_id,
        JSON_OBJECT(
            'calculation_version', v_new_version,
            'status', v_new_status,
            'expected_gross_weight_kg', v_expected,
            'loaded_truck_weight_kg', v_loaded,
            'actual_cargo_weight_kg', v_actual_cargo,
            'difference_kg', v_difference,
            'difference_percent', v_difference_percent
        )
    );

    COMMIT;
END$$
DELIMITER ;

CREATE OR REPLACE VIEW vw_active_operation_tracking AS
SELECT
    ots.company_id,
    ots.operation_id,
    o.operation_code,
    o.state AS weighing_state,
    o.status AS weighing_status,
    o.planned_departure_at,
    o.departed_at,
    o.planned_arrival_at,
    o.arrived_at,
    v.plate AS vehicle_plate,
    d.full_name AS driver_name,
    rt.origin,
    rt.destination,
    rt.distance_km,
    ots.tracking_state,
    ots.stopped_since,
    ots.last_moving_at,
    ots.current_latitude,
    ots.current_longitude,
    ots.speed_kmh,
    ots.heading_degrees,
    ots.progress_percent,
    ots.route_deviation_meters,
    ots.estimated_arrival_at,
    ots.delay_minutes,
    ots.last_position_at
FROM operation_tracking_status ots
JOIN weighing_operations o
  ON o.company_id = ots.company_id
 AND o.id = ots.operation_id
JOIN vehicles v
  ON v.company_id = o.company_id
 AND v.id = o.vehicle_id
LEFT JOIN drivers d
  ON d.company_id = o.company_id
 AND d.id = o.driver_id
LEFT JOIN routes rt
  ON rt.company_id = o.company_id
 AND rt.id = o.route_id
WHERE ots.tracking_state IN ('NOT_STARTED', 'IN_TRANSIT', 'STOPPED', 'SIGNAL_LOST');

CREATE OR REPLACE VIEW vw_mobile_active_operations AS
SELECT
    o.company_id,
    o.id AS operation_id,
    o.operation_code,
    o.state AS weighing_state,
    o.status AS weighing_status,
    o.started_at,
    o.completed_at,
    o.planned_departure_at,
    o.departed_at,
    o.planned_arrival_at,
    o.arrived_at,
    v.plate AS vehicle_plate,
    d.full_name AS driver_name,
    cp.name AS cargo_product_name,
    rt.origin,
    rt.destination,
    COALESCE(ots.tracking_state, 'NOT_STARTED') AS tracking_state,
    ots.progress_percent,
    ots.estimated_arrival_at,
    ots.delay_minutes,
    ots.last_position_at
FROM weighing_operations o
JOIN vehicles v
  ON v.company_id = o.company_id
 AND v.id = o.vehicle_id
LEFT JOIN drivers d
  ON d.company_id = o.company_id
 AND d.id = o.driver_id
LEFT JOIN cargo_products cp
  ON cp.company_id = o.company_id
 AND cp.id = o.cargo_product_id
LEFT JOIN routes rt
  ON rt.company_id = o.company_id
 AND rt.id = o.route_id
LEFT JOIN operation_tracking_status ots
  ON ots.company_id = o.company_id
 AND ots.operation_id = o.id
WHERE o.state IN ('DRAFT', 'IN_PROGRESS')
   OR (
        o.state = 'COMPLETED'
        AND o.route_id IS NOT NULL
        AND COALESCE(ots.tracking_state, 'NOT_STARTED')
            IN ('NOT_STARTED', 'IN_TRANSIT', 'STOPPED', 'SIGNAL_LOST')
   );

CREATE OR REPLACE VIEW vw_mobile_completed_operations AS
SELECT
    o.company_id,
    o.id AS operation_id,
    o.operation_code,
    o.status AS weighing_status,
    o.completed_at,
    o.departed_at,
    o.arrived_at,
    v.plate AS vehicle_plate,
    d.full_name AS driver_name,
    cp.name AS cargo_product_name,
    rt.origin,
    rt.destination,
    COALESCE(ots.tracking_state, 'ARRIVED') AS tracking_state
FROM weighing_operations o
JOIN vehicles v
  ON v.company_id = o.company_id
 AND v.id = o.vehicle_id
LEFT JOIN drivers d
  ON d.company_id = o.company_id
 AND d.id = o.driver_id
LEFT JOIN cargo_products cp
  ON cp.company_id = o.company_id
 AND cp.id = o.cargo_product_id
LEFT JOIN routes rt
  ON rt.company_id = o.company_id
 AND rt.id = o.route_id
LEFT JOIN operation_tracking_status ots
  ON ots.company_id = o.company_id
 AND ots.operation_id = o.id
WHERE o.state = 'COMPLETED'
  AND (
      o.route_id IS NULL
      OR ots.tracking_state = 'ARRIVED'
  );

CREATE OR REPLACE VIEW vw_ai_latest_insights AS
SELECT
    i.company_id,
    i.id AS insight_id,
    i.analysis_run_id,
    r.scope,
    r.status AS analysis_status,
    i.operation_id,
    i.insight_type,
    i.severity,
    i.title,
    i.description,
    i.confidence_percent,
    i.evidence_json,
    i.created_at
FROM ai_insights i
JOIN ai_analysis_runs r
  ON r.company_id = i.company_id
 AND r.id = i.analysis_run_id
WHERE r.status = 'COMPLETED';

CREATE OR REPLACE VIEW vw_company_current_subscription AS
SELECT
    cs.company_id,
    cs.id AS subscription_id,
    cs.status,
    cs.starts_at,
    cs.current_period_start,
    cs.current_period_end,
    p.id AS plan_id,
    p.code AS plan_code,
    p.name AS plan_name,
    p.monthly_price_brl,
    p.features_json
FROM company_subscriptions cs
JOIN subscription_plans p ON p.id = cs.plan_id
WHERE cs.status IN ('TRIAL', 'ACTIVE', 'PAST_DUE');

DROP PROCEDURE IF EXISTS sp_v3_add_column_if_missing;
DROP PROCEDURE IF EXISTS sp_v3_add_index_if_missing;
DROP PROCEDURE IF EXISTS sp_v3_add_check_if_missing;

USE loadsense;

CREATE TABLE IF NOT EXISTS company_requests (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    legal_name          VARCHAR(180) NOT NULL,
    document_number     VARCHAR(20) NOT NULL,
    responsible_name    VARCHAR(140) NOT NULL,
    email               VARCHAR(160) NOT NULL,
    phone               VARCHAR(30) NULL,
    privacy_accepted    TINYINT(1) NOT NULL DEFAULT 0,
    status              ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_company_requests_status_date (status, created_at),
    KEY idx_company_requests_document (document_number),
    CONSTRAINT chk_company_requests_privacy CHECK (privacy_accepted IN (0,1))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id          BIGINT UNSIGNED NOT NULL,
    user_id             BIGINT UNSIGNED NOT NULL,
    token_hash          CHAR(64) NOT NULL,
    expires_at          DATETIME(3) NOT NULL,
    used_at             DATETIME(3) NULL,
    created_at          DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_password_reset_token_hash (token_hash),
    KEY idx_password_reset_user_expiry (company_id, user_id, expires_at),
    CONSTRAINT fk_password_reset_user
        FOREIGN KEY (company_id, user_id)
        REFERENCES users(company_id, id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

USE loadsense;

SET @company_id := (
    SELECT id FROM companies WHERE slug = 'loadsense-demo' LIMIT 1
);
SET @admin_role_id := (
    SELECT id FROM roles
     WHERE company_id = @company_id
       AND name = 'ADMINISTRATOR'
     LIMIT 1
);

INSERT INTO users (
    company_id,
    role_id,
    full_name,
    email,
    password_hash,
    active,
    must_change_password
)
SELECT
    @company_id,
    @admin_role_id,
    'Administrador LoadSense',
    'admin@loadsense.local',
    '$2b$12$5aZyYIc63Y/mTa9kjRvCjuP02tHJ5DbV7VCb3OX4VzwtqVwLSIkSq',
    1,
    0
WHERE @company_id IS NOT NULL
  AND @admin_role_id IS NOT NULL
  AND NOT EXISTS (
      SELECT 1
        FROM users
       WHERE company_id = @company_id
         AND email = 'admin@loadsense.local'
  );
