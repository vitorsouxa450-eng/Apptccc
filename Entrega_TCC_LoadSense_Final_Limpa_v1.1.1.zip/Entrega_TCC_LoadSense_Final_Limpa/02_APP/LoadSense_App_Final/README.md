# LoadSense Mobile

Versão 0.2.0 do aplicativo do TCC LoadSense, construída com React Native, Expo, TypeScript e Expo Router para desenvolvimento no VS Code.

## O que já funciona

- Splash e bootstrap com estados de carregamento, erro, manutenção e atualização obrigatória.
- Login multiempresa com validação de empresa, e-mail e senha.
- Conta demonstrativa e sessão persistida com `expo-secure-store`.
- Recuperação de senha com mensagem que evita enumeração de usuários.
- Solicitação de cadastro de empresa sem escolha pública de perfil.
- Termos de Uso e Aviso de Privacidade, com aceite obrigatório após o primeiro login.
- Área autenticada com cinco abas: Dashboard, Operações, Monitoramento, Relatórios e Configurações.
- Identidade visual com logotipo LoadSense no topo e modo escuro fiel ao protótipo.
- Tema claro e escuro com preferência persistida no aparelho.
- Dashboard com nível operacional, indicadores, gráfico, operação ativa e alertas.
- Operações com abas Ativas/Concluídas, busca e detalhe em Resumo, Pesagens, Trajeto e Alertas.
- Monitoramento em mapa/lista, RFID, sinal, posição e progresso de rota.
- Relatórios por período com métricas, gráficos, distribuição de cargas e geração simulada.
- Configurações com Planos, Alertas, Histórico de Pesagens, Status do Sistema, Preferências e Sobre.
- Estados de loading, vazio, erro e offline.
- Logout com revogação simulada e remoção do token local.
- Layout responsivo para Android, iOS e Web.

## Preparação no Windows

1. Instale o [Node.js LTS](https://nodejs.org/) versão 20.19.4 ou superior.
2. Instale o [VS Code](https://code.visualstudio.com/).
3. Instale o aplicativo Expo Go no celular.
4. Abra esta pasta no VS Code.

No terminal integrado:

```bash
npm install
copy .env.example .env
npx expo start
```

No macOS ou Linux, use `cp .env.example .env` no lugar de `copy`.

Depois, leia o QR Code com o Expo Go. Computador e celular devem estar na mesma rede. Se a rede bloquear a conexão local, rode `npx expo start --tunnel`.

## Conta demonstrativa

Na tela de Login, toque em **Preencher acesso demo** ou informe:

```text
Empresa: loadsense-demo
E-mail: admin@loadsense.com
Senha: LoadSense@123
```

O primeiro login abre os documentos legais. Ative a confirmação e toque em **Aceitar e continuar**.

## Revisar estados de interface

Edite `.env` e reinicie o Expo quando mudar uma variável.

```dotenv
# ready | maintenance | update
EXPO_PUBLIC_MOCK_BOOTSTRAP_STATE=ready

# success | empty | error | loading
EXPO_PUBLIC_MOCK_DASHBOARD_STATE=success
```

Para validar o modo offline, desligue a conexão do aparelho com o aplicativo aberto.

## Estrutura principal

```text
app/                         Rotas e telas do Expo Router
  (auth)/                    Login, recuperação e cadastro da empresa
  (tabs)/                    Cinco abas autenticadas
src/
  components/                Componentes visuais reutilizáveis
  providers/                 Sessão e conectividade
  services/                  Cliente HTTP da API e armazenamento seguro
  theme/                     Cores, fontes, espaços e raios
  types/                     Contratos TypeScript
docs/API_CONTRACT.md         Contrato da API REST usada pelo app
```

## Arquitetura e segurança

- O aplicativo nunca se conecta diretamente ao MySQL.
- O cliente HTTP em `src/services/api.ts` consome a API REST; o MySQL fica atrás do backend.
- O login é multiempresa: `companyCode + email + password`.
- Empresa, perfil e permissões vêm da sessão retornada pelo servidor.
- O `accessToken` permanece em memória; somente o `refreshToken` é persistido no SecureStore.
- Senhas, hashes, tokens, auditoria e regras de autorização pertencem ao backend.
- O cadastro público gera uma solicitação. Após aprovação, o primeiro convite cria o Administrador.

Consulte [docs/API_CONTRACT.md](docs/API_CONTRACT.md) para manter o app e o backend compatíveis.

## Comandos úteis

```bash
npm run start
npm run typecheck
npm run lint
npm run doctor
```

## Próxima etapa recomendada

Configurar `EXPO_PUBLIC_API_URL`, aplicar a migração de suporte do backend e criar o primeiro usuário administrador. O aplicativo deve consumir a API; nunca deve se conectar diretamente ao MySQL.

## Integração com API REST

Use `src/services/api.ts` e configure `EXPO_PUBLIC_API_URL` para o backend REST. O aplicativo não acessa MySQL diretamente.
