import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Pressable, StyleSheet, Switch, View } from 'react-native';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { BrandMark } from '@/components/brand-mark';
import { Screen } from '@/components/screen';
import { useSession } from '@/providers/session-provider';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
type DocumentType = 'terms' | 'privacy';
const content = {
    terms: {
        title: 'Termos de Uso',
        sections: [
            ['1. Finalidade', 'O LoadSense apoia o monitoramento de cargas, pesagens, trajetos, alertas e relatórios operacionais. As informações devem ser usadas somente para as atividades autorizadas pela empresa.'],
            ['2. Conta e acesso', 'Cada pessoa deve usar sua própria conta. Empresa, perfil e permissões são definidos pelo serviço e não podem ser alterados pelo aplicativo. É proibido compartilhar senha ou tentar acessar dados de outra empresa.'],
            ['3. Dados operacionais', 'Os indicadores auxiliam a tomada de decisão, mas não substituem verificações de segurança, manutenção dos equipamentos ou obrigações legais do transporte.'],
            ['4. Uso adequado', 'O usuário deve manter os dados corretos, relatar acessos suspeitos e respeitar as permissões atribuídas. Ações relevantes podem ser registradas para auditoria.'],
            ['5. Disponibilidade', 'Manutenções, falhas de conectividade e atualizações podem limitar temporariamente o serviço. O aplicativo identificará situações de indisponibilidade sempre que possível.'],
        ],
    },
    privacy: {
        title: 'Aviso de Privacidade',
        sections: [
            ['1. Dados tratados', 'Podemos tratar dados de identificação e contato, vínculo com a empresa, sessão, dispositivo, preferências, registros de auditoria e dados operacionais necessários ao LoadSense.'],
            ['2. Finalidades', 'Os dados são usados para autenticar usuários, separar empresas, aplicar permissões, monitorar operações, emitir alertas, produzir relatórios, prevenir fraudes e cumprir obrigações aplicáveis.'],
            ['3. Segurança', 'Senhas são processadas no servidor com hash seguro. O aplicativo armazena somente o token de renovação em armazenamento protegido; ele nunca acessa o banco MySQL diretamente.'],
            ['4. Compartilhamento e retenção', 'O acesso é limitado a pessoas e fornecedores necessários à operação, conforme contratos e regras de segurança. Os dados são mantidos pelo período necessário às finalidades e obrigações legais.'],
            ['5. Direitos', 'O titular poderá solicitar informações, correção e demais direitos aplicáveis por meio do canal definido pela empresa controladora dos dados.'],
        ],
    },
} as const;
export default function LegalScreen() {
    const params = useLocalSearchParams<{
        document?: string;
    }>();
    const { session, acceptTerms, logout } = useSession();
    const theme = useAppTheme();
    const [selected, setSelected] = useState<DocumentType>(params.document === 'privacy' ? 'privacy' : 'terms');
    const [accepted, setAccepted] = useState(false);
    const [saving, setSaving] = useState(false);
    const requiresConsent = Boolean(session && !session.termsAccepted);
    const document = content[selected];
    async function confirm() {
        setSaving(true);
        try {
            await acceptTerms();
            router.replace('/dashboard');
        }
        finally {
            setSaving(false);
        }
    }
    async function leave() {
        if (session)
            await logout();
        router.replace('/login');
    }
    return (<Screen contentStyle={styles.content}>
      <View style={styles.header}>
        <BrandMark compact/>
        <Pressable accessibilityLabel="Fechar" hitSlop={10} onPress={() => requiresConsent ? void leave() : router.back()}>
          <Ionicons name="close" size={26} color={theme.colors.icon}/>
        </Pressable>
      </View>

      <View style={styles.intro}>
        <AppText variant="title">Transparência e segurança</AppText>
        <AppText color={theme.colors.textSecondary}>Atualizado em 25 de agosto de 2026.</AppText>
      </View>

      <View style={[styles.tabs, { backgroundColor: theme.colors.surfaceMuted }]}>
        {(['terms', 'privacy'] as const).map((item) => (<Pressable key={item} accessibilityRole="tab" accessibilityState={{ selected: selected === item }} onPress={() => setSelected(item)} style={[styles.tab, selected === item && styles.tabActive]}>
            <AppText variant="label" color={selected === item ? colors.white : theme.colors.textSecondary}>
              {item === 'terms' ? 'Termos de Uso' : 'Privacidade'}
            </AppText>
          </Pressable>))}
      </View>

      <View style={[styles.document, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
        <AppText variant="title">{document.title}</AppText>
        {document.sections.map(([title, paragraph]) => (<View key={title} style={styles.section}>
            <AppText variant="subtitle">{title}</AppText>
            <AppText color={theme.colors.textSecondary}>{paragraph}</AppText>
          </View>))}
      </View>

      {requiresConsent ? (<View style={[styles.consent, { backgroundColor: theme.colors.surface }]}>
          <View style={styles.switchRow}>
            <Switch accessibilityLabel="Concordar com os Termos de Uso e o Aviso de Privacidade" trackColor={{ false: theme.colors.surfaceMuted, true: colors.orangeDark }} thumbColor={accepted ? colors.orange : theme.colors.textMuted} value={accepted} onValueChange={setAccepted}/>
            <AppText variant="label" style={styles.switchText}>
              Li e concordo com os Termos de Uso e com o Aviso de Privacidade.
            </AppText>
          </View>
          <AppButton label="Aceitar e continuar" disabled={!accepted} loading={saving} onPress={() => void confirm()}/>
          <AppButton label="Sair da conta" variant="ghost" disabled={saving} onPress={() => void leave()}/>
        </View>) : null}
    </Screen>);
}
const styles = StyleSheet.create({
    content: {
        alignSelf: 'center',
        maxWidth: 720,
        width: '100%',
    },
    header: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    intro: {
        gap: spacing.xs,
        marginBottom: spacing.xl,
        marginTop: spacing.xxxl,
    },
    tabs: {
        borderRadius: radius.md,
        flexDirection: 'row',
        marginBottom: spacing.lg,
        padding: spacing.xs,
    },
    tab: {
        alignItems: 'center',
        borderRadius: radius.sm,
        flex: 1,
        padding: spacing.md,
    },
    tabActive: {
        backgroundColor: colors.orange,
    },
    document: {
        borderRadius: radius.lg,
        borderWidth: 1,
        gap: spacing.xl,
        padding: spacing.xl,
    },
    section: {
        gap: spacing.sm,
    },
    consent: {
        borderColor: colors.orange,
        borderRadius: radius.lg,
        borderWidth: 1,
        gap: spacing.lg,
        marginTop: spacing.xl,
        padding: spacing.lg,
    },
    switchRow: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.md,
    },
    switchText: {
        flex: 1,
    },
});
