import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { BrandMark } from '@/components/brand-mark';
import { Screen } from '@/components/screen';
import { SubpageHeader } from '@/components/subpage-header';
import { APP_VERSION } from '@/constants/app';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
export default function AboutScreen() {
    const theme = useAppTheme();
    return (<Screen contentStyle={styles.content}>
      <SubpageHeader title="Sobre o LoadSense" subtitle={`Versão ${APP_VERSION}`}/>

      <View style={[styles.brandCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
        <BrandMark />
        <AppText color={theme.colors.textSecondary}>
          Plataforma de pesagem, rastreamento RFID e gestão logística criada como Trabalho de Conclusão de Curso da ETEC de Taboão da Serra.
        </AppText>
      </View>

      <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
        <AboutRow icon="school-outline" title="Projeto acadêmico" description="Ensino Médio Integrado ao Técnico em Desenvolvimento de Sistemas"/>
        <AboutRow icon="people-outline" title="Equipe" description="Levi, Pedro, Vitor Silva e Vítor Rangel"/>
        <AboutRow icon="shield-checkmark-outline" title="Arquitetura segura" description="Aplicativo → API REST → MySQL 8 V3.1"/>
        <AboutRow icon="code-slash-outline" title="Tecnologias" description="React Native, Expo, TypeScript, ESP32 e RFID"/>
      </View>

      <View style={[styles.note, { backgroundColor: theme.colors.orangeSoft }]}>
        <Ionicons name="information-circle" size={20} color={colors.orange}/>
        <AppText variant="caption" color={theme.colors.textSecondary} style={styles.noteText}>
          Esta versão utiliza dados simulados no formato da futura API para validar navegação, visual e regras do projeto.
        </AppText>
      </View>
    </Screen>);
}
type AboutRowProps = {
    icon: keyof typeof Ionicons.glyphMap;
    title: string;
    description: string;
};
function AboutRow({ icon, title, description }: AboutRowProps) {
    const theme = useAppTheme();
    return (<View style={[styles.row, { borderBottomColor: theme.colors.border }]}>
      <View style={[styles.icon, { backgroundColor: theme.colors.orangeSoft }]}>
        <Ionicons name={icon} size={20} color={colors.orange}/>
      </View>
      <View style={styles.rowCopy}>
        <AppText variant="label">{title}</AppText>
        <AppText variant="caption" color={theme.colors.textSecondary}>{description}</AppText>
      </View>
    </View>);
}
const styles = StyleSheet.create({
    content: {
        alignSelf: 'center',
        maxWidth: 720,
        width: '100%',
    },
    brandCard: {
        borderRadius: radius.md,
        borderWidth: 1,
        gap: spacing.lg,
        marginTop: spacing.xxl,
        padding: spacing.xl,
    },
    card: {
        borderRadius: radius.md,
        borderWidth: 1,
        marginTop: spacing.xl,
        overflow: 'hidden',
    },
    row: {
        alignItems: 'center',
        borderBottomWidth: 1,
        flexDirection: 'row',
        gap: spacing.md,
        padding: spacing.md,
    },
    icon: {
        alignItems: 'center',
        borderRadius: radius.sm,
        height: 40,
        justifyContent: 'center',
        width: 40,
    },
    rowCopy: {
        flex: 1,
    },
    note: {
        alignItems: 'flex-start',
        borderRadius: radius.md,
        flexDirection: 'row',
        gap: spacing.md,
        marginBottom: spacing.xl,
        marginTop: spacing.xl,
        padding: spacing.md,
    },
    noteText: {
        flex: 1,
    },
});
