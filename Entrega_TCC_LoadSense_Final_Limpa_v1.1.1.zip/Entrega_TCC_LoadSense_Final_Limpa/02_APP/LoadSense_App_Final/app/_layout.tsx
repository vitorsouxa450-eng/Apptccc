import { Montserrat_600SemiBold, Montserrat_700Bold, useFonts as useMontserratFonts, } from '@expo-google-fonts/montserrat';
import { OpenSans_400Regular, OpenSans_600SemiBold, OpenSans_700Bold, useFonts as useOpenSansFonts, } from '@expo-google-fonts/open-sans';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NetworkProvider } from '@/providers/network-provider';
import { SessionProvider } from '@/providers/session-provider';
import { ThemeProvider, useAppTheme } from '@/providers/theme-provider';
void SplashScreen.preventAutoHideAsync();
const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            retry: 1,
            staleTime: 30000,
        },
    },
});
export default function RootLayout() {
    const [montserratLoaded, montserratError] = useMontserratFonts({
        Montserrat_600SemiBold,
        Montserrat_700Bold,
    });
    const [openSansLoaded, openSansError] = useOpenSansFonts({
        OpenSans_400Regular,
        OpenSans_600SemiBold,
        OpenSans_700Bold,
    });
    const ready = (montserratLoaded && openSansLoaded) || Boolean(montserratError || openSansError);
    useEffect(() => {
        if (ready)
            void SplashScreen.hideAsync();
    }, [ready]);
    if (!ready)
        return null;
    return (<SafeAreaProvider>
      <ThemeProvider>
        <NetworkProvider>
          <QueryClientProvider client={queryClient}>
            <SessionProvider>
              <ThemedNavigation />
            </SessionProvider>
          </QueryClientProvider>
        </NetworkProvider>
      </ThemeProvider>
    </SafeAreaProvider>);
}
function ThemedNavigation() {
    const theme = useAppTheme();
    return (<>
      <StatusBar style={theme.isDark ? 'light' : 'dark'} backgroundColor={theme.colors.background}/>
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: theme.colors.background } }}>
        <Stack.Screen name="index"/>
        <Stack.Screen name="(auth)"/>
        <Stack.Screen name="(tabs)"/>
        <Stack.Screen name="operation/[id]"/>
        <Stack.Screen name="plans"/>
        <Stack.Screen name="preferences"/>
        <Stack.Screen name="system-status"/>
        <Stack.Screen name="weighing-history"/>
        <Stack.Screen name="about"/>
        <Stack.Screen name="legal" options={{ presentation: 'modal' }}/>
        <Stack.Screen name="notifications"/>
        <Stack.Screen name="maintenance"/>
        <Stack.Screen name="update-required"/>
      </Stack>
    </>);
}
