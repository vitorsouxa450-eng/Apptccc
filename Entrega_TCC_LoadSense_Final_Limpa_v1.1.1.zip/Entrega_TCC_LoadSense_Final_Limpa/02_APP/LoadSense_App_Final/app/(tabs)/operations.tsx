import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { OperationCard } from '@/components/operation-card';
import { PageHeader } from '@/components/page-header';
import { Screen } from '@/components/screen';
import { SearchField } from '@/components/search-field';
import { SegmentedControl } from '@/components/segmented-control';
import { StatusState } from '@/components/status-state';
import { useAppTheme } from '@/providers/theme-provider';
import { api } from '@/services/api';
import { colors, radius, spacing } from '@/theme/tokens';
import type { OperationState } from '@/types/operations';
export default function OperationsScreen() {
    const theme = useAppTheme();
    const [state, setState] = useState<OperationState>('ACTIVE');
    const [search, setSearch] = useState('');
    const query = useQuery({ queryKey: ['operations'], queryFn: api.getOperations });
    const operations = useMemo(() => {
        const term = search.trim().toLowerCase();
        return (query.data ?? []).filter((operation) => {
            const matchesState = operation.state === state;
            const matchesSearch = !term || [operation.code, operation.plate, operation.driver, operation.cargo]
                .some((value) => value.toLowerCase().includes(term));
            return matchesState && matchesSearch;
        });
    }, [query.data, search, state]);
    if (query.isPending) {
        return (<Screen scroll={false} contentStyle={styles.loading}>
        <ActivityIndicator color={colors.orange} size="large"/>
        <AppText color={theme.colors.textSecondary}>Carregando operações...</AppText>
      </Screen>);
    }
    if (query.isError) {
        return (<Screen scroll={false}>
        <StatusState icon="warning-outline" title="Operações indisponíveis" description="Não foi possível carregar os dados agora." actionLabel="Tentar novamente" onAction={() => void query.refetch()} tone="error"/>
      </Screen>);
    }
    const activeCount = query.data.filter((item) => item.state === 'ACTIVE').length;
    const completedCount = query.data.filter((item) => item.state === 'COMPLETED').length;
    return (<Screen contentStyle={styles.content}>
      <PageHeader title="Operações" subtitle="Cargas ativas e concluídas"/>
      <View style={styles.summaryRow}>
        <View style={[styles.summaryCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <View style={[styles.summaryIcon, { backgroundColor: theme.colors.orangeSoft }]}><Ionicons name="navigate" size={19} color={colors.orange}/></View>
          <AppText variant="metric">{activeCount}</AppText>
          <AppText variant="caption" color={theme.colors.textSecondary}>Em andamento</AppText>
        </View>
        <View style={[styles.summaryCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <View style={[styles.summaryIcon, { backgroundColor: theme.colors.greenSoft }]}><Ionicons name="checkmark-circle" size={19} color={colors.green}/></View>
          <AppText variant="metric">{completedCount}</AppText>
          <AppText variant="caption" color={theme.colors.textSecondary}>Concluídas</AppText>
        </View>
      </View>
      <SegmentedControl options={[{ label: 'Ativas', value: 'ACTIVE' }, { label: 'Concluídas', value: 'COMPLETED' }]} value={state} onChange={setState}/>
      <View style={styles.search}><SearchField value={search} onChangeText={setSearch} placeholder="Buscar placa, operação ou motorista"/></View>
      <View style={styles.listHeader}>
        <AppText variant="subtitle">{state === 'ACTIVE' ? 'Operações em andamento' : 'Histórico concluído'}</AppText>
        <AppText variant="caption" color={theme.colors.textMuted}>{operations.length} registros</AppText>
      </View>
      <View style={styles.list}>
        {operations.length ? operations.map((operation) => <OperationCard key={operation.id} operation={operation}/>) : (<View style={[styles.empty, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
            <Ionicons name="search-outline" size={30} color={theme.colors.textMuted}/>
            <AppText variant="label">Nenhuma operação encontrada</AppText>
            <AppText variant="caption" color={theme.colors.textSecondary}>Ajuste a busca ou altere o filtro.</AppText>
          </View>)}
      </View>
    </Screen>);
}
const styles = StyleSheet.create({
    content: { alignSelf: 'center', maxWidth: 760, width: '100%' },
    loading: { alignItems: 'center', gap: spacing.lg, justifyContent: 'center' },
    summaryRow: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.xl, marginTop: spacing.xxl },
    summaryCard: { borderRadius: radius.md, borderWidth: 1, flex: 1, padding: spacing.md },
    summaryIcon: { alignItems: 'center', borderRadius: radius.sm, height: 34, justifyContent: 'center', marginBottom: spacing.sm, width: 34 },
    search: { marginTop: spacing.md },
    listHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.xxl },
    list: { gap: spacing.md, marginTop: spacing.md },
    empty: { alignItems: 'center', borderRadius: radius.md, borderWidth: 1, gap: spacing.sm, padding: spacing.xxl },
});
