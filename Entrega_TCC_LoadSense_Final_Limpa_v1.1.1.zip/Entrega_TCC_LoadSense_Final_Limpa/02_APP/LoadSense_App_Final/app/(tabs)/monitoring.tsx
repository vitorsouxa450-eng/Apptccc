import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { OperationCard } from '@/components/operation-card';
import { PageHeader } from '@/components/page-header';
import { Screen } from '@/components/screen';
import { SearchField } from '@/components/search-field';
import { SegmentedControl } from '@/components/segmented-control';
import { useAppTheme } from '@/providers/theme-provider';
import { api } from '@/services/api';
import { colors, radius, spacing } from '@/theme/tokens';
import type { Operation } from '@/types/operations';
type ViewMode = 'MAP' | 'LIST';
export default function MonitoringScreen() {
    const theme = useAppTheme();
    const [viewMode, setViewMode] = useState<ViewMode>('MAP');
    const [search, setSearch] = useState('');
    const query = useQuery({ queryKey: ['monitoring'], queryFn: api.getMonitoringOperations, refetchInterval: 30000 });
    const activeOperations = useMemo(() => {
        const term = search.trim().toLowerCase();
        return (query.data ?? []).filter((operation) => operation.state === 'ACTIVE' && (!term || [operation.plate, operation.code, operation.currentLocation].some((value) => value.toLowerCase().includes(term))));
    }, [query.data, search]);
    if (query.isPending)
        return <Screen scroll={false} contentStyle={styles.loading}><ActivityIndicator color={colors.orange} size="large"/><AppText color={theme.colors.textSecondary}>Sincronizando monitoramento...</AppText></Screen>;
    const online = activeOperations.filter((item) => item.deviceOnline).length;
    const alerts = activeOperations.filter((item) => item.alertsCount > 0).length;
    return (<Screen contentStyle={styles.content}>
      <PageHeader title="Monitoramento" subtitle="Posição, RFID e telemetria em tempo real"/>
      <View style={styles.statusRow}>
        <StatusPill icon="radio-outline" label={`${online} online`} color={colors.green}/>
        <StatusPill icon="warning-outline" label={`${alerts} com alerta`} color={alerts ? colors.red : colors.green}/>
        <StatusPill icon="time-outline" label="Agora" color={colors.orange}/>
      </View>
      <SegmentedControl options={[{ label: 'Mapa', value: 'MAP' }, { label: 'Lista', value: 'LIST' }]} value={viewMode} onChange={setViewMode}/>
      <View style={styles.search}><SearchField value={search} onChangeText={setSearch} placeholder="Buscar caminhão ou localização"/></View>
      {viewMode === 'MAP' ? (<>
          <FleetMap operations={activeOperations}/>
          <View style={styles.sectionHeader}><AppText variant="subtitle">Cargas monitoradas</AppText><AppText variant="caption" color={theme.colors.textMuted}>Atualização automática</AppText></View>
          <View style={styles.list}>{activeOperations.slice(0, 3).map((operation) => <OperationCard key={operation.id} operation={operation} compact/>)}</View>
        </>) : <View style={[styles.list, styles.listTop]}>{activeOperations.map((operation) => <OperationCard key={operation.id} operation={operation}/>)}</View>}
    </Screen>);
}
function StatusPill({ icon, label, color }: {
    icon: keyof typeof Ionicons.glyphMap;
    label: string;
    color: string;
}) {
    const theme = useAppTheme();
    return <View style={[styles.statusPill, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}><Ionicons name={icon} size={14} color={color}/><AppText variant="caption" color={theme.colors.textSecondary}>{label}</AppText></View>;
}
function FleetMap({ operations }: {
    operations: Operation[];
}) {
    const theme = useAppTheme();
    const markers = [{ left: '17%', top: '66%' }, { left: '43%', top: '47%' }, { left: '69%', top: '28%' }, { left: '79%', top: '66%' }] as const;
    return (<View style={[styles.map, { backgroundColor: theme.isDark ? '#141818' : '#E8ECEA', borderColor: theme.colors.border }]}>
      <View style={[styles.road, styles.roadOne, { backgroundColor: theme.isDark ? '#343838' : '#C5CCC8' }]}/>
      <View style={[styles.road, styles.roadTwo, { backgroundColor: theme.isDark ? '#343838' : '#C5CCC8' }]}/>
      <View style={[styles.road, styles.routeLine]}/>
      <View style={[styles.mapLabel, { backgroundColor: theme.colors.surface }]}><Ionicons name="navigate" size={14} color={colors.orange}/><AppText variant="caption">Rota Santos → Campinas</AppText></View>
      {operations.slice(0, 4).map((operation, index) => (<View key={operation.id} style={[styles.marker, markers[index]]}>
          <View style={[styles.markerBubble, { backgroundColor: operation.deviceOnline ? colors.orange : colors.red }]}><Ionicons name="car-sport" size={14} color={colors.white}/></View>
          <AppText variant="caption">{operation.plate}</AppText>
        </View>))}
      <View style={[styles.mapFooter, { backgroundColor: theme.colors.overlay }]}><Ionicons name="shield-checkmark" size={15} color={colors.green}/><AppText variant="caption" color={colors.white}>RFID e GPS sincronizados com a central</AppText></View>
    </View>);
}
const styles = StyleSheet.create({
    content: { alignSelf: 'center', maxWidth: 760, width: '100%' },
    loading: { alignItems: 'center', gap: spacing.lg, justifyContent: 'center' },
    statusRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginBottom: spacing.xl, marginTop: spacing.xxl },
    statusPill: { alignItems: 'center', borderRadius: radius.pill, borderWidth: 1, flexDirection: 'row', gap: 6, paddingHorizontal: spacing.md, paddingVertical: spacing.sm },
    search: { marginTop: spacing.md },
    map: { borderRadius: radius.md, borderWidth: 1, height: 330, marginTop: spacing.lg, overflow: 'hidden', position: 'relative' },
    road: { borderRadius: radius.pill, height: 9, position: 'absolute', width: '105%' },
    roadOne: { left: '-8%', top: '48%', transform: [{ rotate: '-31deg' }] },
    roadTwo: { left: '20%', top: '53%', transform: [{ rotate: '59deg' }], width: '82%' },
    routeLine: { backgroundColor: colors.orange, height: 4, left: '-2%', top: '48%', transform: [{ rotate: '-31deg' }], width: '95%' },
    marker: { alignItems: 'center', gap: 3, position: 'absolute' },
    markerBubble: { alignItems: 'center', borderColor: colors.white, borderRadius: radius.pill, borderWidth: 2, height: 31, justifyContent: 'center', width: 31 },
    mapLabel: { alignItems: 'center', borderRadius: radius.sm, flexDirection: 'row', gap: spacing.sm, left: spacing.md, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, position: 'absolute', top: spacing.md },
    mapFooter: { alignItems: 'center', bottom: 0, flexDirection: 'row', gap: spacing.sm, left: 0, padding: spacing.md, position: 'absolute', right: 0 },
    sectionHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.xxl },
    list: { gap: spacing.md, marginTop: spacing.md },
    listTop: { marginTop: spacing.xl },
});
