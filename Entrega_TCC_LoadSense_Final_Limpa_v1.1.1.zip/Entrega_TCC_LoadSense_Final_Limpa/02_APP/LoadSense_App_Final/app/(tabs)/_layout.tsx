import { Ionicons } from '@expo/vector-icons';
import { Redirect, Tabs } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { useSession } from '@/providers/session-provider';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, fonts } from '@/theme/tokens';
const icons = {
    dashboard: ['grid-outline', 'grid'],
    operations: ['swap-horizontal-outline', 'swap-horizontal'],
    monitoring: ['pulse-outline', 'pulse'],
    reports: ['document-text-outline', 'document-text'],
    settings: ['settings-outline', 'settings'],
} as const;
export default function TabsLayout() {
    const { status, session } = useSession();
    const theme = useAppTheme();
    if (status === 'loading') {
        return (<View style={styles.loading}>
        <ActivityIndicator color={colors.orange} size="large"/>
      </View>);
    }
    if (status !== 'ready' || !session)
        return <Redirect href="/"/>;
    if (!session.termsAccepted)
        return <Redirect href="/legal"/>;
    return (<Tabs initialRouteName="dashboard" screenOptions={{
            headerShown: false,
            tabBarActiveTintColor: colors.orange,
            tabBarInactiveTintColor: theme.colors.textMuted,
            tabBarHideOnKeyboard: true,
            tabBarLabelStyle: styles.label,
            tabBarStyle: [
                styles.tabBar,
                { backgroundColor: theme.colors.tabBar, borderTopColor: theme.colors.border },
            ],
            sceneStyle: { backgroundColor: theme.colors.background },
        }}>
      <Tabs.Screen name="dashboard" options={{
            title: 'Dashboard',
            tabBarIcon: ({ color, focused, size }) => (<Ionicons name={icons.dashboard[focused ? 1 : 0]} color={color} size={size}/>),
        }}/>
      <Tabs.Screen name="operations" options={{
            title: 'Operações',
            tabBarIcon: ({ color, focused, size }) => (<Ionicons name={icons.operations[focused ? 1 : 0]} color={color} size={size}/>),
        }}/>
      <Tabs.Screen name="monitoring" options={{
            title: 'Monitorar',
            tabBarIcon: ({ color, focused, size }) => (<Ionicons name={icons.monitoring[focused ? 1 : 0]} color={color} size={size}/>),
        }}/>
      <Tabs.Screen name="reports" options={{
            title: 'Relatórios',
            tabBarIcon: ({ color, focused, size }) => (<Ionicons name={icons.reports[focused ? 1 : 0]} color={color} size={size}/>),
        }}/>
      <Tabs.Screen name="settings" options={{
            title: 'Ajustes',
            tabBarIcon: ({ color, focused, size }) => (<Ionicons name={icons.settings[focused ? 1 : 0]} color={color} size={size}/>),
        }}/>
    </Tabs>);
}
const styles = StyleSheet.create({
    loading: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
    },
    tabBar: {
        height: 70,
        paddingBottom: 8,
        paddingTop: 8,
    },
    label: {
        fontFamily: fonts.bodySemiBold,
        fontSize: 10,
    },
});
