import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { router } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { ActiveOperationCard, AlertRow, LegendItem, MetricCard, } from '@/components/dashboard/dashboard-widgets';
import { PageHeader } from '@/components/page-header';
import { Screen } from '@/components/screen';
import { SectionHeading } from '@/components/section-heading';
import { StatusState } from '@/components/status-state';
import { TrendChart } from '@/components/trend-chart';
import { ROLE_LABELS } from '@/constants/app';
import { useNetwork } from '@/providers/network-provider';
import { useSession } from '@/providers/session-provider';
import { useAppTheme } from '@/providers/theme-provider';
import { api } from '@/services/api';
import { colors, radius, spacing } from '@/theme/tokens';
export default function DashboardScreen() {
    const { session } = useSession();
    const { isOnline } = useNetwork();
    const theme = useAppTheme();
    const query = useQuery({
        queryKey: ['dashboard', session?.company.id],
        queryFn: api.getDashboard,
        enabled: Boolean(session && isOnline),
    });
    if (!isOnline && !query.data) {
        return (<Screen scroll={false}>
        <StatusState icon="cloud-offline-outline" title="Você está offline" description="Conecte-se à internet para carregar os indicadores da empresa." tone="warning"/>
      </Screen>);
    }
    if (query.isPending) {
        return (<Screen scroll={false}>
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.orange}/>
          <AppText color={theme.colors.textSecondary}>Carregando indicadores...</AppText>
        </View>
      </Screen>);
    }
    if (query.isError) {
        return (<Screen scroll={false}>
        <StatusState icon="warning-outline" title="Indicadores indisponíveis" description="Não foi possível atualizar o Dashboard agora." actionLabel="Tentar novamente" onAction={() => void query.refetch()} tone="error"/>
      </Screen>);
    }
    const data = query.data;
    const isEmpty = data.metrics.length === 0 && !data.activeOperation && data.alerts.length === 0;
    if (isEmpty) {
        return (<Screen scroll={false}>
        <StatusState icon="cube-outline" title="Nenhuma operação ainda" description="Quando a primeira operação for criada, os indicadores e alertas aparecerão aqui." actionLabel="Ir para Operações" onAction={() => router.push('/operations')}/>
      </Screen>);
    }
    return (<Screen contentStyle={styles.content}>
      <PageHeader />

      <View style={styles.welcomeRow}>
        <View style={styles.welcomeCopy}>
          <AppText variant="title">Olá, {session?.user.name.split(' ')[0]}</AppText>
          <AppText color={theme.colors.textSecondary}>Acompanhe o resumo da operação em tempo real.</AppText>
        </View>
        <View style={[styles.roleBadge, { backgroundColor: theme.colors.orangeSoft }]}>
          <AppText variant="caption" color={colors.orange}>
            {session ? ROLE_LABELS[session.user.role] : ''}
          </AppText>
        </View>
      </View>

      <View style={[styles.levelCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
        <AppText variant="label" color={theme.colors.textMuted}>NÍVEL OPERACIONAL</AppText>
        <View style={styles.levelContent}>
          <View style={[styles.levelRing, { borderColor: colors.orange }]}>
            <AppText variant="metric">91%</AppText>
            <AppText variant="caption" color={theme.colors.textMuted}>ATIVA</AppText>
          </View>
          <View style={styles.levelLegend}>
            <LegendItem color={colors.green} label="Frota ativa" value="24 veículos"/>
            <LegendItem color={colors.orange} label="Em rota" value="8 entregas"/>
            <LegendItem color={colors.red} label="Alertas" value="3 críticos"/>
          </View>
        </View>
        <View style={[styles.noDivergence, { backgroundColor: theme.colors.greenSoft }]}>
          <Ionicons name="checkmark-circle" size={17} color={colors.green}/>
          <AppText variant="caption" color={colors.green}>
            Nenhuma divergência de pesagem detectada
          </AppText>
        </View>
      </View>

      <View style={styles.section}>
        <SectionHeading title="Visão geral" actionLabel="Atualizar" onAction={() => void query.refetch()}/>
        <View style={styles.metricsGrid}>
          {data.metrics.map((metric) => <MetricCard key={metric.id} metric={metric}/>)}
        </View>
      </View>

      <View style={styles.section}>
        <SectionHeading title="Monitoramento em tempo real" actionLabel="Ver tudo" onAction={() => router.push('/monitoring')}/>
        <View style={[styles.chartCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <TrendChart values={[28, 36, 32, 51, 63, 57, 76, 69, 84, 91]} labels={['08h', '12h', 'Agora']} height={132}/>
          <View style={styles.chartFooter}>
            <AppText variant="caption" color={theme.colors.textMuted}>Carga acompanhada</AppText>
            <AppText variant="label">{data.activeOperation?.code ?? 'OP-1042'}</AppText>
          </View>
        </View>
      </View>

      {data.activeOperation ? (<View style={styles.section}>
          <SectionHeading title="Operação em destaque" actionLabel="Ver operação" onAction={() => router.push('/operations')}/>
          <ActiveOperationCard operation={data.activeOperation}/>
        </View>) : null}

      <View style={styles.section}>
        <SectionHeading title="Alertas recentes" actionLabel="Ver todos" onAction={() => router.push('/notifications')}/>
        <View style={[styles.alertList, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          {data.alerts.map((alert) => <AlertRow key={alert.id} alert={alert}/>)}
        </View>
      </View>

      <AppText variant="caption" color={theme.colors.textMuted} style={styles.updated}>
        Atualizado às {new Date(data.updatedAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
      </AppText>
    </Screen>);
}
const styles = StyleSheet.create({
    content: {
        alignSelf: 'center',
        maxWidth: 880,
        width: '100%',
    },
    loading: {
        alignItems: 'center',
        flex: 1,
        gap: spacing.lg,
        justifyContent: 'center',
    },
    welcomeRow: {
        alignItems: 'flex-start',
        flexDirection: 'row',
        gap: spacing.md,
        justifyContent: 'space-between',
        marginTop: spacing.xxxl,
    },
    welcomeCopy: {
        flex: 1,
        gap: spacing.xs,
    },
    roleBadge: {
        borderRadius: radius.pill,
        paddingHorizontal: spacing.md,
        paddingVertical: spacing.sm,
    },
    section: {
        gap: spacing.md,
        marginTop: spacing.xxxl,
    },
    levelCard: {
        borderRadius: radius.lg,
        borderWidth: 1,
        gap: spacing.lg,
        marginTop: spacing.xxl,
        padding: spacing.lg,
    },
    levelContent: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.xxl,
    },
    levelRing: {
        alignItems: 'center',
        borderRadius: radius.pill,
        borderRightColor: colors.gray700,
        borderWidth: 9,
        height: 112,
        justifyContent: 'center',
        width: 112,
    },
    levelLegend: {
        flex: 1,
        gap: spacing.md,
    },
    noDivergence: {
        alignItems: 'center',
        borderRadius: radius.sm,
        flexDirection: 'row',
        gap: spacing.sm,
        padding: spacing.md,
    },
    chartCard: {
        borderRadius: radius.lg,
        borderWidth: 1,
        padding: spacing.lg,
    },
    chartFooter: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: spacing.md,
    },
    metricsGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: spacing.md,
    },
    alertList: {
        borderRadius: radius.lg,
        borderWidth: 1,
        overflow: 'hidden',
    },
    updated: {
        marginTop: spacing.xxl,
        textAlign: 'center',
    },
});
