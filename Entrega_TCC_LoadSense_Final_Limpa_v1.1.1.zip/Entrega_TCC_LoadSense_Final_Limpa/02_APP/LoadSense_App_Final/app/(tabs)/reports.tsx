import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { Alert, Pressable, StyleSheet, View } from 'react-native';
import { useState } from 'react';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { PageHeader } from '@/components/page-header';
import { Screen } from '@/components/screen';
import { SegmentedControl } from '@/components/segmented-control';
import { TrendChart } from '@/components/trend-chart';
import { useAppTheme } from '@/providers/theme-provider';
import { api } from '@/services/api';
import { colors, radius, spacing } from '@/theme/tokens';
import type { ReportItem, ReportPeriod } from '@/types/operations';
export default function ReportsScreen() {
    const theme = useAppTheme();
    const [period, setPeriod] = useState<ReportPeriod>('30d');
    const [generating, setGenerating] = useState(false);
    const query = useQuery({ queryKey: ['reports', period], queryFn: () => api.getReports(period) });
    const data = query.data;
    async function handleGenerate() {
        if (generating)
            return;
        setGenerating(true);
        try {
            const result = await api.createReport(period);
            await query.refetch();
            Alert.alert('Relatório solicitado', `Solicitação ${result.id} registrada com status ${result.state}.`);
        }
        catch (error) {
            Alert.alert('Não foi possível gerar', error instanceof Error ? error.message : 'Tente novamente.');
        }
        finally {
            setGenerating(false);
        }
    }
    return (<Screen contentStyle={styles.content}>
      <PageHeader title="Relatórios" subtitle="Indicadores, históricos e exportações"/>
      <View style={styles.filterBlock}>
        <AppText variant="label">Período de análise</AppText>
        <SegmentedControl options={[{ label: '7 dias', value: '7d' }, { label: '30 dias', value: '30d' }, { label: '90 dias', value: '90d' }]} value={period} onChange={setPeriod}/>
      </View>

      {query.isPending || !data ? (<View style={[styles.loadingCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}><AppText color={theme.colors.textSecondary}>Preparando indicadores...</AppText></View>) : (<>
          <View style={styles.metricsGrid}>
            <Metric label="Operações" value={String(data.summary.operations)} icon="swap-horizontal"/>
            <Metric label="Carga transportada" value={`${data.summary.cargoTons.toLocaleString('pt-BR')} t`} icon="cube"/>
            <Metric label="Eficiência média" value={`${data.summary.averageEfficiency}%`} icon="speedometer"/>
            <Metric label="Divergências" value={String(data.summary.divergences)} icon="warning" tone="danger"/>
          </View>

          <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
            <View style={styles.cardHeader}>
              <View><AppText variant="subtitle">Desempenho operacional</AppText><AppText variant="caption" color={theme.colors.textSecondary}>Evolução da eficiência no período</AppText></View>
              <View style={[styles.positiveBadge, { backgroundColor: theme.colors.greenSoft }]}><Ionicons name="trending-up" size={14} color={colors.green}/><AppText variant="caption" color={colors.green}>+6,8%</AppText></View>
            </View>
            <TrendChart values={data.performance} labels={['Início', 'Meio', 'Hoje']}/>
          </View>

          <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
            <AppText variant="subtitle">Distribuição por tipo de carga</AppText>
            <View style={styles.distributionBar}>{data.cargoDistribution.map((item) => <View key={item.label} style={{ backgroundColor: item.color, flex: item.percentage }}/>)}</View>
            <View style={styles.legend}>{data.cargoDistribution.map((item) => <View key={item.label} style={styles.legendItem}><View style={[styles.legendDot, { backgroundColor: item.color }]}/><AppText variant="caption" color={theme.colors.textSecondary}>{item.label} · {item.percentage}%</AppText></View>)}</View>
          </View>

          <View style={styles.sectionHeader}><AppText variant="subtitle">Relatórios gerados</AppText><AppText variant="caption" color={theme.colors.textMuted}>{data.reports.length} arquivos</AppText></View>
          <View style={styles.reportList}>{data.reports.map((report) => <ReportCard key={report.id} report={report}/>)}</View>
          <View style={styles.generate}><AppButton label="Gerar novo relatório" icon="document-text-outline" loading={generating} onPress={() => void handleGenerate()}/></View>
        </>)}
    </Screen>);
}
function Metric({ label, value, icon, tone = 'default' }: {
    label: string;
    value: string;
    icon: keyof typeof Ionicons.glyphMap;
    tone?: 'default' | 'danger';
}) {
    const theme = useAppTheme();
    const color = tone === 'danger' ? colors.red : colors.orange;
    return <View style={[styles.metric, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}><View style={[styles.metricIcon, { backgroundColor: tone === 'danger' ? theme.colors.redSoft : theme.colors.orangeSoft }]}><Ionicons name={icon} size={18} color={color}/></View><AppText variant="metric" style={styles.metricValue}>{value}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{label}</AppText></View>;
}
function ReportCard({ report }: {
    report: ReportItem;
}) {
    const theme = useAppTheme();
    const icons = { OPERATIONAL: 'bar-chart-outline', WEIGHING: 'scale-outline', TRACKING: 'map-outline' } as const;
    return <Pressable onPress={() => Alert.alert(report.title, `Período: ${report.period}\nGerado: ${report.generatedAt}`)} style={({ pressed }) => [styles.reportCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }, pressed && { backgroundColor: theme.colors.pressed }]}><View style={[styles.reportIcon, { backgroundColor: theme.colors.orangeSoft }]}><Ionicons name={icons[report.type]} size={20} color={colors.orange}/></View><View style={styles.reportCopy}><AppText variant="label">{report.title}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{report.period}</AppText><AppText variant="caption" color={theme.colors.textMuted}>{report.generatedAt}</AppText></View><Ionicons name="chevron-forward" size={18} color={theme.colors.textMuted}/></Pressable>;
}
const styles = StyleSheet.create({
    content: { alignSelf: 'center', maxWidth: 760, width: '100%' },
    filterBlock: { gap: spacing.sm, marginTop: spacing.xxl },
    loadingCard: { alignItems: 'center', borderRadius: radius.md, borderWidth: 1, marginTop: spacing.xxl, padding: spacing.xxl },
    metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md, marginTop: spacing.xxl },
    metric: { borderRadius: radius.md, borderWidth: 1, flexBasis: '46%', flexGrow: 1, minWidth: 145, padding: spacing.md },
    metricIcon: { alignItems: 'center', borderRadius: radius.sm, height: 34, justifyContent: 'center', marginBottom: spacing.sm, width: 34 },
    metricValue: { fontSize: 22 },
    card: { borderRadius: radius.md, borderWidth: 1, gap: spacing.lg, marginTop: spacing.xxl, padding: spacing.lg },
    cardHeader: { alignItems: 'flex-start', flexDirection: 'row', gap: spacing.sm, justifyContent: 'space-between' },
    positiveBadge: { alignItems: 'center', borderRadius: radius.pill, flexDirection: 'row', gap: 4, paddingHorizontal: spacing.sm, paddingVertical: 4 },
    distributionBar: { borderRadius: radius.pill, flexDirection: 'row', height: 12, overflow: 'hidden' },
    legend: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md },
    legendItem: { alignItems: 'center', flexDirection: 'row', gap: 6 },
    legendDot: { borderRadius: radius.pill, height: 8, width: 8 },
    sectionHeader: { alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.xxl },
    reportList: { gap: spacing.md, marginTop: spacing.md },
    reportCard: { alignItems: 'center', borderRadius: radius.md, borderWidth: 1, flexDirection: 'row', gap: spacing.md, padding: spacing.md },
    reportIcon: { alignItems: 'center', borderRadius: radius.sm, height: 42, justifyContent: 'center', width: 42 },
    reportCopy: { flex: 1, gap: 2 },
    generate: { marginBottom: spacing.xl, marginTop: spacing.xxl },
});
