import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useState } from 'react';
import { Pressable, StyleSheet, Switch, View } from 'react-native';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { PageHeader } from '@/components/page-header';
import { Screen } from '@/components/screen';
import { APP_VERSION, ROLE_LABELS } from '@/constants/app';
import { useSession } from '@/providers/session-provider';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
type SettingRowProps = {
    icon: keyof typeof Ionicons.glyphMap;
    label: string;
    description?: string;
    onPress?: () => void;
};
export default function SettingsScreen() {
    const { session, logout } = useSession();
    const theme = useAppTheme();
    const [leaving, setLeaving] = useState(false);
    async function signOut() {
        setLeaving(true);
        try {
            await logout();
            router.replace('/login');
        }
        finally {
            setLeaving(false);
        }
    }
    const initials = session?.user.name
        .split(' ')
        .slice(0, 2)
        .map((part) => part[0])
        .join('')
        .toUpperCase();
    return (<Screen contentStyle={styles.content}>
      <PageHeader title="Configurações" subtitle="Conta, empresa e preferências" showNotifications={false}/>

      <View style={[styles.profileCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
        <View style={styles.avatar}>
          <AppText variant="subtitle" color={colors.white}>{initials}</AppText>
        </View>
        <View style={styles.profileCopy}>
          <AppText variant="subtitle">{session?.user.name}</AppText>
          <AppText variant="caption" color={theme.colors.textSecondary}>{session?.user.email}</AppText>
          <View style={[styles.roleBadge, { backgroundColor: theme.colors.orangeSoft }]}>
            <AppText variant="caption" color={colors.orange}>
              {session ? ROLE_LABELS[session.user.role] : ''}
            </AppText>
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <AppText variant="label" color={theme.colors.textSecondary}>GERENCIAMENTO</AppText>
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <SettingRow icon="card-outline" label="Planos" description="Visualizar planos disponíveis" onPress={() => router.push('/plans')}/>
          <SettingRow icon="notifications-outline" label="Alertas" description="Consultar alertas e eventos" onPress={() => router.push('/notifications')}/>
          <SettingRow icon="scale-outline" label="Histórico de pesagens" description="Consultar pesagens anteriores" onPress={() => router.push('/weighing-history')}/>
          <SettingRow icon="pulse-outline" label="Status do sistema" description="Integrações e sensores" onPress={() => router.push('/system-status')}/>
          <SettingRow icon="options-outline" label="Preferências" description="Tema e notificações" onPress={() => router.push('/preferences')}/>
          <SettingRow icon="information-circle-outline" label="Sobre o LoadSense" description="Versão e informações do projeto" onPress={() => router.push('/about')}/>
        </View>
      </View>

      <View style={styles.section}>
        <AppText variant="label" color={theme.colors.textSecondary}>EMPRESA</AppText>
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <SettingRow icon="business-outline" label={session?.company.name ?? 'Empresa'} description={`Código: ${session?.company.code ?? '-'}`}/>
          <SettingRow icon="shield-checkmark-outline" label="Perfis e permissões" description="Definidos pelo servidor para esta empresa"/>
        </View>
      </View>

      <View style={styles.section}>
        <AppText variant="label" color={theme.colors.textSecondary}>LEGAL E SEGURANÇA</AppText>
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <SettingRow icon="document-text-outline" label="Termos de Uso" onPress={() => router.push({ pathname: '/legal', params: { document: 'terms' } })}/>
          <SettingRow icon="lock-closed-outline" label="Aviso de Privacidade" onPress={() => router.push({ pathname: '/legal', params: { document: 'privacy' } })}/>
          <SettingRow icon="key-outline" label="Segurança da sessão" description="Token de renovação protegido no dispositivo"/>
        </View>
      </View>

      <View style={styles.section}>
        <AppText variant="label" color={theme.colors.textSecondary}>APLICATIVO</AppText>
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <ThemeSettingRow />
          <SettingRow icon="information-circle-outline" label="LoadSense Mobile" description={`Versão ${APP_VERSION} · Protótipo funcional`}/>
          <SettingRow icon="server-outline" label="Fonte de dados" description="API simulada — pronta para integração REST"/>
        </View>
      </View>

      <View style={styles.logout}>
        <AppButton label="Sair da conta" variant="danger" icon="log-out-outline" loading={leaving} onPress={() => void signOut()}/>
      </View>
    </Screen>);
}
function SettingRow({ icon, label, description, onPress }: SettingRowProps) {
    const theme = useAppTheme();
    const content = (<>
      <View style={[styles.rowIcon, { backgroundColor: theme.colors.orangeSoft }]}>
        <Ionicons name={icon} size={21} color={colors.orange}/>
      </View>
      <View style={styles.rowCopy}>
        <AppText variant="label">{label}</AppText>
        {description ? <AppText variant="caption" color={theme.colors.textSecondary}>{description}</AppText> : null}
      </View>
      {onPress ? <Ionicons name="chevron-forward" size={19} color={theme.colors.textMuted}/> : null}
    </>);
    if (onPress) {
        return (<Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.settingRow, { borderBottomColor: theme.colors.border }, pressed && { backgroundColor: theme.colors.pressed }]}>
        {content}
      </Pressable>);
    }
    return <View style={[styles.settingRow, { borderBottomColor: theme.colors.border }]}>{content}</View>;
}
function ThemeSettingRow() {
    const theme = useAppTheme();
    return (<View style={[styles.settingRow, { borderBottomColor: theme.colors.border }]}>
      <View style={[styles.rowIcon, { backgroundColor: theme.colors.orangeSoft }]}>
        <Ionicons name={theme.isDark ? 'moon' : 'sunny'} size={21} color={colors.orange}/>
      </View>
      <View style={styles.rowCopy}>
        <AppText variant="label">Modo escuro</AppText>
        <AppText variant="caption" color={theme.colors.textSecondary}>
          {theme.isDark ? 'Visual original do protótipo' : 'Tema claro ativado'}
        </AppText>
      </View>
      <Switch accessibilityLabel="Alternar modo escuro" value={theme.isDark} onValueChange={theme.toggleTheme} trackColor={{ false: theme.colors.surfaceMuted, true: colors.orangeDark }} thumbColor={theme.isDark ? colors.orange : theme.colors.textMuted}/>
    </View>);
}
const styles = StyleSheet.create({
    content: {
        alignSelf: 'center',
        maxWidth: 720,
        width: '100%',
    },
    profileCard: {
        alignItems: 'center',
        borderRadius: radius.lg,
        borderWidth: 1,
        flexDirection: 'row',
        gap: spacing.lg,
        marginTop: spacing.xxxl,
        padding: spacing.lg,
    },
    avatar: {
        alignItems: 'center',
        backgroundColor: colors.black,
        borderRadius: radius.pill,
        height: 58,
        justifyContent: 'center',
        width: 58,
    },
    profileCopy: {
        alignItems: 'flex-start',
        flex: 1,
        gap: spacing.xs,
    },
    roleBadge: {
        borderRadius: radius.pill,
        marginTop: spacing.xs,
        paddingHorizontal: spacing.md,
        paddingVertical: spacing.xs,
    },
    section: {
        gap: spacing.sm,
        marginTop: spacing.xxl,
    },
    card: {
        borderRadius: radius.lg,
        borderWidth: 1,
        overflow: 'hidden',
    },
    settingRow: {
        alignItems: 'center',
        borderBottomWidth: 1,
        flexDirection: 'row',
        gap: spacing.md,
        minHeight: 68,
        padding: spacing.lg,
    },
    rowIcon: {
        alignItems: 'center',
        borderRadius: radius.sm,
        height: 38,
        justifyContent: 'center',
        width: 38,
    },
    rowCopy: {
        flex: 1,
        gap: 2,
    },
    logout: {
        marginBottom: spacing.xl,
        marginTop: spacing.xxxl,
    },
});
