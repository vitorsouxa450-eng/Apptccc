import { Ionicons } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import { Pressable, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { BrandMark } from '@/components/brand-mark';
import { Screen } from '@/components/screen';
import { useSession } from '@/providers/session-provider';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
const notifications = [
    {
        id: 'notification-1',
        icon: 'warning' as const,
        title: 'Variação de peso detectada',
        description: 'A operação OP-1042 ultrapassou o limite configurado.',
        time: 'Há 8 min',
        critical: false,
        unread: true,
    },
    {
        id: 'notification-2',
        icon: 'alert-circle' as const,
        title: 'Sensor sem comunicação',
        description: 'O dispositivo LS-008 parou de enviar dados.',
        time: 'Há 21 min',
        critical: true,
        unread: true,
    },
    {
        id: 'notification-3',
        icon: 'checkmark-circle' as const,
        title: 'Operação concluída',
        description: 'A operação OP-1038 foi finalizada sem pendências.',
        time: 'Hoje, 09:42',
        critical: false,
        unread: false,
    },
];
export default function NotificationsScreen() {
    const { status, session } = useSession();
    const theme = useAppTheme();
    if (status === 'ready' && !session)
        return <Redirect href="/login"/>;
    return (<Screen contentStyle={styles.content}>
      <BrandMark compact/>
      <View style={styles.header}>
        <Pressable accessibilityLabel="Voltar" hitSlop={10} onPress={() => router.back()} style={[styles.back, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <Ionicons name="arrow-back" size={23} color={theme.colors.icon}/>
        </Pressable>
        <View style={styles.headerCopy}>
          <AppText variant="title">Notificações</AppText>
          <AppText variant="caption" color={theme.colors.textSecondary}>Alertas e eventos recentes</AppText>
        </View>
      </View>

      <View style={[styles.list, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
        {notifications.map((item) => {
            const palette = item.critical
                ? { background: theme.colors.redSoft, foreground: colors.red }
                : { background: theme.colors.yellowSoft, foreground: theme.isDark ? colors.yellow : colors.black };
            return (<View key={item.id} style={[styles.row, { borderBottomColor: theme.colors.border }, item.unread && { backgroundColor: theme.colors.orangeSoft }]}>
              <View style={[styles.icon, { backgroundColor: palette.background }]}>
                <Ionicons name={item.icon} size={22} color={palette.foreground}/>
              </View>
              <View style={styles.copy}>
                <View style={styles.titleRow}>
                  <AppText variant="label" style={styles.notificationTitle}>{item.title}</AppText>
                  {item.unread ? <View style={styles.unreadDot}/> : null}
                </View>
                <AppText variant="caption" color={theme.colors.textSecondary}>{item.description}</AppText>
                <AppText variant="caption" color={theme.colors.textMuted}>{item.time}</AppText>
              </View>
            </View>);
        })}
      </View>
    </Screen>);
}
const styles = StyleSheet.create({
    content: {
        alignSelf: 'center',
        maxWidth: 720,
        width: '100%',
    },
    header: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.md,
        marginTop: spacing.xxl,
    },
    back: {
        alignItems: 'center',
        borderRadius: radius.md,
        borderWidth: 1,
        height: 44,
        justifyContent: 'center',
        width: 44,
    },
    headerCopy: {
        flex: 1,
        gap: spacing.xs,
    },
    list: {
        borderRadius: radius.lg,
        borderWidth: 1,
        marginTop: spacing.xxxl,
        overflow: 'hidden',
    },
    row: {
        alignItems: 'flex-start',
        borderBottomWidth: 1,
        flexDirection: 'row',
        gap: spacing.md,
        padding: spacing.lg,
    },
    icon: {
        alignItems: 'center',
        borderRadius: radius.md,
        height: 44,
        justifyContent: 'center',
        width: 44,
    },
    copy: {
        flex: 1,
        gap: spacing.xs,
    },
    titleRow: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.sm,
    },
    notificationTitle: {
        flex: 1,
    },
    unreadDot: {
        backgroundColor: colors.orange,
        borderRadius: radius.pill,
        height: 8,
        width: 8,
    },
});
