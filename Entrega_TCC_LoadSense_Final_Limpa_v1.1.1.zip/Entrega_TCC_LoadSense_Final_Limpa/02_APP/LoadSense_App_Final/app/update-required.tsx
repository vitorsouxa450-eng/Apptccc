import { Linking } from 'react-native';
import { Screen } from '@/components/screen';
import { StatusState } from '@/components/status-state';
import { useSession } from '@/providers/session-provider';
export default function UpdateRequiredScreen() {
    const { bootstrapData } = useSession();
    const storeUrl = bootstrapData?.state === 'update-required' ? bootstrapData.storeUrl : 'https://expo.dev';
    return (<Screen scroll={false}>
      <StatusState icon="cloud-download-outline" title="Atualização necessária" description="Instale a versão mais recente para continuar usando o LoadSense com segurança." actionLabel="Atualizar aplicativo" onAction={() => void Linking.openURL(storeUrl)}/>
    </Screen>);
}
