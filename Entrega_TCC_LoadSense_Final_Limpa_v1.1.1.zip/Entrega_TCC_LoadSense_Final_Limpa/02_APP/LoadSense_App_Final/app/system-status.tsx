import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { Screen } from '@/components/screen';
import { SubpageHeader } from '@/components/subpage-header';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
const services = [
    ['ESP32', 'Dispositivos de pesagem', 'Operacional'], ['Leitor RFID', 'Identificação das cargas', 'Operacional'], ['Sincronização', 'Última atualização há 2 min', 'Em tempo real'], ['Sensores', '8 de 8 conectados', 'Online'], ['API LoadSense', 'Comunicação com o aplicativo', 'Operacional'], ['Banco de dados', 'MySQL 8 · V3.1', 'Online'],
];
export default function SystemStatusScreen() {
    const theme = useAppTheme();
    return <Screen contentStyle={styles.content}><SubpageHeader title="Status do sistema" subtitle="Integrações e equipamentos"/><View style={[styles.hero, { backgroundColor: theme.colors.greenSoft, borderColor: colors.green }]}><Ionicons name="checkmark-circle" size={38} color={colors.green}/><View style={styles.heroCopy}><AppText variant="subtitle" color={colors.green}>Todos os serviços operacionais</AppText><AppText variant="caption" color={theme.colors.textSecondary}>Monitoramento atualizado em tempo real</AppText></View></View><View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>{services.map(([name, description, status]) => <View key={name} style={[styles.row, { borderBottomColor: theme.colors.border }]}><View style={[styles.icon, { backgroundColor: theme.colors.greenSoft }]}><Ionicons name="checkmark" size={18} color={colors.green}/></View><View style={styles.copy}><AppText variant="label">{name}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{description}</AppText></View><AppText variant="caption" color={colors.green}>{status}</AppText></View>)}</View></Screen>;
}
const styles = StyleSheet.create({ content: { alignSelf: 'center', maxWidth: 720, width: '100%' }, hero: { alignItems: 'center', borderRadius: radius.md, borderWidth: 1, flexDirection: 'row', gap: spacing.md, marginTop: spacing.xxl, padding: spacing.lg }, heroCopy: { flex: 1 }, card: { borderRadius: radius.md, borderWidth: 1, marginTop: spacing.xl, overflow: 'hidden' }, row: { alignItems: 'center', borderBottomWidth: 1, flexDirection: 'row', gap: spacing.md, padding: spacing.md }, icon: { alignItems: 'center', borderRadius: radius.pill, height: 34, justifyContent: 'center', width: 34 }, copy: { flex: 1 } });
