import { Ionicons } from '@expo/vector-icons';
import { Alert, StyleSheet, View } from 'react-native';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { Screen } from '@/components/screen';
import { SubpageHeader } from '@/components/subpage-header';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
const plans = [
    { name: 'Básico', price: 'R$ 49,90', description: 'Para operações de menor porte', current: true, items: ['Dashboard operacional', 'Até 5 veículos monitorados', 'Alertas essenciais', 'Relatórios mensais'] },
    { name: 'Básico Plus', price: 'R$ 79,90', description: 'Mais controle e automação', current: false, items: ['Até 15 veículos monitorados', 'Alertas personalizados', 'Relatórios por período', 'Histórico completo de pesagens'] },
    { name: 'Premium', price: 'R$ 149,90', description: 'Gestão logística completa', current: false, items: ['Veículos ilimitados', 'RFID e telemetria avançada', 'Relatórios e auditoria', 'Suporte prioritário'] },
];
export default function PlansScreen() {
    return <Screen contentStyle={styles.content}><SubpageHeader title="Planos" subtitle="Escolha a estrutura ideal para a empresa"/><View style={styles.list}>{plans.map((plan) => <PlanCard key={plan.name} {...plan}/>)}</View></Screen>;
}
function PlanCard({ name, price, description, current, items }: (typeof plans)[number]) {
    const theme = useAppTheme();
    return <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: current ? colors.orange : theme.colors.border }]}>{current ? <View style={styles.current}><AppText variant="caption" color={colors.white}>PLANO ATUAL</AppText></View> : null}<AppText variant="subtitle">{name}</AppText><AppText variant="metric" color={colors.orange}>{price}<AppText variant="caption" color={theme.colors.textMuted}> /mês</AppText></AppText><AppText variant="caption" color={theme.colors.textSecondary}>{description}</AppText><View style={styles.features}>{items.map((item) => <View key={item} style={styles.feature}><Ionicons name="checkmark-circle" size={17} color={colors.green}/><AppText variant="caption" color={theme.colors.textSecondary}>{item}</AppText></View>)}</View>{!current ? <AppButton label="Solicitar alteração" variant="secondary" onPress={() => Alert.alert('Solicitação registrada', `A alteração para o plano ${name} será encaminhada ao responsável comercial.`)}/> : null}</View>;
}
const styles = StyleSheet.create({ content: { alignSelf: 'center', maxWidth: 720, width: '100%' }, list: { gap: spacing.lg, marginBottom: spacing.xl, marginTop: spacing.xxl }, card: { borderRadius: radius.md, borderWidth: 1, gap: spacing.sm, overflow: 'hidden', padding: spacing.lg }, current: { alignSelf: 'flex-start', backgroundColor: colors.orange, borderRadius: radius.pill, paddingHorizontal: spacing.md, paddingVertical: 4 }, features: { gap: spacing.sm, marginBottom: spacing.md, marginTop: spacing.md }, feature: { alignItems: 'center', flexDirection: 'row', gap: spacing.sm } });
