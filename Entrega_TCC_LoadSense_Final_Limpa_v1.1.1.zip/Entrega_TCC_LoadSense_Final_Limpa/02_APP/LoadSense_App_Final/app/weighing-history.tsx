import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { Screen } from '@/components/screen';
import { SubpageHeader } from '@/components/subpage-header';
import { useAppTheme } from '@/providers/theme-provider';
import { api } from '@/services/api';
import { colors, radius, spacing } from '@/theme/tokens';
export default function WeighingHistoryScreen() {
    const theme = useAppTheme();
    const query = useQuery({ queryKey: ['weighing-history'], queryFn: api.getOperations });
    const entries = (query.data ?? []).flatMap((operation) => operation.weighings.map((weighing) => ({ ...weighing, code: operation.code, plate: operation.plate })));
    return <Screen contentStyle={styles.content}><SubpageHeader title="Histórico de pesagens" subtitle="Registros operacionais sincronizados"/><View style={styles.summary}><AppText variant="metric">{entries.length}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>pesagens demonstrativas encontradas</AppText></View><View style={styles.list}>{entries.map((item) => <View key={item.id} style={[styles.row, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}><View style={[styles.icon, { backgroundColor: theme.colors.orangeSoft }]}><Ionicons name="scale-outline" size={20} color={colors.orange}/></View><View style={styles.copy}><AppText variant="label">{item.label}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{item.code} · {item.plate}</AppText><AppText variant="caption" color={theme.colors.textMuted}>{item.recordedAt}</AppText></View><AppText variant="subtitle">{item.valueTons.toFixed(2)} t</AppText></View>)}</View></Screen>;
}
const styles = StyleSheet.create({ content: { alignSelf: 'center', maxWidth: 720, width: '100%' }, summary: { marginTop: spacing.xxl }, list: { gap: spacing.md, marginBottom: spacing.xl, marginTop: spacing.lg }, row: { alignItems: 'center', borderRadius: radius.md, borderWidth: 1, flexDirection: 'row', gap: spacing.md, padding: spacing.md }, icon: { alignItems: 'center', borderRadius: radius.sm, height: 40, justifyContent: 'center', width: 40 }, copy: { flex: 1 } });
