import { Redirect } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { BrandMark } from '@/components/brand-mark';
import { Screen } from '@/components/screen';
import { useSession } from '@/providers/session-provider';
import { colors, spacing } from '@/theme/tokens';
export default function IndexScreen() {
    const { status, session, bootstrapError, retryBootstrap } = useSession();
    if (status === 'maintenance')
        return <Redirect href="/maintenance"/>;
    if (status === 'update-required')
        return <Redirect href="/update-required"/>;
    if (status === 'ready' && !session)
        return <Redirect href="/login"/>;
    if (status === 'ready' && session && !session.termsAccepted)
        return <Redirect href="/legal"/>;
    if (status === 'ready' && session)
        return <Redirect href="/dashboard"/>;
    if (status === 'error') {
        return (<Screen scroll={false} backgroundColor={colors.black} contentStyle={styles.center}>
        <BrandMark dark/>
        <AppText color={colors.gray300} style={styles.message}>
          {bootstrapError}
        </AppText>
        <View style={styles.action}>
          <AppButton label="Tentar novamente" onPress={() => void retryBootstrap()}/>
        </View>
      </Screen>);
    }
    return (<Screen scroll={false} backgroundColor={colors.black} contentStyle={styles.center}>
      <BrandMark dark/>
      <ActivityIndicator color={colors.orange} size="large" style={styles.loader}/>
      <AppText color={colors.gray300}>Preparando sua operação...</AppText>
    </Screen>);
}
const styles = StyleSheet.create({
    center: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    loader: {
        marginBottom: spacing.lg,
        marginTop: spacing.xxxl,
    },
    message: {
        marginTop: spacing.xxl,
        maxWidth: 380,
        textAlign: 'center',
    },
    action: {
        marginTop: spacing.xl,
        maxWidth: 300,
        width: '100%',
    },
});
