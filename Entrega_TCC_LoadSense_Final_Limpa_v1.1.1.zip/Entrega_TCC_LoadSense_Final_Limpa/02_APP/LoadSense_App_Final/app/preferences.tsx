import { Ionicons } from '@expo/vector-icons';
import { useState } from 'react';
import { StyleSheet, Switch, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { Screen } from '@/components/screen';
import { SegmentedControl } from '@/components/segmented-control';
import { SubpageHeader } from '@/components/subpage-header';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing, type ThemeMode } from '@/theme/tokens';
export default function PreferencesScreen() {
    const theme = useAppTheme();
    const [push, setPush] = useState(true);
    const [sound, setSound] = useState(true);
    const [criticalOnly, setCriticalOnly] = useState(false);
    return (<Screen contentStyle={styles.content}>
      <SubpageHeader title="Preferências" subtitle="Personalize o aplicativo"/>
      <View style={styles.section}>
        <AppText variant="label" color={theme.colors.textMuted}>APARÊNCIA</AppText>
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <View style={styles.appearance}><Ionicons name={theme.isDark ? 'moon' : 'sunny'} size={22} color={colors.orange}/><View style={styles.copy}><AppText variant="label">Tema do aplicativo</AppText><AppText variant="caption" color={theme.colors.textSecondary}>O modo escuro segue o protótipo oficial</AppText></View></View>
          <SegmentedControl options={[{ label: 'Claro', value: 'light' }, { label: 'Escuro', value: 'dark' }]} value={theme.mode} onChange={(mode: ThemeMode) => theme.setMode(mode)}/>
        </View>
      </View>
      <View style={styles.section}>
        <AppText variant="label" color={theme.colors.textMuted}>NOTIFICAÇÕES</AppText>
        <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <PreferenceSwitch icon="notifications" label="Notificações push" description="Avisos de operações e sensores" value={push} onChange={setPush}/>
          <PreferenceSwitch icon="volume-high" label="Som de alerta" description="Som ao receber alertas críticos" value={sound} onChange={setSound}/>
          <PreferenceSwitch icon="alert-circle" label="Apenas alertas críticos" description="Ocultar notificações informativas" value={criticalOnly} onChange={setCriticalOnly}/>
        </View>
      </View>
    </Screen>);
}
function PreferenceSwitch({ icon, label, description, value, onChange }: {
    icon: keyof typeof Ionicons.glyphMap;
    label: string;
    description: string;
    value: boolean;
    onChange: (value: boolean) => void;
}) {
    const theme = useAppTheme();
    return <View style={[styles.row, { borderBottomColor: theme.colors.border }]}><View style={[styles.icon, { backgroundColor: theme.colors.orangeSoft }]}><Ionicons name={icon} size={19} color={colors.orange}/></View><View style={styles.copy}><AppText variant="label">{label}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{description}</AppText></View><Switch value={value} onValueChange={onChange} trackColor={{ false: theme.colors.surfaceMuted, true: colors.orangeDark }} thumbColor={value ? colors.orange : theme.colors.textMuted}/></View>;
}
const styles = StyleSheet.create({
    content: { alignSelf: 'center', maxWidth: 720, width: '100%' }, section: { gap: spacing.sm, marginTop: spacing.xxl }, card: { borderRadius: radius.md, borderWidth: 1, gap: spacing.md, overflow: 'hidden', padding: spacing.md },
    appearance: { alignItems: 'center', flexDirection: 'row', gap: spacing.md }, copy: { flex: 1, gap: 2 }, row: { alignItems: 'center', borderBottomWidth: 1, flexDirection: 'row', gap: spacing.md, paddingVertical: spacing.md }, icon: { alignItems: 'center', borderRadius: radius.sm, height: 38, justifyContent: 'center', width: 38 },
});
