import { Screen } from '@/components/screen';
import { StatusState } from '@/components/status-state';
import { useSession } from '@/providers/session-provider';
export default function MaintenanceScreen() {
    const { bootstrapData, retryBootstrap } = useSession();
    const message = bootstrapData?.state === 'maintenance'
        ? bootstrapData.message
        : 'O LoadSense está temporariamente indisponível.';
    return (<Screen scroll={false}>
      <StatusState icon="construct-outline" title="Manutenção em andamento" description={message} actionLabel="Verificar novamente" onAction={() => void retryBootstrap()} tone="warning"/>
    </Screen>);
}
