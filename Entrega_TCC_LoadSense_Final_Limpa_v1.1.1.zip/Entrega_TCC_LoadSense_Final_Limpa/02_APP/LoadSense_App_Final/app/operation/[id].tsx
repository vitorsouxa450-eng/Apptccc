import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { BrandMark } from '@/components/brand-mark';
import { Screen } from '@/components/screen';
import { SegmentedControl } from '@/components/segmented-control';
import { StatusState } from '@/components/status-state';
import { useAppTheme } from '@/providers/theme-provider';
import { api } from '@/services/api';
import { colors, radius, spacing } from '@/theme/tokens';
import type { Operation } from '@/types/operations';
type DetailTab = 'SUMMARY' | 'WEIGHINGS' | 'ROUTE' | 'ALERTS';
export default function OperationDetailsScreen() {
    const params = useLocalSearchParams<{
        id: string;
    }>();
    const theme = useAppTheme();
    const [tab, setTab] = useState<DetailTab>('SUMMARY');
    const query = useQuery({ queryKey: ['operation', params.id], queryFn: () => api.getOperation(params.id) });
    if (query.isPending)
        return <Screen scroll={false} contentStyle={styles.loading}><ActivityIndicator color={colors.orange} size="large"/></Screen>;
    if (query.isError)
        return <Screen scroll={false}><StatusState icon="alert-circle-outline" title="Operação não encontrada" description="O registro solicitado não está disponível." actionLabel="Voltar" onAction={() => router.back()} tone="error"/></Screen>;
    const operation = query.data;
    return (<Screen contentStyle={styles.content}>
      <BrandMark compact/>
      <View style={styles.topBar}>
        <Pressable accessibilityLabel="Voltar" onPress={() => router.back()} style={[styles.back, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}><Ionicons name="arrow-back" size={22} color={theme.colors.icon}/></Pressable>
        <View style={styles.heading}><AppText variant="title">Detalhes da operação</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{operation.code} · {operation.plate}</AppText></View>
        <View style={[styles.signal, { backgroundColor: operation.deviceOnline ? theme.colors.greenSoft : theme.colors.redSoft }]}><Ionicons name={operation.deviceOnline ? 'radio' : 'cloud-offline'} size={18} color={operation.deviceOnline ? colors.green : colors.red}/></View>
      </View>

      <OperationHero operation={operation}/>
      <SegmentedControl options={[{ label: 'Resumo', value: 'SUMMARY' }, { label: 'Pesagens', value: 'WEIGHINGS' }, { label: 'Trajeto', value: 'ROUTE' }, { label: 'Alertas', value: 'ALERTS' }]} value={tab} onChange={setTab}/>

      {tab === 'SUMMARY' ? <Summary operation={operation}/> : null}
      {tab === 'WEIGHINGS' ? <Weighings operation={operation}/> : null}
      {tab === 'ROUTE' ? <RouteDetails operation={operation}/> : null}
      {tab === 'ALERTS' ? <Alerts operation={operation}/> : null}
    </Screen>);
}
function OperationHero({ operation }: {
    operation: Operation;
}) {
    const theme = useAppTheme();
    return (<View style={[styles.hero, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
      <View style={styles.heroTop}>
        <View style={[styles.heroIcon, { backgroundColor: theme.colors.orangeSoft }]}><Ionicons name="car-sport" size={25} color={colors.orange}/></View>
        <View style={styles.heroCopy}><AppText variant="subtitle">{operation.plate}</AppText><AppText variant="caption" color={operation.statusTone === 'critical' ? colors.red : colors.green}>{operation.status}</AppText></View>
        <AppText variant="caption" color={theme.colors.textMuted}>{operation.lastSignal}</AppText>
      </View>
      <View style={styles.routeLine}><View style={styles.routeDot}/><View style={[styles.routeTrack, { backgroundColor: theme.colors.surfaceMuted }]}><View style={[styles.routeProgress, { width: `${operation.routeProgress}%` }]}/></View><View style={[styles.routeDot, styles.routeDotEnd]}/></View>
      <View style={styles.routeLabels}><AppText variant="caption" color={theme.colors.textSecondary} style={styles.routeLabel}>{operation.origin}</AppText><AppText variant="caption" color={theme.colors.textSecondary} style={[styles.routeLabel, styles.routeLabelRight]}>{operation.destination}</AppText></View>
      <View style={styles.heroMetrics}><HeroMetric label="Carga" value={`${operation.currentWeightTons.toFixed(1)} t`}/><HeroMetric label="Progresso" value={`${operation.progress}%`}/><HeroMetric label="Alertas" value={String(operation.alertsCount)}/></View>
    </View>);
}
function HeroMetric({ label, value }: {
    label: string;
    value: string;
}) {
    const theme = useAppTheme();
    return <View style={styles.heroMetric}><AppText variant="subtitle">{value}</AppText><AppText variant="caption" color={theme.colors.textMuted}>{label}</AppText></View>;
}
function Summary({ operation }: {
    operation: Operation;
}) {
    return <View style={styles.section}><AppText variant="subtitle">Resumo da operação</AppText><InfoGrid items={[['Motorista', operation.driver], ['Carga', operation.cargo], ['Etiqueta RFID', operation.rfidTag], ['Localização atual', operation.currentLocation], ['Saída planejada', operation.scheduledAt], ['Chegada prevista', operation.estimatedArrival]]}/></View>;
}
function InfoGrid({ items }: {
    items: string[][];
}) {
    const theme = useAppTheme();
    return <View style={[styles.infoCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>{items.map(([label, value]) => <View key={label} style={[styles.infoRow, { borderBottomColor: theme.colors.border }]}><AppText variant="caption" color={theme.colors.textMuted}>{label}</AppText><AppText variant="label" style={styles.infoValue}>{value}</AppText></View>)}</View>;
}
function Weighings({ operation }: {
    operation: Operation;
}) {
    const theme = useAppTheme();
    return <View style={styles.section}><AppText variant="subtitle">Histórico de pesagens</AppText>{operation.weighings.map((item) => <View key={item.id} style={[styles.eventCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}><View style={[styles.eventIcon, { backgroundColor: theme.colors.orangeSoft }]}><Ionicons name="scale-outline" size={20} color={colors.orange}/></View><View style={styles.eventCopy}><AppText variant="label">{item.label}</AppText><AppText variant="caption" color={theme.colors.textMuted}>{item.recordedAt}</AppText></View><AppText variant="subtitle">{item.valueTons.toFixed(2)} t</AppText></View>)}</View>;
}
function RouteDetails({ operation }: {
    operation: Operation;
}) {
    const theme = useAppTheme();
    return <View style={styles.section}><AppText variant="subtitle">Trajeto monitorado</AppText><View style={[styles.routeCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}><TimelinePoint title="Origem" description={operation.origin} done/><TimelinePoint title="Localização atual" description={operation.currentLocation} active/><TimelinePoint title="Destino" description={operation.destination}/><View style={[styles.routeStatus, { backgroundColor: theme.colors.greenSoft }]}><Ionicons name="navigate" size={17} color={colors.green}/><AppText variant="caption" color={colors.green}>{operation.routeProgress}% do percurso concluído</AppText></View></View></View>;
}
function TimelinePoint({ title, description, done, active }: {
    title: string;
    description: string;
    done?: boolean;
    active?: boolean;
}) {
    const theme = useAppTheme();
    const color = active ? colors.orange : done ? colors.green : theme.colors.textMuted;
    return <View style={styles.timelineRow}><View style={[styles.timelineDot, { backgroundColor: color }]}/><View style={styles.eventCopy}><AppText variant="label">{title}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{description}</AppText></View></View>;
}
function Alerts({ operation }: {
    operation: Operation;
}) {
    const theme = useAppTheme();
    if (!operation.events.length)
        return <View style={styles.noAlerts}><Ionicons name="checkmark-circle" size={38} color={colors.green}/><AppText variant="subtitle">Nenhum alerta registrado</AppText><AppText variant="caption" color={theme.colors.textSecondary}>A operação segue dentro dos parâmetros configurados.</AppText></View>;
    return <View style={styles.section}><AppText variant="subtitle">Alertas registrados</AppText>{operation.events.map((event) => { const critical = event.tone === 'critical'; return <View key={event.id} style={[styles.eventCard, { backgroundColor: critical ? theme.colors.redSoft : theme.colors.yellowSoft, borderColor: critical ? colors.red : '#EAB308' }]}><Ionicons name={critical ? 'alert-circle' : 'warning'} size={22} color={critical ? colors.red : '#EAB308'}/><View style={styles.eventCopy}><AppText variant="label">{event.title}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{event.description}</AppText></View><AppText variant="caption" color={theme.colors.textMuted}>{event.time}</AppText></View>; })}</View>;
}
const styles = StyleSheet.create({
    content: { alignSelf: 'center', maxWidth: 760, width: '100%' }, loading: { alignItems: 'center', justifyContent: 'center' },
    topBar: { alignItems: 'center', flexDirection: 'row', gap: spacing.md, marginTop: spacing.xxl }, back: { alignItems: 'center', borderRadius: radius.sm, borderWidth: 1, height: 42, justifyContent: 'center', width: 42 },
    heading: { flex: 1 }, signal: { alignItems: 'center', borderRadius: radius.pill, height: 38, justifyContent: 'center', width: 38 },
    hero: { borderRadius: radius.md, borderWidth: 1, gap: spacing.lg, marginBottom: spacing.xl, marginTop: spacing.xxl, padding: spacing.lg },
    heroTop: { alignItems: 'center', flexDirection: 'row', gap: spacing.md }, heroIcon: { alignItems: 'center', borderRadius: radius.sm, height: 46, justifyContent: 'center', width: 46 }, heroCopy: { flex: 1 },
    routeLine: { alignItems: 'center', flexDirection: 'row' }, routeDot: { backgroundColor: colors.green, borderRadius: radius.pill, height: 11, width: 11 }, routeDotEnd: { backgroundColor: colors.orange }, routeTrack: { flex: 1, height: 5, overflow: 'hidden' }, routeProgress: { backgroundColor: colors.orange, height: '100%' },
    routeLabels: { flexDirection: 'row', justifyContent: 'space-between' }, routeLabel: { flex: 1 }, routeLabelRight: { textAlign: 'right' },
    heroMetrics: { flexDirection: 'row' }, heroMetric: { alignItems: 'center', flex: 1 },
    section: { gap: spacing.md, marginTop: spacing.xxl }, infoCard: { borderRadius: radius.md, borderWidth: 1, overflow: 'hidden' }, infoRow: { borderBottomWidth: 1, gap: spacing.xs, padding: spacing.md }, infoValue: { flex: 1 },
    eventCard: { alignItems: 'center', borderRadius: radius.md, borderWidth: 1, flexDirection: 'row', gap: spacing.md, padding: spacing.md }, eventIcon: { alignItems: 'center', borderRadius: radius.sm, height: 40, justifyContent: 'center', width: 40 }, eventCopy: { flex: 1, gap: 2 },
    routeCard: { borderRadius: radius.md, borderWidth: 1, gap: spacing.lg, padding: spacing.lg }, timelineRow: { alignItems: 'flex-start', flexDirection: 'row', gap: spacing.md }, timelineDot: { borderRadius: radius.pill, height: 12, marginTop: 4, width: 12 }, routeStatus: { alignItems: 'center', borderRadius: radius.sm, flexDirection: 'row', gap: spacing.sm, padding: spacing.md },
    noAlerts: { alignItems: 'center', gap: spacing.sm, padding: spacing.xxxl },
});
