import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { Controller, useForm } from 'react-hook-form';
import { StyleSheet, View } from 'react-native';
import { z } from 'zod';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { AuthShell } from '@/components/auth-shell';
import { FormField } from '@/components/form-field';
import { api } from '@/services/api';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
const schema = z.object({
    companyCode: z.string().trim().min(2, 'Informe o código da empresa.'),
    email: z.email('Informe um e-mail válido.'),
});
type FormData = z.infer<typeof schema>;
export default function ForgotPasswordScreen() {
    const theme = useAppTheme();
    const { control, handleSubmit, formState: { errors, isSubmitting, isSubmitSuccessful }, } = useForm<FormData>({
        resolver: zodResolver(schema),
        defaultValues: { companyCode: '', email: '' },
    });
    const submit = handleSubmit(async (values) => {
        await api.requestPasswordReset(values.companyCode, values.email);
    });
    return (<AuthShell title="Recuperar acesso" subtitle="Informe a empresa e o e-mail. Se a conta existir, enviaremos as instruções.">
      {isSubmitSuccessful ? (<View style={[styles.success, { backgroundColor: theme.colors.greenSoft }]} accessibilityRole="alert">
          <AppText variant="subtitle" color={colors.green}>Solicitação recebida</AppText>
          <AppText color={theme.colors.textSecondary}>
            Verifique sua caixa de entrada e também a pasta de spam. Por segurança, não confirmamos se o e-mail está cadastrado.
          </AppText>
        </View>) : (<>
          <Controller control={control} name="companyCode" render={({ field }) => (<FormField label="Empresa" placeholder="Código da empresa" icon="business-outline" value={field.value} onBlur={field.onBlur} onChangeText={field.onChange} error={errors.companyCode?.message}/>)}/>
          <Controller control={control} name="email" render={({ field }) => (<FormField label="E-mail" placeholder="nome@empresa.com" keyboardType="email-address" autoComplete="email" icon="mail-outline" value={field.value} onBlur={field.onBlur} onChangeText={field.onChange} error={errors.email?.message}/>)}/>
          <AppButton label="Enviar instruções" loading={isSubmitting} onPress={() => void submit()}/>
        </>)}
      <AppButton label="Voltar para o login" variant="ghost" onPress={() => router.back()}/>
    </AuthShell>);
}
const styles = StyleSheet.create({
    success: {
        borderRadius: radius.md,
        gap: spacing.sm,
        padding: spacing.lg,
    },
});
