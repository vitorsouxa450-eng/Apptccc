import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { Controller, useForm } from 'react-hook-form';
import { Pressable, StyleSheet, View } from 'react-native';
import { z } from 'zod';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { AuthShell } from '@/components/auth-shell';
import { FormField } from '@/components/form-field';
import { ApiError } from '@/services/api';
import { useSession } from '@/providers/session-provider';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
const loginSchema = z.object({
    companyCode: z.string().trim().min(2, 'Informe o código da empresa.'),
    email: z.email('Informe um e-mail válido.'),
    password: z.string().min(6, 'A senha deve ter pelo menos 6 caracteres.'),
});
type LoginForm = z.infer<typeof loginSchema>;
export default function LoginScreen() {
    const { login } = useSession();
    const theme = useAppTheme();
    const { control, handleSubmit, setError, formState: { errors, isSubmitting }, } = useForm<LoginForm>({
        resolver: zodResolver(loginSchema),
        defaultValues: { companyCode: '', email: '', password: '' },
    });
    const submit = handleSubmit(async (values) => {
        try {
            await login(values);
            router.replace('/');
        }
        catch (error) {
            setError('root', {
                message: error instanceof ApiError ? error.message : 'Não foi possível entrar. Tente novamente.',
            });
        }
    });
    return (<AuthShell title="Acesse sua operação" subtitle="Entre com a empresa, o e-mail corporativo e sua senha.">
      <Controller control={control} name="companyCode" render={({ field: { onBlur, onChange, value, ref } }) => (<FormField ref={ref} label="Empresa" placeholder="Ex.: loadsense-demo" autoCorrect={false} autoCapitalize="none" icon="business-outline" returnKeyType="next" value={value} onBlur={onBlur} onChangeText={onChange} error={errors.companyCode?.message}/>)}/>
      <Controller control={control} name="email" render={({ field: { onBlur, onChange, value, ref } }) => (<FormField ref={ref} label="E-mail" placeholder="nome@empresa.com" keyboardType="email-address" autoComplete="email" icon="mail-outline" returnKeyType="next" value={value} onBlur={onBlur} onChangeText={onChange} error={errors.email?.message}/>)}/>
      <Controller control={control} name="password" render={({ field: { onBlur, onChange, value, ref } }) => (<FormField ref={ref} label="Senha" placeholder="Digite sua senha" autoComplete="current-password" icon="lock-closed-outline" secureTextEntry returnKeyType="done" value={value} onBlur={onBlur} onChangeText={onChange} onSubmitEditing={() => void submit()} error={errors.password?.message}/>)}/>

      <Pressable accessibilityRole="link" onPress={() => router.push('/forgot-password')}>
        <AppText variant="label" color={colors.orange} style={styles.rightLink}>
          Esqueci minha senha
        </AppText>
      </Pressable>

      {errors.root?.message ? (<View style={[styles.error, { backgroundColor: theme.colors.redSoft }]} accessibilityRole="alert">
          <AppText variant="caption" color={colors.red}>
            {errors.root.message}
          </AppText>
        </View>) : null}

      <AppButton label="Entrar" icon="log-in-outline" loading={isSubmitting} onPress={() => void submit()}/>

      <View style={[styles.divider, { backgroundColor: theme.colors.border }]}/>
      <AppText color={theme.colors.textSecondary} style={styles.center}>
        Sua empresa ainda não usa o LoadSense?
      </AppText>
      <AppButton label="Solicitar cadastro da empresa" variant="secondary" onPress={() => router.push('/register-company')}/>

      <View style={styles.legalLinks}>
        <Pressable onPress={() => router.push({ pathname: '/legal', params: { document: 'terms' } })}>
          <AppText variant="caption" color={theme.colors.textSecondary} style={styles.underlined}>
            Termos de Uso
          </AppText>
        </Pressable>
        <AppText variant="caption" color={theme.colors.textMuted}>·</AppText>
        <Pressable onPress={() => router.push({ pathname: '/legal', params: { document: 'privacy' } })}>
          <AppText variant="caption" color={theme.colors.textSecondary} style={styles.underlined}>
            Privacidade
          </AppText>
        </Pressable>
      </View>
    </AuthShell>);
}
const styles = StyleSheet.create({
    rightLink: {
        textAlign: 'right',
    },
    error: {
        borderRadius: radius.sm,
        padding: spacing.md,
    },
    divider: {
        height: 1,
    },
    center: {
        textAlign: 'center',
    },
    legalLinks: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.sm,
        justifyContent: 'center',
    },
    underlined: {
        textDecorationLine: 'underline',
    },
});
