import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { StyleSheet, Switch, View } from 'react-native';
import { z } from 'zod';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { AuthShell } from '@/components/auth-shell';
import { FormField } from '@/components/form-field';
import { api } from '@/services/api';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
const companySchema = z.object({
    legalName: z.string().trim().min(3, 'Informe a razão social.'),
    document: z.string().refine((value) => value.replace(/\D/g, '').length === 14, 'Informe um CNPJ válido com 14 dígitos.'),
    responsibleName: z.string().trim().min(3, 'Informe o nome do responsável.'),
    email: z.email('Informe um e-mail corporativo válido.'),
    phone: z.string().refine((value) => value.replace(/\D/g, '').length >= 10, 'Informe um telefone válido.'),
    acceptedPrivacy: z.boolean().refine(Boolean, 'Você precisa aceitar o aviso de privacidade.'),
});
type CompanyForm = z.infer<typeof companySchema>;
export default function RegisterCompanyScreen() {
    const theme = useAppTheme();
    const { control, handleSubmit, setError, formState: { errors, isSubmitting }, } = useForm<CompanyForm>({
        resolver: zodResolver(companySchema),
        defaultValues: {
            legalName: '',
            document: '',
            responsibleName: '',
            email: '',
            phone: '',
            acceptedPrivacy: false,
        },
    });
    const [requestId, setRequestId] = useState<string | null>(null);
    const submit = handleSubmit(async (values) => {
        try {
            const result = await api.requestCompany(values);
            setRequestId(result.requestId);
        }
        catch {
            setError('root', { message: 'Não foi possível enviar a solicitação. Tente novamente.' });
        }
    });
    return (<AuthShell title="Solicite o LoadSense" subtitle="Cadastre os dados da empresa. O primeiro acesso será liberado após análise.">
      {requestId ? (<View style={[styles.success, { backgroundColor: theme.colors.greenSoft }]} accessibilityRole="alert">
          <AppText variant="subtitle" color={colors.green}>Solicitação enviada</AppText>
          <AppText color={theme.colors.textSecondary}>
            Protocolo {requestId}. Após a aprovação, o responsável receberá o convite para criar o primeiro usuário Administrador.
          </AppText>
          <AppButton label="Voltar para o login" onPress={() => router.replace('/login')}/>
        </View>) : (<>
          <View style={[styles.infoBox, { backgroundColor: theme.colors.blueSoft }]}>
            <AppText variant="caption" color={theme.colors.textSecondary}>
              Perfis e permissões não são escolhidos neste formulário. Eles serão atribuídos com segurança após a aprovação da empresa.
            </AppText>
          </View>
          <Controller control={control} name="legalName" render={({ field }) => (<FormField label="Razão social" placeholder="Nome legal da empresa" autoCapitalize="words" icon="business-outline" value={field.value} onBlur={field.onBlur} onChangeText={field.onChange} error={errors.legalName?.message}/>)}/>
          <Controller control={control} name="document" render={({ field }) => (<FormField label="CNPJ" placeholder="00.000.000/0000-00" keyboardType="number-pad" icon="document-text-outline" value={field.value} onBlur={field.onBlur} onChangeText={field.onChange} error={errors.document?.message}/>)}/>
          <Controller control={control} name="responsibleName" render={({ field }) => (<FormField label="Responsável" placeholder="Nome completo" autoCapitalize="words" icon="person-outline" value={field.value} onBlur={field.onBlur} onChangeText={field.onChange} error={errors.responsibleName?.message}/>)}/>
          <Controller control={control} name="email" render={({ field }) => (<FormField label="E-mail corporativo" placeholder="responsavel@empresa.com" keyboardType="email-address" autoComplete="email" icon="mail-outline" value={field.value} onBlur={field.onBlur} onChangeText={field.onChange} error={errors.email?.message}/>)}/>
          <Controller control={control} name="phone" render={({ field }) => (<FormField label="Telefone" placeholder="(00) 00000-0000" keyboardType="phone-pad" autoComplete="tel" icon="call-outline" value={field.value} onBlur={field.onBlur} onChangeText={field.onChange} error={errors.phone?.message}/>)}/>
          <Controller control={control} name="acceptedPrivacy" render={({ field }) => (<View>
                <View style={styles.switchRow}>
                  <Switch accessibilityLabel="Aceitar aviso de privacidade" trackColor={{ false: theme.colors.surfaceMuted, true: colors.orangeDark }} thumbColor={field.value ? colors.orange : theme.colors.textMuted} value={field.value} onValueChange={field.onChange}/>
                  <AppText variant="caption" color={theme.colors.textSecondary} style={styles.switchText}>
                    Li e concordo com o uso dos dados para análise desta solicitação, conforme o Aviso de Privacidade.
                  </AppText>
                </View>
                {errors.acceptedPrivacy?.message ? (<AppText variant="caption" color={colors.red}>{errors.acceptedPrivacy.message}</AppText>) : null}
              </View>)}/>
          {errors.root?.message ? (<AppText variant="caption" color={colors.red}>{errors.root.message}</AppText>) : null}
          <AppButton label="Enviar solicitação" loading={isSubmitting} onPress={() => void submit()}/>
          <AppButton label="Voltar" variant="ghost" onPress={() => router.back()}/>
        </>)}
    </AuthShell>);
}
const styles = StyleSheet.create({
    infoBox: {
        borderRadius: radius.md,
        padding: spacing.md,
    },
    success: {
        borderRadius: radius.md,
        gap: spacing.lg,
        padding: spacing.lg,
    },
    switchRow: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.sm,
    },
    switchText: {
        flex: 1,
    },
});
