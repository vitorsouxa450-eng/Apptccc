import { Redirect, Stack } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { useSession } from '@/providers/session-provider';
import { useAppTheme } from '@/providers/theme-provider';
import { colors } from '@/theme/tokens';
export default function AuthLayout() {
    const { status, session } = useSession();
    const theme = useAppTheme();
    if (status === 'loading') {
        return (<View style={[styles.loading, { backgroundColor: theme.colors.background }]}>
        <ActivityIndicator color={colors.orange} size="large"/>
      </View>);
    }
    if (status === 'ready' && session) {
        return <Redirect href={session.termsAccepted ? '/dashboard' : '/legal'}/>;
    }
    return <Stack screenOptions={{ headerShown: false, animation: 'slide_from_right', contentStyle: { backgroundColor: theme.colors.background } }}/>;
}
const styles = StyleSheet.create({
    loading: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
    },
});
