export type OperationState = 'ACTIVE' | 'COMPLETED';
export type OperationTone = 'success' | 'warning' | 'critical';
export type OperationWeighing = {
    id: string;
    label: string;
    valueTons: number;
    recordedAt: string;
};
export type OperationEvent = {
    id: string;
    title: string;
    description: string;
    time: string;
    tone: OperationTone;
};
export type Operation = {
    id: string;
    code: string;
    state: OperationState;
    status: string;
    statusTone: OperationTone;
    plate: string;
    driver: string;
    cargo: string;
    rfidTag: string;
    origin: string;
    destination: string;
    currentLocation: string;
    currentWeightTons: number;
    targetWeightTons: number;
    progress: number;
    scheduledAt: string;
    estimatedArrival: string;
    lastSignal: string;
    deviceOnline: boolean;
    alertsCount: number;
    routeProgress: number;
    weighings: OperationWeighing[];
    events: OperationEvent[];
};
export type ReportPeriod = '7d' | '30d' | '90d';
export type ReportSummary = {
    operations: number;
    completed: number;
    cargoTons: number;
    averageEfficiency: number;
    divergences: number;
    averageTripHours: number;
};
export type ReportItem = {
    id: string;
    title: string;
    period: string;
    generatedAt: string;
    type: 'OPERATIONAL' | 'WEIGHING' | 'TRACKING';
};
export type ReportsData = {
    summary: ReportSummary;
    performance: number[];
    cargoDistribution: {
        label: string;
        percentage: number;
        color: string;
    }[];
    reports: ReportItem[];
};
