export type DashboardMetric = {
    id: string;
    label: string;
    value: number;
    tone: 'orange' | 'green' | 'yellow' | 'red';
};
export type DashboardAlert = {
    id: string;
    title: string;
    description: string;
    time: string;
    severity: 'warning' | 'critical' | 'info';
};
export type DashboardData = {
    metrics: DashboardMetric[];
    activeOperation: {
        id: string;
        code: string;
        origin: string;
        destination: string;
        currentWeightTons: number;
        targetWeightTons: number;
        progress: number;
        status: string;
    } | null;
    alerts: DashboardAlert[];
    updatedAt: string;
};
