export type UserRole = 'ADMINISTRATOR' | 'SUPERVISOR' | 'OPERATOR';
export type UserSession = {
    accessToken: string;
    company: {
        id: string;
        code: string;
        name: string;
    };
    user: {
        id: string;
        name: string;
        email: string;
        role: UserRole;
    };
    permissions: string[];
    termsAccepted: boolean;
};
export type LoginInput = {
    companyCode: string;
    email: string;
    password: string;
};
export type CompanyRequestInput = {
    legalName: string;
    document: string;
    responsibleName: string;
    email: string;
    phone: string;
    acceptedPrivacy: boolean;
};
export type BootstrapResult = {
    state: 'ready';
} | {
    state: 'maintenance';
    message: string;
} | {
    state: 'update-required';
    storeUrl: string;
};
