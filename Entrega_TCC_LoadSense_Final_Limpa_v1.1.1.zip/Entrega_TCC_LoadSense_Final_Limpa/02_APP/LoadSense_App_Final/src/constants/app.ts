export const APP_VERSION = '0.2.0';
export const ROLE_LABELS = {
    ADMINISTRATOR: 'Administrador',
    SUPERVISOR: 'Supervisor',
    OPERATOR: 'Operador',
} as const;
