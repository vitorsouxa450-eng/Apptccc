import { createContext, useCallback, useContext, useEffect, useMemo, useState, type PropsWithChildren, } from 'react';
import { api } from '@/services/api';
import { sessionStorage } from '@/services/session-storage';
import type { BootstrapResult, LoginInput, UserSession } from '@/types/auth';
type BootstrapStatus = 'loading' | 'ready' | 'maintenance' | 'update-required' | 'error';
type SessionContextValue = {
    status: BootstrapStatus;
    bootstrapData: BootstrapResult | null;
    bootstrapError: string | null;
    session: UserSession | null;
    login: (input: LoginInput) => Promise<void>;
    logout: () => Promise<void>;
    acceptTerms: () => Promise<void>;
    retryBootstrap: () => Promise<void>;
};
const SessionContext = createContext<SessionContextValue | null>(null);
export function SessionProvider({ children }: PropsWithChildren) {
    const [status, setStatus] = useState<BootstrapStatus>('loading');
    const [bootstrapData, setBootstrapData] = useState<BootstrapResult | null>(null);
    const [bootstrapError, setBootstrapError] = useState<string | null>(null);
    const [session, setSession] = useState<UserSession | null>(null);
    const bootstrap = useCallback(async () => {
        setStatus('loading');
        setBootstrapError(null);
        try {
            const result = await api.bootstrap();
            setBootstrapData(result);
            if (result.state === 'maintenance') {
                setStatus('maintenance');
                return;
            }
            if (result.state === 'update-required') {
                setStatus('update-required');
                return;
            }
            const refreshToken = await sessionStorage.getRefreshToken();
            if (refreshToken) {
                try {
                    setSession(await api.resumeSession(refreshToken));
                }
                catch {
                    await sessionStorage.clearRefreshToken();
                    setSession(null);
                }
            }
            setStatus('ready');
        }
        catch {
            setBootstrapError('Não foi possível iniciar o LoadSense. Verifique sua conexão e tente novamente.');
            setStatus('error');
        }
    }, []);
    useEffect(() => {
        void bootstrap();
    }, [bootstrap]);
    const login = useCallback(async (input: LoginInput) => {
        const result = await api.login(input);
        await sessionStorage.setRefreshToken(result.refreshToken);
        setSession(result.session);
    }, []);
    const logout = useCallback(async () => {
        const refreshToken = await sessionStorage.getRefreshToken();
        try {
            await api.revokeSession(refreshToken ?? undefined);
        }
        finally {
            await sessionStorage.clearRefreshToken();
            setSession(null);
        }
    }, []);
    const acceptTerms = useCallback(async () => {
        if (!session)
            return;
        setSession(await api.acceptTerms(session));
    }, [session]);
    const value = useMemo(() => ({
        status,
        bootstrapData,
        bootstrapError,
        session,
        login,
        logout,
        acceptTerms,
        retryBootstrap: bootstrap,
    }), [acceptTerms, bootstrap, bootstrapData, bootstrapError, login, logout, session, status]);
    return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}
export function useSession() {
    const context = useContext(SessionContext);
    if (!context) {
        throw new Error('useSession deve ser usado dentro de SessionProvider.');
    }
    return context;
}
