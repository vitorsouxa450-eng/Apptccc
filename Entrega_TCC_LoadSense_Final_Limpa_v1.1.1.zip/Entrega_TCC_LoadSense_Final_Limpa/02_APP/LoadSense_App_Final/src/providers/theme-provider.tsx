import * as SecureStore from 'expo-secure-store';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type PropsWithChildren, } from 'react';
import { Platform } from 'react-native';
import { themeColors, type ThemeMode } from '@/theme/tokens';
const THEME_KEY = 'loadsense.theme-mode';
type ThemeContextValue = {
    mode: ThemeMode;
    isDark: boolean;
    colors: (typeof themeColors)[ThemeMode];
    setMode: (mode: ThemeMode) => void;
    toggleTheme: () => void;
};
const ThemeContext = createContext<ThemeContextValue | null>(null);
async function readTheme(): Promise<ThemeMode | null> {
    try {
        const value = Platform.OS === 'web'
            ? globalThis.localStorage?.getItem(THEME_KEY)
            : await SecureStore.getItemAsync(THEME_KEY);
        return value === 'light' || value === 'dark' ? value : null;
    }
    catch {
        return null;
    }
}
async function saveTheme(mode: ThemeMode) {
    try {
        if (Platform.OS === 'web') {
            globalThis.localStorage?.setItem(THEME_KEY, mode);
            return;
        }
        await SecureStore.setItemAsync(THEME_KEY, mode);
    }
    catch {
    }
}
export function ThemeProvider({ children }: PropsWithChildren) {
    const [mode, updateMode] = useState<ThemeMode>('dark');
    useEffect(() => {
        void readTheme().then((storedMode) => {
            if (storedMode)
                updateMode(storedMode);
        });
    }, []);
    const setMode = useCallback((nextMode: ThemeMode) => {
        updateMode(nextMode);
        void saveTheme(nextMode);
    }, []);
    const toggleTheme = useCallback(() => {
        updateMode((currentMode) => {
            const nextMode = currentMode === 'dark' ? 'light' : 'dark';
            void saveTheme(nextMode);
            return nextMode;
        });
    }, []);
    const value = useMemo(() => ({
        mode,
        isDark: mode === 'dark',
        colors: themeColors[mode],
        setMode,
        toggleTheme,
    }), [mode, setMode, toggleTheme]);
    return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}
export function useAppTheme() {
    const context = useContext(ThemeContext);
    if (!context)
        throw new Error('useAppTheme deve ser usado dentro de ThemeProvider.');
    return context;
}
