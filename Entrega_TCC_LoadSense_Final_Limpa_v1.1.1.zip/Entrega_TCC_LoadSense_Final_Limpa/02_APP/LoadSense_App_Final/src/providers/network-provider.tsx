import NetInfo from '@react-native-community/netinfo';
import { createContext, useContext, useEffect, useMemo, useState, type PropsWithChildren } from 'react';
type NetworkContextValue = {
    isOnline: boolean;
};
const NetworkContext = createContext<NetworkContextValue>({ isOnline: true });
export function NetworkProvider({ children }: PropsWithChildren) {
    const [isOnline, setIsOnline] = useState(true);
    useEffect(() => {
        const unsubscribe = NetInfo.addEventListener((state) => {
            setIsOnline(Boolean(state.isConnected && state.isInternetReachable !== false));
        });
        return unsubscribe;
    }, []);
    const value = useMemo(() => ({ isOnline }), [isOnline]);
    return <NetworkContext.Provider value={value}>{children}</NetworkContext.Provider>;
}
export function useNetwork() {
    return useContext(NetworkContext);
}
