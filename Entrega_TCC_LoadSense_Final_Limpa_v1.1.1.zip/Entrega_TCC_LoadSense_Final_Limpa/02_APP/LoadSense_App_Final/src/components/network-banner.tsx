import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { useNetwork } from '@/providers/network-provider';
import { colors, spacing } from '@/theme/tokens';
export function NetworkBanner() {
    const { isOnline } = useNetwork();
    if (isOnline)
        return null;
    return (<View style={styles.banner} accessibilityRole="alert">
      <Ionicons name="cloud-offline-outline" size={17} color={colors.black}/>
      <AppText variant="caption" color={colors.black} style={styles.text}>
        Sem conexão. Alguns dados podem estar desatualizados.
      </AppText>
    </View>);
}
const styles = StyleSheet.create({
    banner: {
        alignItems: 'center',
        backgroundColor: colors.yellow,
        flexDirection: 'row',
        gap: spacing.sm,
        justifyContent: 'center',
        minHeight: 34,
        paddingHorizontal: spacing.lg,
        paddingVertical: spacing.sm,
    },
    text: {
        flexShrink: 1,
        textAlign: 'center',
    },
});
