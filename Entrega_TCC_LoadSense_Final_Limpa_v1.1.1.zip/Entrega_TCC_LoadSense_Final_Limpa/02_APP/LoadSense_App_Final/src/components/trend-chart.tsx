import { StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
type TrendChartProps = {
    values: number[];
    labels?: string[];
    height?: number;
};
export function TrendChart({ values, labels, height = 140 }: TrendChartProps) {
    const theme = useAppTheme();
    const highest = Math.max(...values, 1);
    return (<View>
      <View style={[styles.chart, { height, borderBottomColor: theme.colors.border }]}>
        {values.map((value, index) => (<View key={`${value}-${index}`} style={styles.barColumn}>
            <View style={[styles.barTrack, { backgroundColor: theme.colors.surfaceMuted }]}>
              <View style={[
                styles.bar,
                { height: `${Math.max(12, (value / highest) * 100)}%` },
                index === values.length - 1 && styles.lastBar,
            ]}/>
            </View>
          </View>))}
      </View>
      {labels?.length ? (<View style={styles.labels}>
          {labels.map((label) => <AppText key={label} variant="caption" color={theme.colors.textMuted}>{label}</AppText>)}
        </View>) : null}
    </View>);
}
const styles = StyleSheet.create({
    chart: {
        alignItems: 'flex-end',
        borderBottomWidth: 1,
        flexDirection: 'row',
        gap: 6,
        paddingTop: spacing.sm,
    },
    barColumn: {
        flex: 1,
        height: '100%',
        justifyContent: 'flex-end',
    },
    barTrack: {
        borderRadius: radius.sm,
        height: '100%',
        justifyContent: 'flex-end',
        overflow: 'hidden',
    },
    bar: {
        backgroundColor: colors.orange,
        borderRadius: radius.sm,
        minHeight: 8,
        opacity: 0.72,
    },
    lastBar: {
        opacity: 1,
    },
    labels: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: spacing.sm,
    },
});
