import { Ionicons } from '@expo/vector-icons';
import { ActivityIndicator, Pressable, StyleSheet, View, type PressableProps } from 'react-native';
import { AppText } from '@/components/app-text';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
type AppButtonProps = PressableProps & {
    label: string;
    variant?: ButtonVariant;
    loading?: boolean;
    icon?: keyof typeof Ionicons.glyphMap;
    fullWidth?: boolean;
};
export function AppButton({ label, variant = 'primary', loading = false, disabled, icon, fullWidth = true, style, ...props }: AppButtonProps) {
    const theme = useAppTheme();
    const palettes = {
        primary: { background: colors.orange, border: colors.orange, text: colors.white },
        secondary: { background: theme.colors.surface, border: theme.colors.borderStrong, text: theme.colors.text },
        ghost: { background: 'transparent', border: 'transparent', text: colors.orange },
        danger: { background: theme.isDark ? colors.redSoft : colors.red, border: colors.red, text: theme.isDark ? colors.red : colors.white },
    } as const;
    const palette = palettes[variant];
    const inactive = disabled || loading;
    return (<Pressable accessibilityRole="button" accessibilityState={{ disabled: inactive, busy: loading }} disabled={inactive} style={(state) => [
            styles.button,
            fullWidth && styles.fullWidth,
            { backgroundColor: palette.background, borderColor: palette.border },
            inactive && styles.disabled,
            state.pressed && styles.pressed,
            typeof style === 'function' ? style(state) : style,
        ]} {...props}>
      {loading ? (<ActivityIndicator color={palette.text}/>) : (<View style={styles.content}>
          {icon ? <Ionicons name={icon} size={18} color={palette.text}/> : null}
          <AppText variant="label" color={palette.text}>
            {label}
          </AppText>
        </View>)}
    </Pressable>);
}
const styles = StyleSheet.create({
    button: {
        alignItems: 'center',
        borderRadius: radius.md,
        borderWidth: 1,
        justifyContent: 'center',
        minHeight: 50,
        paddingHorizontal: spacing.lg,
    },
    fullWidth: {
        width: '100%',
    },
    content: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.sm,
    },
    disabled: {
        opacity: 0.55,
    },
    pressed: {
        opacity: 0.82,
        transform: [{ scale: 0.99 }],
    },
});
