import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, TextInput, View } from 'react-native';
import { useAppTheme } from '@/providers/theme-provider';
import { fonts, radius, spacing } from '@/theme/tokens';
type SearchFieldProps = {
    value: string;
    onChangeText: (value: string) => void;
    placeholder?: string;
};
export function SearchField({ value, onChangeText, placeholder = 'Buscar' }: SearchFieldProps) {
    const theme = useAppTheme();
    return (<View style={[styles.shell, { backgroundColor: theme.colors.input, borderColor: theme.colors.border }]}>
      <Ionicons name="search-outline" size={19} color={theme.colors.textMuted}/>
      <TextInput accessibilityLabel={placeholder} autoCapitalize="none" autoCorrect={false} placeholder={placeholder} placeholderTextColor={theme.colors.textMuted} value={value} onChangeText={onChangeText} style={[styles.input, { color: theme.colors.text }]}/>
      {value ? <Ionicons name="close-circle" size={18} color={theme.colors.textMuted} onPress={() => onChangeText('')}/> : null}
    </View>);
}
const styles = StyleSheet.create({
    shell: {
        alignItems: 'center',
        borderRadius: radius.sm,
        borderWidth: 1,
        flexDirection: 'row',
        gap: spacing.sm,
        minHeight: 44,
        paddingHorizontal: spacing.md,
    },
    input: {
        flex: 1,
        fontFamily: fonts.bodyRegular,
        fontSize: 14,
        paddingVertical: spacing.sm,
    },
});
