import { StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
type BrandMarkProps = {
    compact?: boolean;
    dark?: boolean;
};
export function BrandMark({ compact = false, dark = false }: BrandMarkProps) {
    const theme = useAppTheme();
    const wordmarkColor = dark || theme.isDark ? colors.white : theme.colors.text;
    return (<View style={styles.row} accessibilityLabel="LoadSense">
      <View style={[styles.symbol, compact && styles.symbolCompact]}>
        <View style={[styles.symbolBar, styles.symbolBarTop, compact && styles.symbolBarCompact]}/>
        <View style={[styles.symbolBar, styles.symbolBarBottom, compact && styles.symbolBarCompact]}/>
        <View style={[styles.symbolCore, compact && styles.symbolCoreCompact]}/>
      </View>
      <View>
        <AppText variant={compact ? 'subtitle' : 'title'} color={wordmarkColor} style={styles.wordmark}>
          LOAD<AppText variant={compact ? 'subtitle' : 'title'} color={colors.orange}>SENSE</AppText>
        </AppText>
        {!compact ? (<AppText variant="caption" color={dark || theme.isDark ? colors.gray300 : theme.colors.textSecondary}>
            Logística inteligente em tempo real
          </AppText>) : null}
      </View>
    </View>);
}
const styles = StyleSheet.create({
    row: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.md,
    },
    symbol: {
        alignItems: 'center',
        height: 48,
        justifyContent: 'center',
        position: 'relative',
        width: 48,
    },
    symbolCompact: {
        height: 36,
        width: 36,
    },
    symbolBar: {
        backgroundColor: colors.orange,
        borderRadius: radius.pill,
        height: 10,
        position: 'absolute',
        transform: [{ rotate: '-24deg' }],
        width: 31,
    },
    symbolBarCompact: {
        height: 8,
        width: 25,
    },
    symbolBarTop: {
        top: 12,
    },
    symbolBarBottom: {
        bottom: 12,
    },
    symbolCore: {
        backgroundColor: colors.orange,
        borderColor: colors.white,
        borderRadius: 4,
        borderWidth: 2,
        height: 15,
        transform: [{ rotate: '-24deg' }],
        width: 15,
    },
    symbolCoreCompact: {
        borderRadius: 3,
        height: 12,
        width: 12,
    },
    wordmark: {
        lineHeight: 27,
        letterSpacing: 0.2,
    },
});
