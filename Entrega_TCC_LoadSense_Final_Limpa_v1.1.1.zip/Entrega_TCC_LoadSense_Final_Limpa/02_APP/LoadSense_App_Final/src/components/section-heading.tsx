import { Pressable, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { colors, spacing } from '@/theme/tokens';
type SectionHeadingProps = {
    title: string;
    actionLabel?: string;
    onAction?: () => void;
};
export function SectionHeading({ title, actionLabel, onAction }: SectionHeadingProps) {
    return (<View style={styles.row}>
      <AppText variant="subtitle">{title}</AppText>
      {actionLabel && onAction ? (<Pressable accessibilityRole="button" hitSlop={8} onPress={onAction}>
          <AppText variant="label" color={colors.orange}>{actionLabel}</AppText>
        </Pressable>) : null}
    </View>);
}
const styles = StyleSheet.create({
    row: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.md,
        justifyContent: 'space-between',
    },
});
