import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Pressable, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
import type { Operation } from '@/types/operations';
type OperationCardProps = {
    operation: Operation;
    compact?: boolean;
};
const toneColor = {
    success: colors.green,
    warning: '#EAB308',
    critical: colors.red,
};
export function OperationCard({ operation, compact = false }: OperationCardProps) {
    const theme = useAppTheme();
    const statusColor = toneColor[operation.statusTone];
    return (<Pressable accessibilityRole="button" accessibilityLabel={`Abrir ${operation.code}`} onPress={() => router.push({ pathname: '/operation/[id]', params: { id: operation.id } })} style={({ pressed }) => [
            styles.card,
            { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
            pressed && { backgroundColor: theme.colors.pressed },
        ]}>
      <View style={styles.topRow}>
        <View style={[styles.truckIcon, { backgroundColor: theme.colors.orangeSoft }]}>
          <Ionicons name="car-sport" size={19} color={colors.orange}/>
        </View>
        <View style={styles.titleCopy}>
          <AppText variant="label">{operation.plate}</AppText>
          <AppText variant="caption" color={statusColor}>{operation.status}</AppText>
        </View>
        <AppText variant="caption" color={theme.colors.textMuted}>{operation.code}</AppText>
      </View>

      {!compact ? (<View style={styles.routeRow}>
          <View style={styles.routePoint}/>
          <View style={styles.routeCopy}>
            <AppText variant="caption" color={theme.colors.textMuted} numberOfLines={1}>{operation.origin}</AppText>
            <AppText variant="caption" color={theme.colors.textSecondary} numberOfLines={1}>{operation.destination}</AppText>
          </View>
          <Ionicons name="chevron-forward" size={18} color={theme.colors.textMuted}/>
        </View>) : null}

      <View style={[styles.progressTrack, { backgroundColor: theme.colors.surfaceMuted }]}>
        <View style={[styles.progressFill, { width: `${operation.state === 'COMPLETED' ? 100 : operation.progress}%` }]}/>
      </View>
      <View style={styles.footer}>
        <AppText variant="caption" color={theme.colors.textMuted}>{operation.lastSignal}</AppText>
        <AppText variant="caption" color={theme.colors.textSecondary}>
          {operation.currentWeightTons.toFixed(1)} t · {operation.progress}%
        </AppText>
      </View>
    </Pressable>);
}
const styles = StyleSheet.create({
    card: {
        borderRadius: radius.md,
        borderWidth: 1,
        gap: spacing.md,
        padding: spacing.md,
    },
    topRow: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.sm,
    },
    truckIcon: {
        alignItems: 'center',
        borderRadius: radius.sm,
        height: 36,
        justifyContent: 'center',
        width: 36,
    },
    titleCopy: {
        flex: 1,
    },
    routeRow: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.sm,
    },
    routePoint: {
        backgroundColor: colors.orange,
        borderRadius: radius.pill,
        height: 8,
        width: 8,
    },
    routeCopy: {
        flex: 1,
        gap: 2,
    },
    progressTrack: {
        borderRadius: radius.pill,
        height: 5,
        overflow: 'hidden',
    },
    progressFill: {
        backgroundColor: colors.orange,
        borderRadius: radius.pill,
        height: '100%',
    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
});
