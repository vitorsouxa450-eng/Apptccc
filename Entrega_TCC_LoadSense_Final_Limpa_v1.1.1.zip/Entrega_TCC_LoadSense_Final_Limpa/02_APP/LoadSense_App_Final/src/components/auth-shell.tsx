import type { PropsWithChildren } from 'react';
import { StyleSheet, View, useWindowDimensions } from 'react-native';
import { AppText } from '@/components/app-text';
import { BrandMark } from '@/components/brand-mark';
import { Screen } from '@/components/screen';
import { useAppTheme } from '@/providers/theme-provider';
import { radius, shadow, spacing } from '@/theme/tokens';
type AuthShellProps = PropsWithChildren<{
    title: string;
    subtitle: string;
}>;
export function AuthShell({ title, subtitle, children }: AuthShellProps) {
    const { width } = useWindowDimensions();
    const isWide = width >= 760;
    const theme = useAppTheme();
    return (<Screen keyboardAware contentStyle={[styles.content, isWide && styles.contentWide]}>
      <View style={styles.brandArea}>
        <BrandMark />
        <View style={styles.headline}>
          <AppText variant="display">{title}</AppText>
          <AppText color={theme.colors.textSecondary}>{subtitle}</AppText>
        </View>
      </View>
      <View style={[
            styles.card,
            { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
            isWide && styles.cardWide,
        ]}>{children}</View>
      <AppText variant="caption" color={theme.colors.textMuted} style={styles.footer}>
        LoadSense · Projeto de TCC · 2026
      </AppText>
    </Screen>);
}
const styles = StyleSheet.create({
    content: {
        justifyContent: 'center',
    },
    contentWide: {
        alignItems: 'center',
    },
    brandArea: {
        gap: spacing.xxl,
        marginBottom: spacing.xxl,
        maxWidth: 520,
        width: '100%',
    },
    headline: {
        gap: spacing.sm,
    },
    card: {
        borderRadius: radius.lg,
        borderWidth: 1,
        gap: spacing.lg,
        padding: spacing.xl,
        ...shadow,
    },
    cardWide: {
        maxWidth: 520,
        width: '100%',
    },
    footer: {
        marginTop: spacing.xxl,
        textAlign: 'center',
    },
});
