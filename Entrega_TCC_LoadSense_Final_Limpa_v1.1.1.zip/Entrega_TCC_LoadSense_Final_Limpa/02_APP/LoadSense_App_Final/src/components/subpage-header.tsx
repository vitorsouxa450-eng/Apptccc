import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Pressable, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { BrandMark } from '@/components/brand-mark';
import { useAppTheme } from '@/providers/theme-provider';
import { radius, spacing } from '@/theme/tokens';
export function SubpageHeader({ title, subtitle }: {
    title: string;
    subtitle: string;
}) {
    const theme = useAppTheme();
    return (<View>
      <BrandMark compact/>
      <View style={styles.row}>
        <Pressable accessibilityLabel="Voltar" onPress={() => router.back()} style={[styles.back, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
          <Ionicons name="arrow-back" size={22} color={theme.colors.icon}/>
        </Pressable>
        <View style={styles.copy}><AppText variant="title">{title}</AppText><AppText variant="caption" color={theme.colors.textSecondary}>{subtitle}</AppText></View>
      </View>
    </View>);
}
const styles = StyleSheet.create({
    row: { alignItems: 'center', flexDirection: 'row', gap: spacing.md, marginTop: spacing.xxl },
    back: { alignItems: 'center', borderRadius: radius.sm, borderWidth: 1, height: 42, justifyContent: 'center', width: 42 },
    copy: { flex: 1, gap: 2 },
});
