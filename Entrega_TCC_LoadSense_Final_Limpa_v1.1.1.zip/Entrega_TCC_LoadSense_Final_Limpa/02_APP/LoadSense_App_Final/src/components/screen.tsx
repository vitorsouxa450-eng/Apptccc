import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { PropsWithChildren } from 'react';
import { NetworkBanner } from '@/components/network-banner';
import { useAppTheme } from '@/providers/theme-provider';
import { spacing } from '@/theme/tokens';
type ScreenProps = PropsWithChildren<{
    scroll?: boolean;
    keyboardAware?: boolean;
    contentStyle?: StyleProp<ViewStyle>;
    backgroundColor?: string;
}>;
export function Screen({ children, scroll = true, keyboardAware = false, contentStyle, backgroundColor, }: ScreenProps) {
    const theme = useAppTheme();
    const resolvedBackground = backgroundColor ?? theme.colors.background;
    const content = scroll ? (<ScrollView contentContainerStyle={[styles.scrollContent, contentStyle]} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
      {children}
    </ScrollView>) : (<View style={[styles.staticContent, contentStyle]}>{children}</View>);
    return (<SafeAreaView edges={['top']} style={[styles.safeArea, { backgroundColor: resolvedBackground }]}> 
      <NetworkBanner />
      {keyboardAware ? (<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
          {content}
        </KeyboardAvoidingView>) : (content)}
    </SafeAreaView>);
}
const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
    },
    flex: {
        flex: 1,
    },
    scrollContent: {
        flexGrow: 1,
        padding: spacing.xl,
    },
    staticContent: {
        flex: 1,
        padding: spacing.xl,
    },
});
