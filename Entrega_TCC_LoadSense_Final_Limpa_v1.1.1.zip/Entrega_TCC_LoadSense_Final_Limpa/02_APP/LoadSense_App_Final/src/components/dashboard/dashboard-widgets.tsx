import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, shadow, spacing } from '@/theme/tokens';
import type { DashboardAlert, DashboardData, DashboardMetric } from '@/types/dashboard';
type LegendItemProps = {
    color: string;
    label: string;
    value: string;
};
type ActiveOperation = NonNullable<DashboardData['activeOperation']>;
export function MetricCard({ metric }: {
    metric: DashboardMetric;
}) {
    const theme = useAppTheme();
    const metricColors = {
        orange: { foreground: colors.orange, background: theme.colors.orangeSoft },
        green: { foreground: colors.green, background: theme.colors.greenSoft },
        yellow: { foreground: theme.isDark ? colors.yellow : colors.black, background: theme.colors.yellowSoft },
        red: { foreground: colors.red, background: theme.colors.redSoft },
    } as const;
    const palette = metricColors[metric.tone];
    return (<View style={[styles.metricCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
      <View style={[styles.metricMarker, { backgroundColor: palette.background }]}>
        <View style={[styles.metricDot, { backgroundColor: palette.foreground }]}/>
      </View>
      <AppText variant="metric">{metric.value}</AppText>
      <AppText variant="caption" color={theme.colors.textSecondary}>{metric.label}</AppText>
    </View>);
}
export function LegendItem({ color, label, value }: LegendItemProps) {
    const theme = useAppTheme();
    return (<View style={styles.legendRow}>
      <View style={[styles.legendDot, { backgroundColor: color }]}/>
      <View style={styles.legendCopy}>
        <AppText variant="label">{label}</AppText>
        <AppText variant="caption" color={theme.colors.textMuted}>{value}</AppText>
      </View>
    </View>);
}
export function ActiveOperationCard({ operation }: {
    operation: ActiveOperation;
}) {
    return (<View style={styles.operationCard}>
      <View style={styles.operationTop}>
        <View>
          <AppText variant="subtitle" color={colors.white}>{operation.code}</AppText>
          <AppText variant="caption" color={colors.gray300}>{operation.status}</AppText>
        </View>
        <View style={styles.liveBadge}>
          <View style={styles.liveDot}/>
          <AppText variant="caption" color={colors.green}>AO VIVO</AppText>
        </View>
      </View>

      <View style={styles.route}>
        <View style={styles.routePoint}/>
        <View style={styles.routeCopy}>
          <AppText variant="caption" color={colors.gray300}>ORIGEM</AppText>
          <AppText variant="label" color={colors.white}>{operation.origin}</AppText>
        </View>
        <Ionicons name="arrow-forward" size={18} color={colors.gray500}/>
        <View style={styles.routeCopy}>
          <AppText variant="caption" color={colors.gray300}>DESTINO</AppText>
          <AppText variant="label" color={colors.white}>{operation.destination}</AppText>
        </View>
      </View>

      <View style={styles.weightRow}>
        <View>
          <AppText variant="caption" color={colors.gray300}>Peso atual</AppText>
          <AppText variant="metric" color={colors.white}>{operation.currentWeightTons.toFixed(1)} t</AppText>
        </View>
        <AppText variant="label" color={colors.gray300}>
          Meta: {operation.targetWeightTons.toFixed(1)} t
        </AppText>
      </View>

      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${operation.progress}%` }]}/>
      </View>
      <AppText variant="caption" color={colors.gray300} style={styles.progressLabel}>
        {operation.progress}% da meta de carregamento
      </AppText>
    </View>);
}
export function AlertRow({ alert }: {
    alert: DashboardAlert;
}) {
    const theme = useAppTheme();
    const critical = alert.severity === 'critical';
    const palette = critical
        ? { background: theme.colors.redSoft, foreground: colors.red, icon: 'alert-circle' as const }
        : { background: theme.colors.yellowSoft, foreground: theme.isDark ? colors.yellow : colors.black, icon: 'warning' as const };
    return (<Pressable style={({ pressed }) => [styles.alertRow, { borderBottomColor: theme.colors.border }, pressed && styles.pressed]}>
      <View style={[styles.alertIcon, { backgroundColor: palette.background }]}>
        <Ionicons name={palette.icon} size={20} color={palette.foreground}/>
      </View>
      <View style={styles.alertCopy}>
        <AppText variant="label">{alert.title}</AppText>
        <AppText variant="caption" color={theme.colors.textSecondary} numberOfLines={2}>{alert.description}</AppText>
      </View>
      <AppText variant="caption" color={theme.colors.textMuted}>{alert.time}</AppText>
    </Pressable>);
}
const styles = StyleSheet.create({
    metricCard: {
        borderRadius: radius.lg,
        borderWidth: 1,
        flexBasis: '46%',
        flexGrow: 1,
        minWidth: 145,
        padding: spacing.lg,
        ...shadow,
    },
    metricMarker: {
        alignItems: 'center',
        borderRadius: radius.pill,
        height: 28,
        justifyContent: 'center',
        marginBottom: spacing.md,
        width: 28,
    },
    metricDot: {
        borderRadius: radius.pill,
        height: 9,
        width: 9,
    },
    legendRow: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.sm,
    },
    legendDot: {
        borderRadius: radius.pill,
        height: 8,
        width: 8,
    },
    legendCopy: {
        flex: 1,
    },
    operationCard: {
        backgroundColor: colors.black,
        borderRadius: radius.lg,
        gap: spacing.lg,
        padding: spacing.xl,
    },
    operationTop: {
        alignItems: 'flex-start',
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    liveBadge: {
        alignItems: 'center',
        backgroundColor: '#163622',
        borderRadius: radius.pill,
        flexDirection: 'row',
        gap: spacing.xs,
        paddingHorizontal: spacing.md,
        paddingVertical: spacing.sm,
    },
    liveDot: {
        backgroundColor: colors.green,
        borderRadius: radius.pill,
        height: 7,
        width: 7,
    },
    route: {
        alignItems: 'center',
        flexDirection: 'row',
        gap: spacing.sm,
    },
    routePoint: {
        backgroundColor: colors.orange,
        borderRadius: radius.pill,
        height: 10,
        width: 10,
    },
    routeCopy: {
        flex: 1,
    },
    weightRow: {
        alignItems: 'flex-end',
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    progressTrack: {
        backgroundColor: colors.gray700,
        borderRadius: radius.pill,
        height: 9,
        overflow: 'hidden',
    },
    progressFill: {
        backgroundColor: colors.orange,
        borderRadius: radius.pill,
        height: '100%',
    },
    progressLabel: {
        textAlign: 'right',
    },
    alertRow: {
        alignItems: 'center',
        borderBottomWidth: 1,
        flexDirection: 'row',
        gap: spacing.md,
        padding: spacing.lg,
    },
    alertIcon: {
        alignItems: 'center',
        borderRadius: radius.md,
        height: 42,
        justifyContent: 'center',
        width: 42,
    },
    alertCopy: {
        flex: 1,
        gap: spacing.xs,
    },
    pressed: {
        opacity: 0.72,
    },
});
