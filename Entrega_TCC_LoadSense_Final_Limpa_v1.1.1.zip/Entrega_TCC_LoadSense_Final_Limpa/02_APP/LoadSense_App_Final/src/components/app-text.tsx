import { StyleSheet, Text, type TextProps } from 'react-native';
import { useAppTheme } from '@/providers/theme-provider';
import { fonts } from '@/theme/tokens';
type TextVariant = 'display' | 'title' | 'subtitle' | 'body' | 'label' | 'caption' | 'metric';
type AppTextProps = TextProps & {
    variant?: TextVariant;
    color?: string;
};
export function AppText({ variant = 'body', color, style, ...props }: AppTextProps) {
    const theme = useAppTheme();
    return <Text {...props} style={[styles.base, styles[variant], { color: color ?? theme.colors.text }, style]}/>;
}
const styles = StyleSheet.create({
    base: {
        fontFamily: fonts.bodyRegular,
    },
    display: {
        fontFamily: fonts.headingBold,
        fontSize: 30,
        lineHeight: 38,
        letterSpacing: -0.6,
    },
    title: {
        fontFamily: fonts.headingBold,
        fontSize: 22,
        lineHeight: 29,
        letterSpacing: -0.2,
    },
    subtitle: {
        fontFamily: fonts.headingSemiBold,
        fontSize: 17,
        lineHeight: 24,
    },
    body: {
        fontFamily: fonts.bodyRegular,
        fontSize: 15,
        lineHeight: 22,
    },
    label: {
        fontFamily: fonts.bodySemiBold,
        fontSize: 14,
        lineHeight: 20,
    },
    caption: {
        fontFamily: fonts.bodyRegular,
        fontSize: 12,
        lineHeight: 18,
    },
    metric: {
        fontFamily: fonts.headingBold,
        fontSize: 26,
        lineHeight: 32,
    },
});
