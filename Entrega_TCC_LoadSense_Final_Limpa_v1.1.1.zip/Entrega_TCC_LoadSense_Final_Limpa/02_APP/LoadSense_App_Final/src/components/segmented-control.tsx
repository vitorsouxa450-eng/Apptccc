import { Pressable, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
type Option<T extends string> = {
    label: string;
    value: T;
};
type SegmentedControlProps<T extends string> = {
    options: Option<T>[];
    value: T;
    onChange: (value: T) => void;
};
export function SegmentedControl<T extends string>({ options, value, onChange }: SegmentedControlProps<T>) {
    const theme = useAppTheme();
    return (<View style={[styles.container, { backgroundColor: theme.colors.surfaceMuted }]}>
      {options.map((option) => {
            const selected = value === option.value;
            return (<Pressable key={option.value} accessibilityRole="tab" accessibilityState={{ selected }} onPress={() => onChange(option.value)} style={({ pressed }) => [
                    styles.option,
                    selected && styles.selected,
                    pressed && styles.pressed,
                ]}>
            <AppText variant="label" color={selected ? colors.white : theme.colors.textSecondary}>
              {option.label}
            </AppText>
          </Pressable>);
        })}
    </View>);
}
const styles = StyleSheet.create({
    container: {
        borderRadius: radius.sm,
        flexDirection: 'row',
        padding: 3,
    },
    option: {
        alignItems: 'center',
        borderRadius: 6,
        flex: 1,
        justifyContent: 'center',
        minHeight: 40,
        paddingHorizontal: spacing.sm,
    },
    selected: {
        backgroundColor: colors.orange,
    },
    pressed: {
        opacity: 0.78,
    },
});
