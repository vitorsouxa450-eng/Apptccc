import { Ionicons } from '@expo/vector-icons';
import { forwardRef, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View, type TextInputProps } from 'react-native';
import { AppText } from '@/components/app-text';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, fonts, radius, spacing } from '@/theme/tokens';
type FormFieldProps = TextInputProps & {
    label: string;
    error?: string;
    icon?: keyof typeof Ionicons.glyphMap;
};
export const FormField = forwardRef<TextInput, FormFieldProps>(function FormField({ label, error, icon, secureTextEntry, style, ...props }, ref) {
    const [passwordVisible, setPasswordVisible] = useState(false);
    const isPassword = Boolean(secureTextEntry);
    const theme = useAppTheme();
    return (<View style={styles.field}>
      <AppText variant="label" color={theme.colors.textSecondary}>
        {label}
      </AppText>
      <View style={[
            styles.inputShell,
            { backgroundColor: theme.colors.input, borderColor: theme.colors.borderStrong },
            error && styles.inputShellError,
        ]}>
        {icon ? <Ionicons name={icon} size={19} color={theme.colors.textMuted}/> : null}
        <TextInput ref={ref} accessibilityLabel={label} autoCapitalize="none" placeholderTextColor={theme.colors.textMuted} secureTextEntry={isPassword && !passwordVisible} style={[styles.input, { color: theme.colors.text }, style]} {...props}/>
        {isPassword ? (<Pressable accessibilityLabel={passwordVisible ? 'Ocultar senha' : 'Mostrar senha'} accessibilityRole="button" hitSlop={8} onPress={() => setPasswordVisible((value) => !value)}>
            <Ionicons name={passwordVisible ? 'eye-off-outline' : 'eye-outline'} size={20} color={theme.colors.textSecondary}/>
          </Pressable>) : null}
      </View>
      {error ? (<AppText variant="caption" color={colors.red}>
          {error}
        </AppText>) : null}
    </View>);
});
const styles = StyleSheet.create({
    field: {
        gap: 6,
    },
    inputShell: {
        alignItems: 'center',
        borderRadius: radius.md,
        borderWidth: 1,
        flexDirection: 'row',
        gap: spacing.sm,
        minHeight: 50,
        paddingHorizontal: spacing.md,
    },
    inputShellError: {
        borderColor: colors.red,
    },
    input: {
        flex: 1,
        fontFamily: fonts.bodyRegular,
        fontSize: 15,
        paddingVertical: spacing.md,
    },
});
