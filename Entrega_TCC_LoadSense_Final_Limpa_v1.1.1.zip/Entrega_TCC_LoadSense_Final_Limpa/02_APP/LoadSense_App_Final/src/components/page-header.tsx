import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Pressable, StyleSheet, View } from 'react-native';
import { AppText } from '@/components/app-text';
import { BrandMark } from '@/components/brand-mark';
import { useSession } from '@/providers/session-provider';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
type PageHeaderProps = {
    title?: string;
    subtitle?: string;
    showNotifications?: boolean;
};
export function PageHeader({ title, subtitle, showNotifications = true }: PageHeaderProps) {
    const { session } = useSession();
    const theme = useAppTheme();
    return (<View>
      <View style={styles.header}>
        <BrandMark compact/>
        {showNotifications ? (<Pressable accessibilityLabel="Abrir notificações" accessibilityRole="button" hitSlop={8} onPress={() => router.push('/notifications')} style={({ pressed }) => [
                styles.notification,
                { backgroundColor: theme.colors.surface, borderColor: theme.colors.border },
                pressed && styles.pressed,
            ]}>
            <Ionicons name="notifications-outline" size={23} color={theme.colors.icon}/>
            <View style={[styles.badge, { borderColor: theme.colors.surface }]}/>
          </Pressable>) : null}
      </View>
      {title ? (<View style={styles.copy}>
          <AppText variant="title">{title}</AppText>
          <AppText variant="caption" color={theme.colors.textSecondary} numberOfLines={1}>
            {subtitle ?? session?.company.name ?? 'LoadSense'}
          </AppText>
        </View>) : null}
    </View>);
}
const styles = StyleSheet.create({
    header: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    copy: {
        gap: spacing.xs,
        marginTop: spacing.xxl,
    },
    notification: {
        alignItems: 'center',
        borderRadius: radius.md,
        borderWidth: 1,
        height: 44,
        justifyContent: 'center',
        marginLeft: spacing.md,
        width: 44,
    },
    badge: {
        backgroundColor: colors.red,
        borderRadius: radius.pill,
        borderWidth: 2,
        height: 10,
        position: 'absolute',
        right: 8,
        top: 7,
        width: 10,
    },
    pressed: {
        opacity: 0.7,
    },
});
