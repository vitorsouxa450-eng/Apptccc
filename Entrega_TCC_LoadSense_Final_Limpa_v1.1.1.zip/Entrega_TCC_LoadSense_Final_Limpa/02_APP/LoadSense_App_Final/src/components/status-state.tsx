import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, View } from 'react-native';
import { AppButton } from '@/components/app-button';
import { AppText } from '@/components/app-text';
import { useAppTheme } from '@/providers/theme-provider';
import { colors, radius, spacing } from '@/theme/tokens';
type StatusStateProps = {
    icon: keyof typeof Ionicons.glyphMap;
    title: string;
    description: string;
    actionLabel?: string;
    onAction?: () => void;
    tone?: 'neutral' | 'warning' | 'error';
};
export function StatusState({ icon, title, description, actionLabel, onAction, tone = 'neutral', }: StatusStateProps) {
    const theme = useAppTheme();
    const tones = {
        neutral: { background: theme.colors.orangeSoft, foreground: colors.orange },
        warning: { background: theme.colors.yellowSoft, foreground: theme.isDark ? colors.yellow : colors.black },
        error: { background: theme.colors.redSoft, foreground: colors.red },
    };
    const palette = tones[tone];
    return (<View style={styles.container}>
      <View style={[styles.icon, { backgroundColor: palette.background }]}>
        <Ionicons name={icon} size={34} color={palette.foreground}/>
      </View>
      <AppText variant="title" style={styles.center}>
        {title}
      </AppText>
      <AppText color={theme.colors.textSecondary} style={styles.center}>
        {description}
      </AppText>
      {actionLabel && onAction ? (<View style={styles.action}>
          <AppButton label={actionLabel} onPress={onAction}/>
        </View>) : null}
    </View>);
}
const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        flex: 1,
        justifyContent: 'center',
        padding: spacing.xxl,
    },
    icon: {
        alignItems: 'center',
        borderRadius: radius.pill,
        height: 72,
        justifyContent: 'center',
        marginBottom: spacing.xl,
        width: 72,
    },
    center: {
        marginBottom: spacing.sm,
        maxWidth: 440,
        textAlign: 'center',
    },
    action: {
        marginTop: spacing.lg,
        maxWidth: 320,
        width: '100%',
    },
});
