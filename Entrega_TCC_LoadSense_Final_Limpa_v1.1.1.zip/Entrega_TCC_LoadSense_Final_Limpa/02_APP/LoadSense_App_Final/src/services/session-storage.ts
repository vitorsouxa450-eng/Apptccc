import * as SecureStore from 'expo-secure-store';
const REFRESH_TOKEN_KEY = 'loadsense.refresh-token';
let memoryFallback: string | null = null;
async function canUseSecureStore() {
    try {
        return await SecureStore.isAvailableAsync();
    }
    catch {
        return false;
    }
}
export const sessionStorage = {
    async getRefreshToken() {
        if (await canUseSecureStore()) {
            return SecureStore.getItemAsync(REFRESH_TOKEN_KEY);
        }
        return memoryFallback;
    },
    async setRefreshToken(token: string) {
        if (await canUseSecureStore()) {
            await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, token, {
                keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
            });
            return;
        }
        memoryFallback = token;
    },
    async clearRefreshToken() {
        if (await canUseSecureStore()) {
            await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
        }
        memoryFallback = null;
    },
};
