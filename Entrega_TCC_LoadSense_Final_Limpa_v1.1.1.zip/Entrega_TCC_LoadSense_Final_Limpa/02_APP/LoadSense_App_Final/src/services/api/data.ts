import { request } from '@/services/api/client';
import type { DashboardData } from '@/types/dashboard';
import type { Operation, ReportsData, ReportItem, ReportPeriod } from '@/types/operations';
export const dataApi = {
    async getDashboard() {
        return request<DashboardData>('/dashboard');
    },
    async getOperations() {
        return request<Operation[]>('/operations');
    },
    async getMonitoringOperations() {
        return request<Operation[]>('/monitoring/operations');
    },
    async getOperation(id: string) {
        return request<Operation>(`/operations/${encodeURIComponent(id)}`);
    },
    async createReport(period: ReportPeriod) {
        return request<{
            id: string;
            state: string;
        }>('/reports', {
            method: 'POST',
            body: JSON.stringify({ period }),
        });
    },
    async getReports(period: ReportPeriod): Promise<ReportsData> {
        const [summary, reports] = await Promise.all([
            request<Omit<ReportsData, 'reports'>>(`/reports/summary?period=${encodeURIComponent(period)}`),
            request<ReportItem[]>('/reports'),
        ]);
        return { ...summary, reports };
    },
};
