import { sessionStorage } from '@/services/session-storage';
import { ApiError } from '@/services/api/errors';
type ErrorPayload = {
    error?: {
        message?: string;
        code?: string;
    };
};
const API_URL = (process.env.EXPO_PUBLIC_API_URL ?? '').replace(/\/$/, '');
let accessToken: string | null = null;
let refreshPromise: Promise<boolean> | null = null;
export function setAccessToken(token: string | null) {
    accessToken = token;
}
export function getAccessToken() {
    return accessToken;
}
export function clearAccessToken() {
    accessToken = null;
}
function requireApiUrl() {
    if (!API_URL)
        throw new ApiError('EXPO_PUBLIC_API_URL não foi configurada.');
    return API_URL;
}
async function parseResponse<T>(response: Response): Promise<T> {
    if (response.status === 204)
        return undefined as T;
    const text = await response.text();
    let payload: ErrorPayload | null = null;
    try {
        payload = text ? JSON.parse(text) : null;
    }
    catch {
        payload = null;
    }
    if (!response.ok) {
        throw new ApiError(payload?.error?.message || 'Não foi possível concluir a solicitação.', response.status, payload?.error?.code);
    }
    return payload as T;
}
export async function rawRequest<T>(path: string, init: RequestInit = {}) {
    const response = await fetch(`${requireApiUrl()}${path}`, {
        ...init,
        headers: {
            Accept: 'application/json',
            ...(init.body ? { 'Content-Type': 'application/json' } : {}),
            ...(init.headers ?? {}),
        },
    });
    return parseResponse<T>(response);
}
async function refreshAccessToken() {
    if (refreshPromise)
        return refreshPromise;
    refreshPromise = (async () => {
        const refreshToken = await sessionStorage.getRefreshToken();
        if (!refreshToken)
            return false;
        try {
            const result = await rawRequest<{
                access_token: string;
                refresh_token: string;
            }>('/auth/refresh', {
                method: 'POST',
                body: JSON.stringify({ refresh_token: refreshToken }),
            });
            setAccessToken(result.access_token);
            await sessionStorage.setRefreshToken(result.refresh_token);
            return true;
        }
        catch {
            clearAccessToken();
            await sessionStorage.clearRefreshToken();
            return false;
        }
    })();
    try {
        return await refreshPromise;
    }
    finally {
        refreshPromise = null;
    }
}
export async function request<T>(path: string, init: RequestInit = {}, authenticated = true, retry = true): Promise<T> {
    const headers = new Headers(init.headers);
    if (authenticated && accessToken)
        headers.set('Authorization', `Bearer ${accessToken}`);
    try {
        return await rawRequest<T>(path, { ...init, headers });
    }
    catch (error) {
        if (authenticated && retry && error instanceof ApiError && error.status === 401) {
            if (await refreshAccessToken())
                return request<T>(path, init, true, false);
        }
        throw error;
    }
}
