import { Platform } from 'react-native';
import { APP_VERSION } from '@/constants/app';
import { clearAccessToken, getAccessToken, rawRequest, request, setAccessToken, } from '@/services/api/client';
import type { BootstrapResult, CompanyRequestInput, LoginInput, UserSession } from '@/types/auth';
type LoginResponse = {
    access_token: string;
    refresh_token: string;
    user: UserSession['user'];
    company: UserSession['company'];
    permissions: string[];
    terms_accepted: boolean;
};
function toSession(result: LoginResponse): UserSession {
    return {
        accessToken: result.access_token,
        company: result.company,
        user: result.user,
        permissions: result.permissions,
        termsAccepted: result.terms_accepted,
    };
}
export const authApi = {
    async bootstrap(): Promise<BootstrapResult> {
        const platform = Platform.OS === 'ios' ? 'IOS' : 'ANDROID';
        return rawRequest<BootstrapResult>(`/app/bootstrap?platform=${platform}&build=1`, {}, false);
    },
    async login(input: LoginInput) {
        const result = await rawRequest<LoginResponse>('/auth/login', {
            method: 'POST',
            body: JSON.stringify({
                company_code: input.companyCode,
                email: input.email,
                password: input.password,
                device: { platform: Platform.OS, app_version: APP_VERSION },
            }),
        }, false);
        setAccessToken(result.access_token);
        return { session: toSession(result), refreshToken: result.refresh_token };
    },
    async resumeSession(refreshToken: string) {
        const result = await rawRequest<LoginResponse>('/auth/refresh', {
            method: 'POST',
            body: JSON.stringify({ refresh_token: refreshToken }),
        }, false);
        setAccessToken(result.access_token);
        return toSession(result);
    },
    async revokeSession(refreshToken?: string) {
        clearAccessToken();
        if (!refreshToken)
            return;
        await rawRequest<void>('/auth/logout', {
            method: 'POST',
            body: JSON.stringify({ refresh_token: refreshToken }),
        }, false);
    },
    async acceptTerms(session?: UserSession) {
        const result = await request<Omit<LoginResponse, 'access_token' | 'refresh_token' | 'expires_in'>>('/me/legal-acceptances', {
            method: 'POST',
            body: JSON.stringify({}),
        });
        return {
            accessToken: session?.accessToken ?? getAccessToken() ?? '',
            company: result.company,
            user: result.user,
            permissions: result.permissions,
            termsAccepted: result.terms_accepted,
        } satisfies UserSession;
    },
    async requestPasswordReset(companyCode: string, email: string) {
        await request('/auth/password/forgot', {
            method: 'POST',
            body: JSON.stringify({ company_code: companyCode, email }),
        }, false);
    },
    async requestCompany(input: CompanyRequestInput) {
        return request<{
            requestId: string;
        }>('/company-requests', {
            method: 'POST',
            body: JSON.stringify({
                legal_name: input.legalName,
                document: input.document,
                responsible_name: input.responsibleName,
                email: input.email,
                phone: input.phone,
                accepted_privacy: input.acceptedPrivacy,
            }),
        }, false);
    },
};
