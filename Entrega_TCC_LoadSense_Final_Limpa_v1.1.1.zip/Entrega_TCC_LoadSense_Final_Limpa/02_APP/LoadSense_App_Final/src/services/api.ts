import { authApi } from '@/services/api/auth';
import { dataApi } from '@/services/api/data';
export { ApiError } from '@/services/api/errors';
export const api = {
    ...authApi,
    ...dataApi,
};
