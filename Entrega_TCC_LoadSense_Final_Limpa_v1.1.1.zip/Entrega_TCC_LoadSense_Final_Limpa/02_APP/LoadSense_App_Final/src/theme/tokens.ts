import { Platform, type ViewStyle } from 'react-native';
export const colors = {
    orange: '#FF5B1F',
    orangeDark: '#D9420B',
    orangeSoft: '#FFF0EA',
    black: '#121212',
    gray900: '#1E1E1E',
    gray700: '#454545',
    gray600: '#626262',
    gray500: '#7A7A7A',
    gray300: '#D3D3D3',
    gray200: '#E6E6E6',
    gray100: '#F0F0F0',
    offWhite: '#F5F5F5',
    white: '#FFFFFF',
    green: '#22C55E',
    greenSoft: '#EAF9F0',
    yellow: '#FFF100',
    yellowSoft: '#FFFCE0',
    red: '#EF4444',
    redSoft: '#FEECEC',
    blue: '#2563EB',
    blueSoft: '#EAF0FF',
} as const;
export type ThemeMode = 'light' | 'dark';
export type ThemeColors = {
    background: string;
    surface: string;
    surfaceElevated: string;
    surfaceMuted: string;
    border: string;
    borderStrong: string;
    text: string;
    textSecondary: string;
    textMuted: string;
    icon: string;
    input: string;
    tabBar: string;
    pressed: string;
    overlay: string;
    orangeSoft: string;
    greenSoft: string;
    yellowSoft: string;
    redSoft: string;
    blueSoft: string;
};
export const themeColors: Record<ThemeMode, ThemeColors> = {
    dark: {
        background: '#080909',
        surface: '#111212',
        surfaceElevated: '#181919',
        surfaceMuted: '#202121',
        border: '#252727',
        borderStrong: '#343636',
        text: '#F7F7F7',
        textSecondary: '#C7C9C9',
        textMuted: '#858888',
        icon: '#D8DADA',
        input: '#181919',
        tabBar: '#0C0D0D',
        pressed: '#242626',
        overlay: 'rgba(0, 0, 0, 0.72)',
        orangeSoft: '#391A10',
        greenSoft: '#0E2B1B',
        yellowSoft: '#342D0B',
        redSoft: '#351315',
        blueSoft: '#111E38',
    },
    light: {
        background: '#F5F5F5',
        surface: '#FFFFFF',
        surfaceElevated: '#FFFFFF',
        surfaceMuted: '#EEEEEE',
        border: '#E2E2E2',
        borderStrong: '#CACACA',
        text: '#161616',
        textSecondary: '#505050',
        textMuted: '#777777',
        icon: '#282828',
        input: '#FFFFFF',
        tabBar: '#FFFFFF',
        pressed: '#EEEEEE',
        overlay: 'rgba(18, 18, 18, 0.48)',
        orangeSoft: '#FFF0EA',
        greenSoft: '#EAF9F0',
        yellowSoft: '#FFF8D6',
        redSoft: '#FEECEC',
        blueSoft: '#EAF0FF',
    },
};
export const spacing = {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    xxl: 24,
    xxxl: 32,
    huge: 40,
} as const;
export const radius = {
    sm: 8,
    md: 12,
    lg: 16,
    xl: 24,
    pill: 999,
} as const;
export const fonts = {
    headingSemiBold: 'Montserrat_600SemiBold',
    headingBold: 'Montserrat_700Bold',
    bodyRegular: 'OpenSans_400Regular',
    bodySemiBold: 'OpenSans_600SemiBold',
    bodyBold: 'OpenSans_700Bold',
} as const;
export const shadow: ViewStyle = Platform.select({
    ios: {
        shadowColor: colors.black,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.08,
        shadowRadius: 12,
    },
    android: { elevation: 3 },
    default: {
        boxShadow: '0 4px 16px rgba(18, 18, 18, 0.08)',
    },
}) as ViewStyle;
