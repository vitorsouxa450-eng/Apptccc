# Contrato inicial da API — LoadSense Mobile

Esta versão implementa o cliente HTTP em `src/services/api.ts` e consome a API REST correspondente. O aplicativo, o painel web e os dispositivos nunca acessam o MySQL diretamente.

## Regras obrigatórias

- Base sugerida: `/api/v1`.
- Todas as respostas usam JSON e HTTPS em produção.
- O contexto da empresa vem da autenticação; não confiar em `company_id` enviado livremente pelo cliente.
- O login recebe `company_code`, `email` e `password`.
- O `access_token` permanece somente em memória; o `refresh_token` fica no SecureStore.
- O encerramento da sessão revoga o `refresh_token` no servidor.
- Perfis válidos: `ADMINISTRATOR`, `SUPERVISOR` e `OPERATOR`.
- Erros de autenticação e recuperação de senha não devem revelar se uma conta existe.

## Endpoints da primeira integração

| Método | Rota | Uso |
| --- | --- | --- |
| `GET` | `/app/bootstrap` | Manutenção, versão mínima e atualização obrigatória |
| `POST` | `/auth/login` | Login multiempresa |
| `POST` | `/auth/refresh` | Renovar o token de acesso |
| `POST` | `/auth/logout` | Revogar a sessão atual |
| `POST` | `/auth/password/forgot` | Solicitar recuperação sem enumerar contas |
| `GET` | `/me` | Usuário, empresa, perfil, permissões e aceite legal |
| `POST` | `/me/legal-acceptances` | Registrar versão aceita dos documentos |
| `POST` | `/company-requests` | Solicitação pública de nova empresa |
| `GET` | `/dashboard` | Indicadores, operação em destaque e alertas |
| `GET` | `/operations?state=&search=` | Operações ativas/concluídas com busca e paginação |
| `GET` | `/operations/{id}` | Resumo, pesagens, trajeto e alertas da operação |
| `GET` | `/monitoring/operations` | Posição atual, RFID, dispositivo, sinal e progresso |
| `GET` | `/reports/summary?period=` | Indicadores e séries do período selecionado |
| `GET` | `/reports` | Histórico de relatórios gerados |
| `POST` | `/reports` | Solicitar geração assíncrona de relatório/PDF |
| `GET` | `/system/status` | Estado resumido das integrações e dispositivos |

## Exemplo de login

Requisição:

```json
{
  "company_code": "loadsense-demo",
  "email": "admin@loadsense.com",
  "password": "senha-do-usuario",
  "device": {
    "platform": "android",
    "app_version": "0.2.0"
  }
}
```

Resposta `200`:

```json
{
  "access_token": "token-curto",
  "refresh_token": "token-rotativo",
  "expires_in": 900,
  "user": {
    "id": "user-001",
    "name": "Ana Martins",
    "email": "admin@loadsense.com",
    "role": "ADMINISTRATOR"
  },
  "company": {
    "id": "company-001",
    "code": "loadsense-demo",
    "name": "LoadSense Demonstração"
  },
  "permissions": ["dashboard.read", "operations.read"],
  "terms_accepted": false
}
```

## Padrão de erro

```json
{
  "error": {
    "code": "INVALID_CREDENTIALS",
    "message": "Empresa, e-mail ou senha inválidos.",
    "request_id": "req_01J..."
  }
}
```

O aplicativo deve traduzir códigos conhecidos em mensagens amigáveis e manter uma opção de tentar novamente para falhas transitórias.
