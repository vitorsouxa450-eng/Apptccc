# LoadSense — Site Final Integrado

Esta pasta é a versão final do site fornecida para o TCC, com a integração REST ao backend LoadSense.

## Requisito
O backend deve estar executando em `http://localhost:3333` e o MySQL deve estar ativo conforme o pacote do backend.

## Abrir
Acesse `http://localhost:3333/`.

## Login de demonstração
- Código da empresa: `loadsense-demo`
- E-mail: `admin@loadsense.local`
- Senha: `LoadSense123!`

O navegador usa a API em `/api/v1` e os dados são lidos/escritos no MySQL através do backend.
