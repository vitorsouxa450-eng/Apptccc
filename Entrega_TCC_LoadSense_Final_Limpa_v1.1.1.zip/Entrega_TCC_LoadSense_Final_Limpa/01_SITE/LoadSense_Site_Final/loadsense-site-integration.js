(function () {
    'use strict';
    const API = () => window.LoadSenseAPI;
    const file = window.location.pathname.toLowerCase().split('/').pop();
    const publicPages = new Set(['login.html', 'cadastro.html']);
    function escapeHtml(value) {
        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }
    function fmtKg(value) {
        return `${Number(value || 0).toLocaleString('pt-BR', { maximumFractionDigits: 0 })} kg`;
    }
    function fmtDate(value) {
        if (!value)
            return '—';
        const text = String(value);
        const date = new Date(text.includes('T') || text.endsWith('Z') ? text : `${text.replace(' ', 'T')}Z`);
        return Number.isNaN(date.getTime())
            ? text
            : date.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
    }
    function showToast(message) {
        const toast = document.getElementById('toast');
        const toastText = document.getElementById('toastText') || document.getElementById('toastDescription');
        if (!toast)
            return;
        if (toastText)
            toastText.textContent = message;
        toast.classList.add('show');
        window.setTimeout(() => toast.classList.remove('show'), 3000);
    }
    function redirectLogin() {
        const protectedPages = new Set([
            'dashboard.html', 'planilha.html', 'historico.html', 'alertas.html',
            'monitoramento.html', 'configuracoes.html', 'novapesagem.html', 'relatorios.html'
        ]);
        if (protectedPages.has(file)) {
            window.location.href = '../LoadSense/Login.html';
        }
    }
    function applyUserToPage() {
        try {
            const user = JSON.parse(localStorage.getItem('loadsense_usuario') || '{}');
            document.querySelectorAll('.profile-name').forEach((element) => {
                if (user.nome)
                    element.textContent = user.nome;
            });
            document.querySelectorAll('.profile-role').forEach((element) => {
                if (user.perfil)
                    element.textContent = user.perfil;
            });
            document.querySelectorAll('.avatar').forEach((element) => {
                if (!user.nome)
                    return;
                const parts = String(user.nome).trim().split(/\s+/);
                element.textContent = `${parts[0]?.[0] || ''}${parts.at(-1)?.[0] || ''}`.toUpperCase();
            });
        }
        catch (_) {
        }
    }
    async function requireSession() {
        if (publicPages.has(file))
            return true;
        const ok = await API().resume();
        if (!ok) {
            redirectLogin();
            return false;
        }
        applyUserToPage();
        return true;
    }
    function addCompanyField() {
        let field = document.getElementById('companyCode');
        if (field)
            return field;
        const form = document.getElementById('loginForm');
        const email = document.getElementById('email');
        const group = email?.closest('.form-group') || email?.parentElement;
        if (!form || !group)
            return null;
        const container = document.createElement('div');
        container.className = group.className || 'form-group';
        container.innerHTML = `
      <label for="companyCode">Código da empresa</label>
      <div class="input-wrapper">
        <input type="text" id="companyCode" name="companyCode" value="loadsense-demo" placeholder="loadsense-demo" autocomplete="organization">
      </div>
    `;
        group.parentElement?.insertBefore(container, group);
        return document.getElementById('companyCode');
    }
    async function initLogin() {
        const form = document.getElementById('loginForm');
        if (!form || !API())
            return;
        const company = addCompanyField();
        const button = document.getElementById('loginButton');
        const forgot = document.getElementById('forgotPassword');
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            event.stopPropagation();
            const companyCode = company?.value.trim() || 'loadsense-demo';
            const email = document.getElementById('email')?.value.trim() || '';
            const password = document.getElementById('senha')?.value || '';
            if (!companyCode || !email || !password) {
                showToast('Informe código da empresa, e-mail e senha.');
                return;
            }
            const oldContent = button?.innerHTML;
            if (button) {
                button.disabled = true;
                button.innerHTML = '<span>Entrando...</span>';
            }
            try {
                const result = await API().login(companyCode, email, password);
                window.location.href = result.terms_accepted
                    ? '../Dashboard/Dashboard.html'
                    : '../Configuracoes/Configuracoes.html';
            }
            catch (error) {
                showToast(error.message || 'Não foi possível entrar.');
                if (button) {
                    button.disabled = false;
                    button.innerHTML = oldContent || '<span>Entrar</span>';
                }
            }
        }, { once: true });
        forgot?.addEventListener('click', async (event) => {
            event.preventDefault();
            const email = document.getElementById('email')?.value.trim() || '';
            if (!email) {
                showToast('Informe o e-mail para recuperar o acesso.');
                return;
            }
            try {
                await API().forgotPassword(company?.value.trim() || 'loadsense-demo', email);
                showToast('Se a conta existir, as instruções de recuperação serão enviadas.');
            }
            catch (error) {
                showToast(error.message || 'Não foi possível iniciar a recuperação.');
            }
        }, { once: true });
    }
    async function initCadastro() {
        const form = document.getElementById('cadastroForm');
        if (!form || !API())
            return;
        let documentInput = document.getElementById('documentoEmpresa');
        if (!documentInput) {
            const companyInput = document.getElementById('empresa');
            const group = companyInput?.closest('.form-group');
            if (group?.parentElement) {
                const container = document.createElement('div');
                container.className = group.className || 'form-group';
                container.innerHTML = `
          <label for="documentoEmpresa">CNPJ da empresa</label>
          <div class="input-wrapper">
            <input type="text" id="documentoEmpresa" name="documentoEmpresa" placeholder="00.000.000/0000-00" autocomplete="organization">
          </div>
        `;
                group.parentElement.insertBefore(container, group.nextSibling);
                documentInput = document.getElementById('documentoEmpresa');
            }
        }
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            event.stopPropagation();
            const name = document.getElementById('nome')?.value.trim() || '';
            const company = document.getElementById('empresa')?.value.trim() || '';
            const email = document.getElementById('email')?.value.trim() || '';
            const phone = document.getElementById('telefone')?.value.trim() || null;
            const documentNumber = documentInput?.value.trim() || '';
            const accepted = document.getElementById('aceitarTermos')?.checked === true;
            const button = document.getElementById('cadastroButton');
            if (!name || !company || !email || !documentNumber || !accepted) {
                showToast('Preencha nome, empresa, CNPJ, e-mail e aceite os termos.');
                return;
            }
            if (button) {
                button.disabled = true;
                button.dataset.originalText = button.textContent;
                button.textContent = 'Enviando solicitação...';
            }
            try {
                const result = await API().requestCompany({
                    legal_name: company,
                    document: documentNumber,
                    responsible_name: name,
                    email,
                    phone,
                    accepted_privacy: true
                });
                showToast(`Solicitação enviada: ${result.requestId}`);
                window.setTimeout(() => {
                    window.location.href = '../LoadSense/Login.html';
                }, 1200);
            }
            catch (error) {
                showToast(error.message || 'Não foi possível enviar a solicitação.');
                if (button) {
                    button.disabled = false;
                    button.textContent = button.dataset.originalText || 'Criar conta →';
                }
            }
        }, { once: true });
    }
    async function initDashboard() {
        const data = await API().dashboard();
        const metrics = document.querySelectorAll('.metric-card .metric-value');
        const value = (id) => Number((data.metrics || []).find((item) => item.id === id)?.value ?? 0);
        if (metrics[0])
            metrics[0].textContent = value('trips').toLocaleString('pt-BR');
        if (metrics[1])
            metrics[1].textContent = `${value('tons').toLocaleString('pt-BR', { maximumFractionDigits: 1 })} t`;
        if (metrics[2])
            metrics[2].textContent = value('alerts').toLocaleString('pt-BR');
        if (metrics[3])
            metrics[3].textContent = `${value('normal_percent').toLocaleString('pt-BR', { maximumFractionDigits: 1 })}%`;
        const list = document.getElementById('operationsList');
        if (!list)
            return;
        const operations = await API().operations('', '');
        list.innerHTML = operations.slice(0, 10).map((operation) => `
      <div class="operation-row" data-operation-id="${escapeHtml(operation.id)}">
        <span class="operation-id">${escapeHtml(operation.code)}</span>
        <span class="operation-date">${escapeHtml(fmtDate(operation.scheduledAt))}</span>
        <span class="plate">${escapeHtml(operation.plate || '—')}</span>
        <span class="driver">${escapeHtml(operation.driver || 'Não informado')}</span>
        <span class="weight">${escapeHtml(fmtKg(Number(operation.currentWeightTons || 0) * 1000))}</span>
        <span class="status-badge">${escapeHtml(operation.status || 'Em análise')}</span>
      </div>
    `).join('') || '<div class="no-results" style="display:block">Nenhuma operação registrada.</div>';
        list.querySelectorAll('.operation-row').forEach((row) => {
            row.addEventListener('click', () => {
                if (row.dataset.operationId) {
                    window.location.href = `../Historico/Historico.html?operation=${encodeURIComponent(row.dataset.operationId)}`;
                }
            });
        });
    }
    async function initOperationsTable() {
        const tbody = document.getElementById('tableBody');
        if (!tbody)
            return;
        const operations = await API().operations('', '');
        tbody.innerHTML = operations.map((operation) => `
      <tr data-operation-id="${escapeHtml(operation.id)}">
        <td>${escapeHtml(operation.code)}</td>
        <td>${escapeHtml(fmtDate(operation.scheduledAt))}</td>
        <td>${escapeHtml(operation.plate || '—')}</td>
        <td>${escapeHtml(operation.driver || 'Não informado')}</td>
        <td>${escapeHtml(operation.rfidTag || '—')}</td>
        <td>${escapeHtml(fmtKg(Number(operation.currentWeightTons || 0) * 1000))}</td>
        <td>${escapeHtml(operation.status || 'Em análise')}</td>
      </tr>
    `).join('') || '<tr><td colspan="7">Nenhuma operação registrada.</td></tr>';
        const counter = document.getElementById('operationCounter');
        if (counter)
            counter.textContent = `${operations.length} operações`;
    }
    async function initAlerts() {
        const container = document.getElementById('alertsContainer');
        if (!container)
            return;
        const alerts = await API().alerts();
        container.innerHTML = alerts.map((alert) => `
      <article class="alert-card" data-alert-id="${escapeHtml(alert.id)}">
        <div>
          <span class="alert-level ${alert.severity === 'CRITICAL' ? 'critical' : 'warning'}">${alert.severity === 'CRITICAL' ? 'Crítico' : 'Atenção'}</span>
          <h3>${escapeHtml(alert.title)}</h3>
          <p>${escapeHtml(alert.message)}</p>
          <small>${escapeHtml(alert.operation_code || '')} · ${escapeHtml(fmtDate(alert.created_at))}</small>
        </div>
        <div class="alert-actions">
          <button type="button" data-alert-action="${escapeHtml(alert.id)}">
            ${alert.state === 'ACKNOWLEDGED' ? 'Resolver' : 'Reconhecer'}
          </button>
        </div>
      </article>
    `).join('') || '<p>Nenhum alerta ativo.</p>';
        container.querySelectorAll('[data-alert-action]').forEach((button) => {
            button.addEventListener('click', async () => {
                const id = button.dataset.alertAction;
                const current = alerts.find((item) => String(item.id) === String(id));
                if (!current)
                    return;
                try {
                    const nextState = current.state === 'ACKNOWLEDGED' ? 'RESOLVED' : 'ACKNOWLEDGED';
                    await API().updateAlert(id, nextState, nextState === 'RESOLVED' ? 'Resolvido pelo painel web.' : 'Reconhecido pelo painel web.');
                    await initAlerts();
                    showToast('Alerta atualizado.');
                }
                catch (error) {
                    showToast(error.message || 'Não foi possível atualizar o alerta.');
                }
            });
        });
        const count = document.querySelector('.notification-count') || document.querySelector('.alert-count');
        if (count)
            count.textContent = String(alerts.length);
    }
    async function initHistory() {
        const list = document.getElementById('historyList');
        if (!list)
            return;
        const operations = await API().operations('', 'COMPLETED');
        list.innerHTML = operations.map((operation) => `
      <article class="history-item" data-operation-id="${escapeHtml(operation.id)}">
        <div><strong>${escapeHtml(operation.code)}</strong><span>${escapeHtml(fmtDate(operation.scheduledAt))}</span></div>
        <div><b>${escapeHtml(operation.plate || '—')}</b><span>${escapeHtml(operation.driver || 'Não informado')}</span></div>
        <div><b>${escapeHtml(fmtKg(Number(operation.currentWeightTons || 0) * 1000))}</b><span>${escapeHtml(operation.status || 'Normal')}</span></div>
      </article>
    `).join('') || '<p>Nenhuma operação concluída.</p>';
    }
    async function initMonitoring() {
        const operations = await API().monitoring();
        const data = operations.map((operation) => ({
            id: operation.id,
            plate: operation.plate || '—',
            status: operation.trackingState === 'STOPPED' ? 'Parado' : operation.trackingState === 'ARRIVED' ? 'Chegou' : 'Em trânsito',
            driver: operation.driver || 'Não informado',
            from: operation.origin || 'Origem não informada',
            to: operation.destination || 'Destino não informado',
            eta: operation.estimatedArrival || '—',
            remaining: `${Math.max(0, 100 - Number(operation.progress || 0)).toFixed(0)}% restante`,
            progress: Number(operation.progress || 0),
            current: operation.currentLatitude != null && operation.currentLongitude != null
                ? [Number(operation.currentLatitude), Number(operation.currentLongitude)]
                : null,
            start: null,
            end: null
        }));
        window.LoadSenseMonitoringData = data;
        window.dispatchEvent(new CustomEvent('loadsense:monitoring-data', { detail: data }));
    }
    async function initSettings() {
        const tolerance = document.getElementById('weightTolerance');
        const overload = document.getElementById('overloadLimit');
        const unit = document.getElementById('weightUnit');
        if (!tolerance && !overload && !unit)
            return;
        const settings = await API().settings();
        if (tolerance)
            tolerance.value = settings.tolerance_percent ?? tolerance.value;
        if (overload)
            overload.value = settings.critical_limit_percent ?? overload.value;
        if (unit)
            unit.value = settings.default_weight_unit ?? unit.value;
        [tolerance, overload, unit].filter(Boolean).forEach((element) => {
            element.addEventListener('change', async () => {
                try {
                    await API().updateSettings({
                        tolerance_percent: Number(tolerance?.value || 1.5),
                        critical_limit_percent: Number(overload?.value || 3),
                        default_weight_unit: unit?.value || 'KG'
                    });
                    showToast('Configuração salva no servidor.');
                }
                catch (error) {
                    showToast(error.message || 'Não foi possível salvar a configuração.');
                }
            });
        });
        document.getElementById('testConnection')?.addEventListener('click', async () => {
            try {
                const status = await API().systemStatus();
                showToast(`API ${status.api.state} · Banco ${status.database.state}`);
            }
            catch (error) {
                showToast(error.message || 'Não foi possível consultar o servidor.');
            }
        });
    }
    async function initNewWeighing() {
        const button = document.getElementById('registerButton');
        if (!button)
            return;
        button.addEventListener('click', async (event) => {
            event.preventDefault();
            const plate = document.getElementById('plate')?.value.trim() || '';
            const driverName = document.getElementById('driver')?.value.trim() || '';
            const rfid = document.getElementById('rfid')?.value.trim() || '';
            const origin = document.getElementById('origin')?.value.trim() || '';
            const destination = document.getElementById('destination')?.value.trim() || '';
            const cargoName = document.getElementById('cargoType')?.value.trim() || '';
            const parseWeight = (id) => Number(String(document.getElementById(id)?.value || '').replace(/[^0-9,.-]/g, '').replace('.', '').replace(',', '.'));
            const empty = parseWeight('emptyWeight');
            const cargo = parseWeight('cargoWeight');
            const loaded = parseWeight('loadedWeight');
            if (!plate || empty <= 0 || cargo <= 0 || loaded <= 0) {
                showToast('Preencha veículo e os três pesos.');
                return;
            }
            if (Math.abs(loaded - (empty + cargo)) > 0.001) {
                showToast('Os pesos não conferem.');
                return;
            }
            button.disabled = true;
            try {
                const catalogs = await API().catalogs();
                const vehicle = catalogs.vehicles.find((item) => String(item.plate).toUpperCase() === plate.toUpperCase());
                const driver = driverName ? catalogs.drivers.find((item) => item.full_name.toLowerCase() === driverName.toLowerCase()) : null;
                const tag = rfid ? catalogs.rfid_tags.find((item) => item.code.toLowerCase() === rfid.toLowerCase()) : null;
                const product = cargoName ? catalogs.cargo_products.find((item) => item.name.toLowerCase() === cargoName.toLowerCase()) : null;
                const route = catalogs.routes.find((item) => item.origin.toLowerCase() === origin.toLowerCase() && item.destination.toLowerCase() === destination.toLowerCase());
                const unit = catalogs.operational_units[0];
                const user = JSON.parse(localStorage.getItem('loadsense_usuario') || '{}');
                if (!vehicle)
                    throw new Error('Veículo não encontrado no cadastro.');
                if (!unit)
                    throw new Error('Nenhuma unidade operacional cadastrada.');
                const operation = await API().createOperation({
                    operational_unit_id: unit.id,
                    vehicle_id: vehicle.id,
                    driver_id: driver?.id || null,
                    rfid_tag_id: tag?.id || null,
                    cargo_product_id: product?.id || null,
                    route_id: route?.id || null,
                    responsible_user_id: user.id,
                    weighing_method: 'THREE_STAGE',
                    declared_cargo_weight_kg: cargo,
                    declared_quantity_unit: 'KG'
                });
                for (const readingData of [
                    { stage: 'EMPTY_TRUCK', weight_kg: empty },
                    { stage: 'SEPARATED_CARGO', weight_kg: cargo },
                    { stage: 'LOADED_TRUCK', weight_kg: loaded }
                ]) {
                    const reading = await API().addReading(operation.id, {
                        ...readingData,
                        source: 'MANUAL',
                        is_stable: 1,
                        measured_at: new Date().toISOString(),
                        manual_reason: 'Registrada pelo operador no painel web.'
                    });
                    await API().acceptReading(operation.id, reading.id);
                }
                await API().finalizeOperation(operation.id);
                showToast('Pesagem registrada no banco de dados.');
                window.setTimeout(() => {
                    window.location.href = '../Dashboard/Dashboard.html';
                }, 900);
            }
            catch (error) {
                button.disabled = false;
                showToast(error.message || 'Não foi possível registrar a pesagem.');
            }
        }, { once: true });
    }
    document.addEventListener('DOMContentLoaded', async () => {
        if (!publicPages.has(file)) {
            const authenticated = await requireSession();
            if (!authenticated)
                return;
        }
        try {
            switch (file) {
                case 'login.html':
                    await initLogin();
                    break;
                case 'cadastro.html':
                    await initCadastro();
                    break;
                case 'dashboard.html':
                    await initDashboard();
                    break;
                case 'planilha.html':
                    await initOperationsTable();
                    break;
                case 'alertas.html':
                    await initAlerts();
                    break;
                case 'historico.html':
                    await initHistory();
                    break;
                case 'monitoramento.html':
                    await initMonitoring();
                    break;
                case 'configuracoes.html':
                    await initSettings();
                    break;
                case 'novapesagem.html':
                    await initNewWeighing();
                    break;
            }
        }
        catch (error) {
            console.error('LoadSense integration error:', error);
            if (error?.status === 401)
                redirectLogin();
            else
                showToast(error.message || 'Não foi possível carregar os dados do servidor.');
        }
    });
})();
