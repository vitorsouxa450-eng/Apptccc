const USAR_API = true;
const relatoriosMock = {
    semanal: {
        titulo: "Relatório Semanal",
        grafico: [
            { label: "Seg", operacoes: 42 },
            { label: "Ter", operacoes: 55 },
            { label: "Qua", operacoes: 48 },
            { label: "Qui", operacoes: 60 },
            { label: "Sex", operacoes: 38 },
            { label: "Sáb", operacoes: 25 },
            { label: "Dom", operacoes: 13 }
        ],
        status: {
            normal: 15,
            atencao: 7,
            critico: 4,
            analise: 2
        },
        recomendacoes: [
            "Picos de operações na quinta-feira: recomenda-se alocar equipe extra neste dia.",
            "Domingo apresentou menor volume operacional; período adequado para manutenção preventiva da balança.",
            "Parte das operações de sexta-feira apresentou divergência acima da tolerância no turno da tarde."
        ]
    },
    mensal: {
        titulo: "Relatório Mensal",
        grafico: [
            { label: "Sem 1", operacoes: 108 },
            { label: "Sem 2", operacoes: 136 },
            { label: "Sem 3", operacoes: 121 },
            { label: "Sem 4", operacoes: 149 }
        ],
        status: {
            normal: 86,
            atencao: 23,
            critico: 13,
            analise: 6
        },
        recomendacoes: [
            "A quarta semana apresentou o maior volume de pesagens do mês.",
            "A quantidade de operações críticas diminuiu em relação às primeiras semanas.",
            "Recomenda-se revisar preventivamente os equipamentos antes das semanas de maior demanda."
        ]
    },
    bimestral: {
        titulo: "Relatório Bimestral",
        grafico: [
            { label: "Mês 1", operacoes: 514 },
            { label: "Mês 2", operacoes: 583 }
        ],
        status: {
            normal: 719,
            atencao: 214,
            critico: 109,
            analise: 55
        },
        recomendacoes: [
            "O segundo mês apresentou crescimento no número total de operações.",
            "Houve redução proporcional dos casos críticos no período.",
            "A IA recomenda analisar rotas e cargas que concentram maior quantidade de divergências."
        ]
    },
    trimestral: {
        titulo: "Relatório Trimestral",
        grafico: [
            { label: "Mês 1", operacoes: 514 },
            { label: "Mês 2", operacoes: 583 },
            { label: "Mês 3", operacoes: 642 }
        ],
        status: {
            normal: 1187,
            atencao: 318,
            critico: 156,
            analise: 78
        },
        recomendacoes: [
            "O terceiro mês apresentou o maior volume operacional do trimestre.",
            "As divergências vêm apresentando redução proporcional mesmo com o aumento das operações.",
            "Caso o crescimento continue, recomenda-se avaliar aumento da capacidade operacional."
        ]
    }
};
const cardsRelatorio = document.querySelectorAll(".report-card");
const tituloRelatorio = document.getElementById("reportTitle");
const grafico = document.getElementById("chart");
const listaRecomendacoes = document.getElementById("recommendationList");
const tooltip = document.getElementById("chartTooltip");
const tooltipLabel = document.getElementById("tooltipLabel");
const tooltipValue = document.getElementById("tooltipValue");
const botaoPDF = document.getElementById("exportPdf");
const botaoExcel = document.getElementById("exportExcel");
const toast = document.getElementById("toast");
const toastText = document.getElementById("toastText");
let periodoAtual = "semanal";
let dadosAtuais = null;
async function obterDadosRelatorio(periodo) {
    if (window.LoadSenseAPI) {
        const map = {
            semanal: '7d',
            mensal: '30d',
            bimestral: '30d',
            trimestral: '90d'
        };
        try {
            const data = await window.LoadSenseAPI.reports(map[periodo] || '30d');
            const summary = data.summary || {};
            const title = {
                semanal: 'Relatório Semanal',
                mensal: 'Relatório Mensal',
                bimestral: 'Relatório Bimestral',
                trimestral: 'Relatório Trimestral'
            }[periodo] || 'Relatório';
            const performance = Array.isArray(data.performance) ? data.performance : [];
            return {
                titulo: title,
                grafico: performance.length
                    ? performance.map((value, index) => ({ label: `P${index + 1}`, operacoes: value }))
                    : [{ label: 'Sem dados', operacoes: 0 }],
                status: {
                    normal: Number(summary.normal || 0),
                    atencao: Number(summary.attention || 0),
                    critico: Number(summary.critical || 0),
                    analise: Number(summary.analysis || 0)
                },
                recomendacoes: [
                    `${Number(summary.operations || 0).toLocaleString('pt-BR')} operações no período consultado.`,
                    `${Number(summary.divergences || 0).toLocaleString('pt-BR')} operações com divergências de atenção/críticas.`,
                    `Eficiência média calculada: ${Number(summary.averageEfficiency || 0).toLocaleString('pt-BR', { maximumFractionDigits: 1 })}%.`
                ]
            };
        }
        catch (erro) {
            console.error('Erro ao consultar API:', erro);
            mostrarToast('Não foi possível carregar os dados do servidor.');
            return null;
        }
    }
    return relatoriosMock[periodo];
}
async function carregarRelatorio(periodo) {
    const dados = await obterDadosRelatorio(periodo);
    if (!dados) {
        return;
    }
    periodoAtual =
        periodo;
    dadosAtuais =
        dados;
    atualizarTitulo(dados);
    atualizarGrafico(dados);
    atualizarTabela(dados);
    atualizarRecomendacoes(dados);
}
function atualizarTitulo(dados) {
    tituloRelatorio.textContent =
        `Prévia — ${dados.titulo}`;
}
function atualizarGrafico(dados) {
    grafico.innerHTML = "";
    if (!dados.grafico ||
        dados.grafico.length === 0) {
        grafico.innerHTML = `
            <p style="
                color:#888;
                width:100%;
                text-align:center;
                margin:auto;
            ">
                Nenhum dado encontrado para este período.
            </p>
        `;
        return;
    }
    const valores = dados.grafico.map(item => item.operacoes);
    const maiorValor = Math.max(...valores);
    dados.grafico.forEach(item => {
        const coluna = document.createElement("div");
        coluna.className =
            "chart-column";
        const barra = document.createElement("div");
        barra.className =
            "chart-bar";
        const altura = maiorValor > 0
            ? (item.operacoes / maiorValor) * 100
            : 0;
        barra.style.height =
            `${altura}%`;
        barra.dataset.valor =
            item.operacoes;
        barra.dataset.label =
            item.label;
        const label = document.createElement("span");
        label.className =
            "chart-label";
        label.textContent =
            item.label;
        barra.addEventListener("mouseenter", event => {
            mostrarTooltip(event, item.label, item.operacoes);
        });
        barra.addEventListener("mousemove", moverTooltip);
        barra.addEventListener("mouseleave", esconderTooltip);
        coluna.appendChild(barra);
        coluna.appendChild(label);
        grafico.appendChild(coluna);
    });
}
function atualizarTabela(dados) {
    const status = dados.status;
    if (!status) {
        return;
    }
    const total = status.normal +
        status.atencao +
        status.critico +
        status.analise;
    const linhas = document.querySelectorAll(".status-table .table-row");
    const valores = [
        {
            quantidade: status.normal
        },
        {
            quantidade: status.atencao
        },
        {
            quantidade: status.critico
        },
        {
            quantidade: status.analise
        }
    ];
    linhas.forEach((linha, index) => {
        const colunas = linha.querySelectorAll("span");
        const quantidade = valores[index].quantidade;
        const percentual = total > 0
            ? (quantidade /
                total *
                100)
            : 0;
        colunas[1].textContent =
            quantidade;
        colunas[2].textContent =
            percentual.toFixed(1) + "%";
    });
}
function atualizarRecomendacoes(dados) {
    listaRecomendacoes.innerHTML = "";
    if (!dados.recomendacoes ||
        dados.recomendacoes.length === 0) {
        listaRecomendacoes.innerHTML =
            "<li>Nenhuma recomendação disponível.</li>";
        return;
    }
    dados.recomendacoes.forEach(recomendacao => {
        const item = document.createElement("li");
        item.textContent =
            recomendacao;
        listaRecomendacoes.appendChild(item);
    });
}
cardsRelatorio.forEach(card => {
    card.addEventListener("click", async function () {
        const periodo = this.dataset.report;
        if (!periodo) {
            return;
        }
        cardsRelatorio.forEach(item => {
            item.classList.remove("active");
        });
        this.classList.add("active");
        await carregarRelatorio(periodo);
    });
});
function mostrarTooltip(event, label, valor) {
    tooltipLabel.textContent =
        label;
    tooltipValue.textContent =
        `Operações: ${valor}`;
    tooltip.classList.add("show");
    moverTooltip(event);
}
function moverTooltip(event) {
    tooltip.style.left =
        `${event.clientX + 15}px`;
    tooltip.style.top =
        `${event.clientY - 65}px`;
}
function esconderTooltip() {
    tooltip.classList.remove("show");
}
let timerToast;
function mostrarToast(mensagem) {
    if (!toast ||
        !toastText) {
        return;
    }
    clearTimeout(timerToast);
    toastText.textContent =
        mensagem;
    toast.classList.add("show");
    timerToast =
        setTimeout(() => {
            toast.classList.remove("show");
        }, 2300);
}
if (botaoPDF) {
    botaoPDF.addEventListener("click", () => {
        mostrarToast("Preparando relatório em PDF...");
        console.log("Exportação PDF:", dadosAtuais);
    });
}
if (botaoExcel) {
    botaoExcel.addEventListener("click", () => {
        if (!dadosAtuais) {
            mostrarToast("Nenhum relatório carregado.");
            return;
        }
        mostrarToast("Exportando relatório para Excel...");
        gerarCSV();
    });
}
function gerarCSV() {
    if (!dadosAtuais) {
        return;
    }
    let csv = "Periodo;Operacoes\n";
    dadosAtuais.grafico.forEach(item => {
        csv +=
            `${item.label};${item.operacoes}\n`;
    });
    csv += "\n";
    csv +=
        "Status;Operacoes\n";
    csv +=
        `Normal;${dadosAtuais.status.normal}\n`;
    csv +=
        `Atencao;${dadosAtuais.status.atencao}\n`;
    csv +=
        `Critico;${dadosAtuais.status.critico}\n`;
    csv +=
        `Analise;${dadosAtuais.status.analise}\n`;
    const blob = new Blob([
        "\uFEFF" + csv
    ], {
        type: "text/csv;charset=utf-8;"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href =
        url;
    link.download =
        `LoadSense_Relatorio_${periodoAtual}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}
const campoBusca = document.querySelector(".search-box input");
if (campoBusca) {
    campoBusca.addEventListener("keydown", event => {
        if (event.key === "Enter") {
            const pesquisa = campoBusca
                .value
                .trim();
            if (!pesquisa) {
                return;
            }
            console.log("Buscar:", pesquisa);
        }
    });
}
document.addEventListener("DOMContentLoaded", async () => {
    await carregarRelatorio("semanal");
    if (typeof lucide !==
        "undefined") {
        lucide.createIcons();
    }
});
